$(document).ready(function () {
	$("#InstutionName").on("change", function () {
		var InstutionName = $("#InstutionName").val();
		$.ajax({
			type: "POST",
			url: baseurl + "Department/get_department",
			data: {
				InstutionName: InstutionName,
			},
			success: function (response) {
				var responseData = JSON.parse(response);
				var dropdownOptions = { "": "Select Department" }; // Initial dropdown options
				// Loop through the response data and add each district to the dropdown options
				for (var i = 0; i < responseData.length; i++) {
					var DName = responseData[i];
					dropdownOptions[DName.DepartmentName] = DName.DepartmentName;
				}
				// Update the dropdown with the new options
				$("#Department_Name").empty(); // Clear existing options
				$.each(dropdownOptions, function (key, value) {
					$("#Department_Name").append(
						$("<option></option>").attr("value", key).text(value)
					);
				});
			},
			error: function (xhr, status, error) {
				// Handle error response here
				console.error(
					"Error occurred while sending selected value to the controller."
				);
			},
		});
	});
});

$(document).ready(function () {
	$("#Department_Name").on("change", function () {
		var selectedValue = $(this).val();
		$.ajax({
			type: "POST",
			url: baseurl + "Department/get_staff",
			data: { selectedValue: selectedValue },
			success: function (response) {
				var responseData = JSON.parse(response);
				var dropdownOptions = { "": "Select Staff" }; // Initial dropdown options
				// Loop through the response data and add each district to the dropdown options
				for (var i = 0; i < responseData.length; i++) {
					var DName = responseData[i];
					dropdownOptions[DName.Name] = DName.Name;
				}
				// Update the dropdown with the new options
				$("#Staff_Name").empty(); // Clear existing options
				$.each(dropdownOptions, function (key, value) {
					$("#Staff_Name").append(
						$("<option></option>").attr("value", key).text(value)
					);
				});
			},
			error: function (xhr, status, error) {
				// Handle error response here
				console.error(
					"Error occurred while sending selected value to the controller."
				);
			},
		});
	});
});

$(document).ready(function () {
	$("#Department_Name").on("change", function () {
		var Department_Name = $(this).val(); // Get the selected Department_Name
		$("#Course_type").on("change", function () {
			var Course_type = $(this).val(); // Get the selected Course_type
			// Perform AJAX request
			$.ajax({
				type: "POST",
				url: baseurl + "Department/get_batch_1", // Adjust baseurl as needed
				data: { Course_type: Course_type, Department_Name: Department_Name },
				success: function (response) {
					var responseData = JSON.parse(response);
					var dropdownOptions = { "": "Select Batch" }; // Initial dropdown options
					var Section = { "": "Select Section" }; // Initial dropdown options
					var Course = { "": "Select Course" }; // Initial dropdown options

					// Build options for dropdown
					$.each(responseData, function (index, item) {
						dropdownOptions[item.Batch] = item.Batch;
						Section[item.Section] = item.Section;
						Course[item.Course_Name] = item.Course_Name;zz
					});

					$("#Batch").empty(); // Clear existing options
					$.each(dropdownOptions, function (key, value) {
						$("#Batch").append(
							$("<option></option>").attr("value", key).text(value)
						);
					});
					$("#Section").empty(); // Clear existing options
					$.each(Section, function (key, value) {
						$("#Section").append(
							$("<option></option>").attr("value", key).text(value)
						);
					});

					$("#Course").empty(); // Clear existing options
					$.each(Course, function (key, value) {
						$("#Course").append(
							$("<option></option>").attr("value", key).text(value)
						);
					});
				},
				error: function (xhr, status, error) {
					console.error(
						"Error occurred while sending selected value to the controller.",
						error
					);
					// Handle error response here
				},
			});
		});
	});
});

$(document).ready(function () {
	$("#Class-view234").hide();
	$("#get_Department_list23").on("click", function () {
		var InstitutionName = $("#Inst_name_1").val();
		var Inst_codes = $("#Inst_codes").val();
		var Department_Name = $("#Department_Name11").val();
		var Course_type = $("#Course_type").val();
		var Batch = $("#Batch").val();
		var Section = $("#Section").val();
		var Approval = $("#Approval").val();

		$.ajax({
			type: "POST",
			url: baseurl + "Department/Get_class_inchar",
			data: {
				InstitutionName: InstitutionName,
				Inst_codes: Inst_codes,
				Department_Name: Department_Name,
				Course_type: Course_type,
				Batch: Batch,
				Section: Section,
				Approval: Approval,
			},

			success: function (response) {
				try {
					var responseData = JSON.parse(response);

					$("#Class_stud124").empty(); // Clear existing table rows
					$.each(responseData.reports, function (index, item) {
						$("#Class-view234").show();

						var row = `<tr>
<td>${index + 1}</td>
<td>${item.InstutionCode}</td>
<td>${item.Instution_Name}</td>
<td>${item.Department_Code}</td>
<td>${item.Department_Name}</td>
<td>${item.Staff_Name}</td>
<td>${item.Course_type}</td>
<td>${item.Batch}</td>
<td>${item.Course_Name}</td>
<td>${item.Section}</td>


		

		</tr>`;

						$("#Class_stud124").append(row);
					});
				} catch (error) {
					console.error("Error parsing response:", error);
				}
			},
			error: function (xhr, status, error) {
				console.error("AJAX request failed:", status, error);
				// Optionally handle error display to the user
			},
		});
	});

	// Function to escape HTML characters
	function escapeHtml(unsafe) {
		return typeof unsafe === "string"
			? unsafe.replace(/[&<"']/g, function (m) {
					switch (m) {
						case "&":
							return "&amp;";
						case "<":
							return "&lt;";
						case '"':
							return "&quot;";
						case "'":
							return "&#39;";
						default:
							return m;
					}
			  })
			: unsafe;
	}
});
