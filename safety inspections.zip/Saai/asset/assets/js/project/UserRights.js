// Define an empty object to store checkbox IDs
var checkboxIds = {};

$(document).ready(function () {
	// AJAX request to populate dropdown
	$.ajax({
		type: "POST",
		url: baseurl + "UserRights/Get_UserType",
		success: function (response) {
			var responseData = JSON.parse(response);
			var dropdownOptions = { "": "Select Menus" };

			for (var i = 0; i < responseData.length; i++) {
				var Menus = responseData[i];
				dropdownOptions[Menus.MenuHead] = Menus.MenuHead;
			}

			$("#Menus_id").empty();
			$.each(dropdownOptions, function (key, value) {
				$("#Menus_id").append(
					$("<option></option>").attr("value", key).text(value)
				);
			});
		},
		error: function (xhr, status, error) {
			console.error("Error occurred while fetching user types.");
		},
	});

	// Hide column initially
	$("#column").hide();

	// Event listener for dropdown change
	$("#Menus_id").on("change", function () {
		checkboxIds = $();
		var selectedValue = $(this).val();
		if (selectedValue !== "") {
			$.ajax({
				type: "POST",
				url: baseurl + "UserRights/Get_SubMenus",
				data: { selectedValue: selectedValue },
				success: function (response) {
					var responseData = JSON.parse(response);
					var data1 = responseData.get_active_details;
					var data2 = responseData.Get_SubMenu;
					console.log(data1);

					$("#good").empty();
					$.each(data2, function (index2, item1) {
						var activeDetail = data1.find(function (detail) {
							return detail.SubMenus === item1.FormName;
						});

						// Assuming the checkboxes are always checked
						var addChecked = activeDetail && activeDetail.Adds === "1";
						var deleteChecked = activeDetail && activeDetail.Deletes === "1";
						var editChecked = activeDetail && activeDetail.Edits === "1";
						var viewChecked = activeDetail && activeDetail.Views === "1";

						$("#good").append(
							"<tr><td>" +
								item1.FormName +
								'</td><td><input type="checkbox" class="Add" ' +
								(addChecked ? "checked" : "") +
								' id="Add"></td><td><input type="checkbox" class="delete" ' +
								(deleteChecked ? "checked" : "") +
								' id="delete"></td><td><input type="checkbox" class="edit" ' +
								(editChecked ? "checked" : "") +
								' id="edit"></td><td><input type="checkbox" class="view" ' +
								(viewChecked ? "checked" : "") +
								' id="view"></td></tr>'
						);
					});

					$("#column").show();
				},
				error: function (xhr, status, error) {
					console.error("Error occurred while fetching submenus.");
				},
			});
		}
	});

	// Event listener for checkboxes
	$("#good").on("change", 'input[type="checkbox"]', function () {
		var $row = $(this).closest("tr");
		var rowId = $row.index();
		var rowData = {
			FormName: $row.find("td:eq(0)").text(),
			Add: $row.find('input[class="Add"]').prop("checked") ? 1 : 0,
			Delete: $row.find('input[class="delete"]').prop("checked") ? 1 : 0,
			Edit: $row.find('input[class="edit"]').prop("checked") ? 1 : 0,
			View: $row.find('input[class="view"]').prop("checked") ? 1 : 0,
		};

		// Check if rowId already exists in checkboxIds
		if (!checkboxIds[rowId]) {
			// Add rowData to checkboxIds
			checkboxIds[rowId] = rowData;

			// Loop through each checkbox in the row to ensure unchecked checkboxes are also included
			$row.find('input[type="checkbox"]').each(function () {
				var checkboxClass = $(this).attr("class");
				if (!(checkboxClass in rowData)) {
					checkboxIds[rowId][checkboxClass] = 0;
				}
			});
		} else {
			// Row data already exists, handle accordingly
			// You can update the existing data or ignore the change
			// For now, let's just log a message
			console.log("Row data already exists for rowId:", rowId);
		}
	});

	// Event listener for form submission
	$("#form_data").on("click", function (event) {
		event.preventDefault();
		deleteOldData(function () {
			insertNewData();
		});
	});
});

// Function to delete old data
function deleteOldData(callback) {
	var selectedUserType = $("#User_Type").val();
	var selectedMenuId = $("#Menus_id").val();

	$.ajax({
		type: "POST",
		url: baseurl + "UserRights/Delete_old_data",
		data: {
			selectedUserType: selectedUserType,
			selectedMenuId: selectedMenuId,
		},
		success: function (response) {
			callback();
		},
		error: function (xhr, status, error) {
			console.error("Error occurred while deleting old data.");
		},
	});
}

// Function to insert new data
function insertNewData() {
	var selectedUserType = $("#User_Type").val();
	var selectedMenuId = $("#Menus_id").val();

	$.ajax({
		type: "POST",
		url: baseurl + "UserRights/Insert_new_data",
		data: {
			checkboxIds: JSON.stringify(checkboxIds),
			selectedUserType: selectedUserType,
			selectedMenuId: selectedMenuId,
		},
		success: function (response) {
			console.log("Inserted New Data");
			Swal.fire({
				icon: "success",
				title: "Success!",
				text: "Succesfully Stored Data..!.",
			});
		},
		error: function (xhr, status, error) {
			console.error("Error occurred while inserting new data.");
		},
	});
}
