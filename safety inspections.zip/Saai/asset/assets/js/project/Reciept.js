function printDiv() 
{

  var printname=$('#printname11').val();


   	w=window.open();        
   	
			w.document.write(jQuery('.printdiv_pdf').html());
			 w.document.title = printname;
			w.document.close();
			w.print();

}
// Function to convert a number into words
function convertNumberToWords(number) {

    // Separate the integer and decimal parts
    var integerPart = Math.floor(number);
    var decimalPart = parseInt((number - integerPart) * 100);

    // Array of words for the numbers
    var words = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine',
                 'ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen',
                 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];

    // Array of words for the powers of 10
    var powers = ['', 'thousand', 'lakh', 'crore'];

    // Convert the integer part into words
    var integerWords = '';
    if (integerPart > 0) {
        integerWords = capitalizeFirstLetter(convertThreeDigitNumberToWords(integerPart, words, powers));
    } else {
        integerWords = 'Zero';
    }

    // Convert the decimal part into words
    var decimalWords = '';
    if (decimalPart > 0) {
        decimalWords = capitalizeFirstLetter(convertTwoDigitNumberToWords(decimalPart, words));
    }

    // Build the final result
    var result = '';
    if (integerWords !== '') {
        result += integerWords + ' Rupees';
    }
    if (decimalWords !== '') {
        result += ' and ' + decimalWords + ' Paise';
    }
    return result;
}

// Function to convert a string to capitalize the first letter of each word
function capitalizeFirstLetter(str) {
    return str.replace(/\b\w/g, function(char) {
        return char.toUpperCase();
    });
}

// Function to convert a three-digit number into words
function convertThreeDigitNumberToWords(number, words, powers) {
    var word = '';
    var i = 0;
    while (number > 0) {
        var divisor = number % 100;
        if (divisor > 0) {
            word = convertTwoDigitNumberToWords(divisor, words) + ' ' + powers[i] + ' ' + word;
        }
        number = Math.floor(number / 100);
        i++;
    }
    return word;
}

// Function to convert a two-digit number into words
function convertTwoDigitNumberToWords(number, words) {
    if (number < 20) {
        return words[number];
    } else {
        var tens = Math.floor(number / 10);
        var units = number % 10;
        return words[tens + 18] + ((units > 0) ? ' ' + words[units] : '');
    }
}

// When the Convert button is clicked
$(document).ready(function() {
    var amount = parseFloat($('#amount').val());
    var amountWords = convertNumberToWords(amount);
    $('#result').text(amountWords + ' Only');
    $('#result123').text(amountWords + ' Only');
});