$(document).ready(function () {

     $('#exam-coordinating').hide();

    $("#InstutionName").on("change", function () {
        var InstutionName = $(this).val();
        $("#Course_type").on("change", function () {
            var Course_type = $(this).val();
            $("#DepartmentName").on("change", function () {
                var DepartmentName = $(this).val();
                $("#Course_name").on("change", function () {
                    var Course_name = $(this).val();
                    $("#Batch").on("change", function () {
                        var Batch = $(this).val();
                        $("#Semesters").on("change", function () {
                            var Semesters = $(this).val();

                            $.ajax({
                                type: "POST",
                                url: baseurl + "Exam_Schedule/get_subject",
                                data: {
                                    InstutionName: InstutionName,
                                    Course_type: Course_type,
                                    DepartmentName: DepartmentName,
                                    Course_name: Course_name,
                                    Batch: Batch,
                                    Semesters: Semesters,
                                },
                                success: function (response) {
                              
                                var responseData = JSON.parse(response);
                                $("#exam-planning tbody").empty();

                                // Loop through response data and append rows to table
                                $.each(responseData, function(index, item) {
                                    // Create an input field with a default date format
                                    var defaultDate = ""; // You can set a default date here if needed
                                    $('#exam-coordinating').show();
                                    // Construct the row using template literals
                                    var row = `<tr data-subject-id="${item.SubjectCode}">
                                    <td class="md-3">${index + 1}</td>
                                    <td class="md-3" id="Subject_Name" >${item.SubjectName}</td>
                                    <td class="md-3"><input type="date" id="ExamDate"  name="select_date_${item.SubjectCode}" class="exam-date-input form-control md-3" value="${defaultDate}"></td>
                                    <td class="md-3">
                                        <select name="exam_type_${item.SubjectCode}" class="exam-type-select form-control md-3" id="Session">
                                            <option value="">Select Type</option>
                                            <option value="Forenoon">Forenoon</option>
                                            <option value="Afternoon">Afternoon</option>
                                        </select>
                                    </td>
                                </tr>`;
                                

                                    // Append each row to the table body
                                    $("#exam-planning tbody").append(row);
                                });

                                $('#update_exam_sechedule').on('click', function(){

                                    var InstitutionName = $("#InstutionName").val();
                                    var CourseType = $("#Course_type").val();
                                    var DepartmentName = $("#DepartmentName").val();
                                    var Batch = $("#Batch").val();
                                    var ExamCategory = $("#ExamCategory").val();
                                    var Semester = $("#Semesters").val();
                                    var Subject_Name = $("#Subject_Name").val();
                                    var ExamDate = $("#ExamDate").val();
                                    var Session = $("#Session");
                                    var Course_name = $("#Course_name").val();


                                                                // Prepare data array to send via AJAX
                                    var dataArray = [];

                                    $("#exam-planning tbody tr").each(function() {
                                        var SubjectCode = $(this).data("subject-id");
                                        var SubjectName = $(this).find(".md-3:eq(1)").text();
                                        var ExamDate = $(this).find(".exam-date-input").val();
                                        var Session = $(this).find(".exam-type-select").val();

                                        // Push each row's data as an object into the dataArray
                                        dataArray.push({
                                            SubjectCode: SubjectCode,
                                            SubjectName: SubjectName,
                                            ExamDate: ExamDate,
                                            Session: Session
                                        });


                                                            })

                                                            // Send dataArray via AJAX
                                    $.ajax({
                                        type: "POST",
                                        url: baseurl + "Exam_Schedule/update",
                                        data: {
                                            InstitutionName: InstitutionName,
                                            CourseType: CourseType,
                                            DepartmentName: DepartmentName,
                                             Course_name : Course_name,
                                            Batch: Batch,
                                            ExamCategory: ExamCategory,
                                            Semester: Semester,
                                            ExamSchedule: JSON.stringify(dataArray)  // Send the array of data as JSON string
                                        },
                                        success: function (response) {

                                            var responseData = JSON.parse(response);

                                            if (responseData == 'SAVE') {
                                                Swal.fire({
                                                    title: "Good job!",
                                                    text: "The exam has already been assigned and cannot be reassigned.",
                                                    icon: "success",
                                                    confirmButtonText: "OK",
                                                }).then((result) => {
                                                    if (result.isConfirmed) {
                                                        window.location.href = baseurl + "Exam_Schedule";
                                                    }
                                                });
                                            } else if (responseData == 'ALREADY') {
                                                Swal.fire({
                                                    title: "Oops!",
                                                    text: "The assignment of the exam schedule has been already updated.",
                                                    icon: "error",
                                                    confirmButtonText: "OK",
                                                }).then((result) => {
                                                    if (result.isConfirmed) {
                                                        window.location.href = baseurl + "Exam_Schedule";
                                                    }
                                                });
                                            }
                                        },
                                        error: function (xhr, status, error) {
                                            console.error("Error occurred while saving exam schedule:", error);
                                            // Handle error response here
                                        },
                                    });
                                });

                                  
                                },
                                
                                error: function (xhr, status, error) {
                                    console.error("Error occurred while fetching subjects:", error);
                                    // Handle error response here
                                },
                            });
                        });
                    });
                });
            });
        });
    });
});


$(document).ready(function () {
    $('#Exam_sedule21').hide();

    $("#get_Exam_for_assign").on("click", function () {
        var InstitutionName = $("#InstutionName").val();
        var Course_type = $("#Course_type").val();
        var DepartmentName = $("#DepartmentName").val();
        var Course_name = $("#Course_name").val();
        var Batch = $("#Batch").val();
        var ExamCategory = $("#ExamCategory").val();
        var Semesters = $("#Semesters").val();

        $.ajax({
            type: "POST",
            url: baseurl + "Exam_Schedule/Get_Exam_Schedule",
            data: {
                InstitutionName: InstitutionName,
                Course_type: Course_type,
                DepartmentName: DepartmentName,
                Course_name: Course_name,
                Batch: Batch,
                ExamCategory: ExamCategory,
                Semesters: Semesters
            },
            success: function (response) {
                try {
                    var responseData = JSON.parse(response);

                    $('#Exam_sed12').empty(); // Clear existing table rows

                    $.each(responseData.reports, function(index, item) {
                        $('#Exam_sedule21').show();

                        var row = `<tr>
                             <td>${index + 1}</td>
                            <td>${item.InstitutionName}</td>
                            <td>${item.DepartmentName}</td>
                            <td>${item.CourseType}</td>
                            <td>${item.CourseName}</td>
                            <td>${item.Batch}</td>
                            <td>${item.Semester}</td>
                            <td>${item.ExamCategory}</td>
                           <td>${item.SubjectCode}</td>
                            <td>${item.SubjectName}</td>
                            <td>${item.ExamDate}</td>
                            <td>${item.Session}</td>
                        </tr>`;

                        $('#Exam_sed12').append(row);
                    });
                } catch (error) {
                    console.error("Error parsing response:", error);
                }
            },
            error: function (xhr, status, error) {
                console.error("AJAX request failed:", status, error);
                // Optionally handle error display to the user
            }
        });
    });
});
