$(document).ready(function(){


    function details(order_id, amount, serializedData, totalAmount,fullname,email,mobile) {
    
        
        var rp = "rzp_test_ERi8OTWrDXP06W";
        var options = {
            "key": rp,
            "amount": amount,
            "currency": "INR",
            "name": "Annaiveilankannis Group Of Educational Institute",
            "description": "Test Transaction",
            "image": "https://localhost/av/assets/new/images/AVC-Logo.png",
            "order_id": order_id,
            "handler": function(response) {
                // alert("Please wait while we process. Do not press any buttons.");
                     let timerInterval;
        Swal.fire({
            title: 'Please wait while we process.',
            text: 'Do not press any buttons.',
            icon: 'info',
            showCancelButton: false,
            showConfirmButton: false,
            allowOutsideClick: false,
            timerProgressBar: true, // Show progress bar
            timer: 5000, // 10000 milliseconds = 10 seconds
            didOpen: () => {
                const content = Swal.getContent();
                const timer = Swal.getTimerLeft();
                const duration = Math.ceil(timer / 500);
    
                if (content) {
                    const countdown = document.createElement('div');
                    countdown.textContent = 'Redirecting in ' + duration + ' seconds';
                    content.appendChild(countdown);
    
                    timerInterval = setInterval(() => {
                        const timer = Swal.getTimerLeft();
                        const duration = Math.ceil(timer / 1000);
                        countdown.textContent = 'Redirecting in ' + duration + ' seconds';
                    }, 1000);
                }
            },
            willClose: () => {
                clearInterval(timerInterval);
            }
        }).then((result) => {
            if (result.dismiss === Swal.DismissReason.timer) {
                // Redirect after 10 seconds
               var id=document.getElementById('razorpay1').submit();
            }
        });
    
                var al= document.getElementById('payment_id').value = response.razorpay_payment_id;
                var sem = document.getElementById('selectedSemesters').value = serializedData;
                var am = document.getElementById('totalAmount').value = totalAmount;
                //  alert(sem)
                //  alert(am)
                document.getElementById('order_id').value = response.razorpay_order_id;
                document.getElementById('signature_value').value = response.razorpay_signature;
                
            },
            "prefill": {
                "name": fullname,
                "email": email,
                "contact": mobile
            },
            "notes": {},
            "theme": {
                "color": "#3399cc"
            }
        };
        
        var rzp1 = new Razorpay(options);
        rzp1.open();
    }
    


    var totalAmount = 0;
    var selectedSemesters =[];
    

    function updateTotalAmount() {
        totalAmount = selectedSemesters.reduce(function(total, semester,feestype) {
            return total + semester.amount;
        }, 0);
        

        $('#total_row').remove();
        var totalRow = "<tr id='total_row'><td colspan='3'>Total</td><td id='smd'>" + totalAmount.toFixed(2) + "</td><td></td></tr>";
        $('#your_table_id').append(totalRow);
    }

    function sendAjaxRequest() {
        var serializedData = JSON.stringify(selectedSemesters);
        document.getElementById('selectedSemesters').value = serializedData;
        
        $.ajax({
            url: baseurl+"Fees/fetch_fee",
            type: 'POST',
            dataType: 'json',
            data: {'totalAmount': totalAmount, 'semester': serializedData},
            success: function(response) {

                var data1 = response.data1;
                var data2 = response.data2;

                var order_id = data2.order_id;
                var amount = data2.amount;

                var name = data1.name;
                var initial = data1.initial;
                var fullname = initial+"."+name;
                var email = data1.email_id;
                var mobile = data1.mobile_no;

                details(order_id, amount, serializedData, totalAmount,fullname,email,mobile);
            },
            error: function(xhr, status, error) {
                console.error("Error occurred: " + xhr.responseText);
            }
        });
    }

    $('#your_table_id').on('click', 'input[type="checkbox"]', function() {
        var $row = $(this).closest('tr');
    var amount = parseFloat($row.find('td:nth-child(4)').text());
    var semester = $row.find('td:nth-child(3)').text();
    var feestype = $row.find('td:nth-child(2)').text();
    

        

        if ($(this).is(':checked')) {
            selectedSemesters.push({semester: semester, amount: amount,feestype: feestype}); 
        } else {
            var index = selectedSemesters.findIndex(function(item) {
                return item.semester === semester; 
            });
            if (index !== -1) {
                selectedSemesters.splice(index, 1);
            }
        }

        updateTotalAmount();
    });

    $('#your_table_id').on('click', '#divide', function() {
        var $row = $(this).closest('tr');
        var amount4 = $row.find('td:nth-child(4)').text();
        var semester1 = $row.find('td:nth-child(3)').text();
        var feestype = $row.find('td:nth-child(2)').text();
        var sno = $row.find('td:nth-child(1)').text();

        var partial = amount4 / 2;

        var pt = "<tr><td colspan='1'>" + sno + "</td><td>" + feestype + "</td><td>" + semester1 + "</td><td>" + partial.toFixed(2) + "</td><td><input type='checkbox'></td></tr>";
        var pt1 = "<tr><td colspan='1'>" + sno + "</td><td>" + feestype + "</td><td>" + semester1 + "</td><td>" + partial.toFixed(2) + "</td><td><input type='checkbox'></td></tr>";
        
        $('#your_table_id').append(pt);
        $('#your_table_id').append(pt1);
        
        $row.hide();
    });

    $('#rzp-button').click(function() {
       
        sendAjaxRequest();
    });

    $('#fees').change(function() {
        var feesid = $(this).val();
        $.ajax({
            url: '<?php echo base_url("Multi/updsess");?>',
            type: 'POST',
            data: {'feesId': feesid},
            success: function(response) {

            }
        });
    }); 


    $('#FeesType').change(function() {
        var feesid = $(this).val();

        $.ajax({
            url: baseurl+"Fees/get_fees_data",
            type: 'POST',
            data: {'FeesType': feesid},
            success: function(response) {

                var responseData = JSON.parse(response);

                if (responseData == '0') {
                    swal({
                        title: "Great !!",
                        text: "All due amounts have been paid...!!",
                        icon: "success",
                        button: "Close",
                    });
                    
                    $('#sem').html("--Select--");
                    
                    $('#sno').html("");
                    $('#type').html("");
                    $('#semster2').html("");

                    var colspan = $('#your_table_id tr:first-child td').length;
                    $('#your_table_id').empty();
                    if ($('#your_table_id tr.message-row').length === 0) {
                        var message = '<tr class="message-row"><td style="text-align: center" colspan="' + 4 + '">All due amounts have been paid...!!</td></tr>';
                        $('#your_table_id').append(message);
                    }
                } else {
                    var responseData = JSON.parse(response);

                    var Fees_Id = '';

                    var a = responseData.fees_details;

                  
                   
                    var FeesType = a[0].FeesType;

                
                    if(FeesType == 'Tuition Fees'){
                        Fees_Id = '11';
                    }else if(FeesType == 'Admission Fee'){
                        Fees_Id = '10';
                    }else if(FeesType == 'Examination Fee'){
                        Fees_Id = '12';
                    }else if(FeesType == 'Laboratory Fee'){
                        Fees_Id = '13';
                    }else if(FeesType == 'Laboratory Fee'){
                        Fees_Id = '14';
                    }else if(FeesType == 'Consession Fee'){
                        Fees_Id = '15';
                    }else if(FeesType == 'Course Material Fee'){
                        Fees_Id = '16';
                    }
                    
                    if (Fees_Id == 11) {

                        $('#your_table_id').empty();

                    
                        

                            a.forEach((item, index) => {
                            var s_no = index + 1;
                            var amount = item.Fees; // Assuming Fees is the property holding the amount
                            var semester = item.Semester; // Assuming Semester is the property holding the semester value
                            var row = "<tr><td>" + s_no + "</td><td>" + FeesType + "</td><td>" + semester + "</td><td>" + amount + "</td><td><input type='checkbox'></td>";

                             // current data check 
                             // if (index !== a.data.length - 1) {
                            // if (index !==  a.length - 1) {
                            //     row += "<td><input type='checkbox'></td>";
                            // } else {
                            //     row += "<td><button class='btn btn-warning btn-sm' id='divide'>Split</button></td>"; 
                            // }

                            row += "</tr>";

                            $('#your_table_id').append(row);
                        });
                    } else {

                       

                        $('#your_table_id').empty();

                        a.forEach((item, index) => {
                            var s_no = index + 1;
                            var amount = item.Fees; // Assuming Fees is the property holding the amount
                            var semester = item.Semester; // Assuming Semester is the property holding the semester value
                        
                            var row = "<tr><td>" + s_no + "</td><td>" + FeesType + "</td><td>" + semester + "</td><td>" + amount + "</td><td><input type='checkbox'></td>";
                        
                            row += "</tr>";
                        
                            $('#your_table_id').append(row);
                        });
                        
                        
                        
                        // a.forEach(function(item, index) {
                        //     var s_no = index + 1;
                        //     var amount = item.Fees;
                        //     var semester = item.semester;
                        //     var row = "<tr><td>" + s_no + "</td><td>" + type + "</td><td>" + semester + "</td><td>" + amount.toFixed(2) + "</td>";

                        //      // current data check 
                        //      // if (index !== a.data.length - 1) {
                        //     if (index !== responseData.length - 1) {
                        //         row += "<td><input type='checkbox'></td>";
                        //     } else {
                        //         row += "<td><button class='btn btn-warning btn-sm' id='divide'>Split</button></td>"; 
                        //     }

                        //     row += "</tr>";

                        //     $('#your_table_id').append(row);
                        // });


                        
                    }
                }
            },
            error: function(xhr, status, error) {
                console.error(xhr.responseText);
            }
        });
    });
})