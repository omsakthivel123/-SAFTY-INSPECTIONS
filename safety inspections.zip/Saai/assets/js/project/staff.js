

$(document).ready(function () {
	var currentStep = 1;
	var totalSteps = $(".step").length;

	showStep(currentStep);

	$(".next").click(function () {
		if (currentStep < totalSteps) {
			currentStep++;
			showStep(currentStep);
		}
	});

	$(".prev").click(function () {
		if (currentStep > 1) {
			currentStep--;
			showStep(currentStep);
		}
	});

	$("#courseType").change(function () {
		var selectedCourse = $(this).val();
		if (selectedCourse === "UG") {
			$("#step-5").hide();
			totalSteps = 4;
		} else {
			$("#step-5").show();
			totalSteps = 5;
		}
	});

	function showStep(step) {
		$(".step").removeClass("active");
		$("#step-" + step).addClass("active");
	}

	// Initialize based on the default course type value
	$("#courseType").trigger("change");
});

$(document).ready(function () {
	$.ajax({
		type: "POST",
		url: baseurl + "Department/get_department",
		success: function (response) {
			var responseData = JSON.parse(response);
			var dropdownOptions = { "": "Select Department" }; // Initial dropdown options
			// Loop through the response data and add each district to the dropdown options
			for (var i = 0; i < responseData.length; i++) {
				var DName = responseData[i];
				dropdownOptions[DName.DepartmentName] = DName.DepartmentName;
			}
			// Update the dropdown with the new options
			$("#Department_Name").empty(); // Clear existing options
			$.each(dropdownOptions, function (key, value) {
				$("#Department_Name").append(
					$("<option></option>").attr("value", key).text(value)
				);
			});
		},
		error: function (xhr, status, error) {
			// Handle error response here
			console.error(
				"Error occurred while sending selected value to the controller."
			);
		},
	});
});

$(document).ready(function () {
	var i = 1;
	$("#add").on("click", function () {
		const clonedElement = $(`
            <div>
                <br>
                <h2 style="display: flex; justify-content: center; font-size: 23px;">Education Details - ${i}</h2>
                <div class="row">
                    <div class="col-md-4">
                        <label for="Course_Type${i}" class="text-dark">Course Type</label>
                        <select name="Course_Type${i}" class="form-control" id="Course_Type${i}" required>
                            <option value="select">Select</option>
                            <option value="UG">UG</option>
                            <option value="PG">PG</option>
                        </select>
                    </div>
                    <div class="col-md-4" id="ug${i}">
                        <label for="UGDegree${i}" class="text-dark">Degree</label>
                        <input type="text" id="UGDegree${i}" name="UGDegree${i}" class="form-control" required>
                    </div>
                     <div class="col-md-4" id="ug${i}">
                        <label for="Passingyear${i}" class="text-dark">Passing Year</label>
                        <input type="text" id="Passingyear${i}" name="Passingyear${i}" class="form-control" required>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <label for="University_Name${i}" class="text-dark">University Name</label>
                        <input type="text" id="University_Name${i}" name="University_Name${i}" class="form-control" required>
                    </div>
                    <div class="col-md-4">
                        <label for="Institute${i}" class="text-dark">Institute</label>
                        <input type="text" id="Institute${i}" name="Institute${i}" class="form-control" required>
                    </div>
                    <div class="col-md-4">
                        <label for="Mode${i}" class="text-dark">Mode</label>
                        <select name="Mode${i}" class="form-control" id="CourseMode_Type${i}" required>
                            <option value="select">Select</option>
                            <option value="Regular">Regular</option>
                            <option value="Distance Education">Distance Education</option>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <label for="Percentage${i}" class="text-dark">Percentage</label>
                        <input type="text" id="Percentage${i}" name="Percentage${i}" class="form-control" required>
                    </div>
                    <div class="col-md-4">
                        <label for="Specializations${i}" class="text-dark">Specializations</label>
                        <input type="text" id="Specializations${i}" name="Specializations${i}" class="form-control" required>
                    </div>
                    
                </div>
            </div>
        `);

		// Append the modified cloned structure to the container
		$("#add_more").append(clonedElement);

		// Increment the counter for the next set of cloned elements
		i++;
	});
});

$(document).ready(function () {
	$.ajax({
		type: "POST",
		url: baseurl + "Department/get_instution",
		success: function (response) {
			var responseData = JSON.parse(response);
			var dropdownOptions = { "": "Select Instution" }; // Initial dropdown options
			// Loop through the response data and add each district to the dropdown options
			for (var i = 0; i < responseData.length; i++) {
				var IName = responseData[i];
				dropdownOptions[IName.InstutionName] = IName.InstutionName;
			}
			// Update the dropdown with the new options
			$("#Inst_name_1").empty(); // Clear existing options
			$.each(dropdownOptions, function (key, value) {
				$("#Inst_name_1").append(
					$("<option></option>").attr("value", key).text(value)
				);
			});
		},
		error: function (xhr, status, error) {
			// Handle error response here
			console.error(
				"Error occurred while sending selected value to the controller."
			);
		},
	});
});

$(document).ready(function () {
	$("#Inst_name_1").on("change", function () {
		var selectedValue = $(this).val(); // Get the selected value

		$.ajax({
			type: "POST",
			url: baseurl + "Department/Inst_Code",
			data: { selectedValue: selectedValue },
			dataType: "json",
			success: function (response) {
				var firstInstution = response[0];
				var icode = firstInstution.InstutionName_Code;
				$("#Inst_codes").val(icode);
			},

			error: function (xhr, status, error) {
				// Handle error response here
				console.error(
					"Error occurred while sending selected value to the controller."
				);
			},
		});
	});
});

$(document).ready(function () {
	$(document).on("change", "#Inst_name_1", function () {
		var InstutionName = $(this).val(); // Get the selected value

		$.ajax({
			type: "POST",
			url: baseurl + "Department/get_staff_depat",
			data: {
				InstutionName: InstutionName,
			},

			success: function (response) {
				var responseData = JSON.parse(response);
				var dropdownOptions = { "": "Select Department" }; // Initial dropdown options
				// Loop through the response data and add each district to the dropdown options
				for (var i = 0; i < responseData.length; i++) {
					var IName = responseData[i];
					dropdownOptions[IName.DepartmentName] = IName.DepartmentName;
				}
				// Update the dropdown with the new options
				$("#Staff_Department_Name").empty(); // Clear existing options
				$.each(dropdownOptions, function (key, value) {
					$("#Staff_Department_Name").append(
						$("<option></option>").attr("value", key).text(value)
					);
				});
			},
			error: function (xhr, status, error) {
				console.error(
					"Error occurred while sending selected value to the controller."
				);
			},
		});
	});
});

$(document).ready(function () {
	$("#InstutionName").on("change", function () {
		var InstutionName = $("#InstutionName").val();
		$("#Department_attendance").on("change", function () {
			var Department = $("#Department_attendance").val();
			$("#Staff_Type").on("change", function () {
				var Staff_Type = $("#Staff_Type").val();

				$.ajax({
					type: "POST",
					url: baseurl + "Staff/get_staff",
					data: {
						InstutionName: InstutionName,
						Department: Department,
						Staff_Type: Staff_Type,
					},
					success: function (response) {
						var responseData = JSON.parse(response);

						var Name = { "": "Select Staff" }; // Initial dropdown options
						var Staff_id = "";
						// Loop through the response data and add each district to the dropdown options
						for (var i = 0; i < responseData.length; i++) {
							var IName = responseData[i];
							Name[IName.Name] = IName.Name;
							Staff_id = IName.Staff_id;
						}
						// Update the dropdown with the new options
						$("#Staff_name").empty(); // Clear existing options
						$.each(Name, function (key, value) {
							$("#Staff_name").append(
								$("<option></option>").attr("value", key).text(value)
							);
						});

						$("#Staff_id").val(Staff_id);
					},

					error: function (xhr, status, error) {
						// Handle error response here
						console.error(
							"Error occurred while sending selected value to the controller."
						);
					},
				});
			});
		});
	});
});

$(document).ready(function () {
	$("#leaveType").on("change", function () {
		var leaveType = $(this).val();

		if (leaveType == "Permission") {
			var permission_date = `
                <label for="Permission_Date" class="text-dark">Permission Date</label>
                <input type="date" id="Permission_Date" name="Permission_Date" class="form-control">
                <span class="input-group" style="color:red;"><?php echo form_error('permission_date'); ?></span>
            `;

			var fromTimeHtml = `
                <label for="From_Time" class="text-dark">From Time</label>
                <input type="time" id="From_Time" name="From_Time" class="form-control" step="1800">
                <span class="input-group" style="color:red;"><?php echo form_error('From_Time'); ?></span>
            `;

			var toTimeHtml = `
                <label for="To_Time" class="text-dark">To Time</label>
                <input type="time" id="To_Time" name="To_Time" class="form-control" step="1800">
                <span class="input-group" style="color:red;"><?php echo form_error('To_Time'); ?></span>
            `;

			$("#Date").html(permission_date); // Set HTML content inside the #Permission_Date div
			$("#from").html(fromTimeHtml); // Set HTML content inside the #from div
			$("#to").html(toTimeHtml); // Set HTML content inside the #to div
		} else {
			var fromDateHtml = `
                <label for="From_date" class="text-dark">From Date</label>
                <input type="date" id="From_date" name="From_date" class="form-control">
                <span class="input-group" style="color:red;"><?php echo form_error('From_date'); ?></span>
            `;

			var toDateHtml = `
                <label for="To_date" class="text-dark">To Date</label>
                <input type="date" id="To_date" name="To_date" class="form-control">
                <span class="input-group" style="color:red;"><?php echo form_error('To_date'); ?></span>
            `;

			var apply_date = `

			 <label for="apply_date" class="text-dark">Apply Date</label>
			<input type="date" id="apply_date" name="apply_date" class="form-control">
			<span class="input-group" style="color:red;"><?php echo form_error('Religion'); ?></span>
			`;

			$("#Date").html(apply_date);
			$("#from").html(fromDateHtml); // Set HTML content inside the #from div
			$("#to").html(toDateHtml); // Set HTML content inside the #to div
		}
	});

	$("#apply_btn").on("click", function () {
		var InstutionName = $("#InstutionName").val();
		var Department_attendance = $("#Department_attendance").val();
		var Staff_Type = $("#Staff_Type").val();
		var Staff_name = $("#Staff_name").val();
		var leaveType = $("#leaveType").val();
		var Apply_date = $("#apply_date").val();
		var Permission_Date = $("#Permission_Date").val();
		var From_Date = $("#From_date").val();
		var To_Date = $("#To_date").val();
		var From_Time = $("#From_Time").val();
		var To_Time = $("#To_Time").val();
		var Discription = $("#Discription").val();
		var Staff_id = $("#Staff_id").val();

		$.ajax({
			type: "POST",
			url: baseurl + "Staff/add_privilege",
			data: {
				InstutionName: InstutionName,
				Department_attendance: Department_attendance,
				Staff_Type: Staff_Type,
				Staff_name: Staff_name,
				Staff_id: Staff_id,
				leaveType: leaveType,
				Permission_Date: Permission_Date,
				Apply_date: Apply_date,
				From_Date: From_Date,
				To_Date: To_Date,
				From_Time: From_Time,
				To_Time: To_Time,
				Discription: Discription,
			},
			success: function (response) {

				var responseData = JSON.parse(response);
				var responseData = JSON.parse(response);
				if (responseData == "1") {
					Swal.fire({
						title: "Good job!",
						text: "The permission or leave request has been successfully updated and approved for 1 hour",
						icon: "success",
						confirmButtonText: "OK",
					}).then((result) => {
						if (result.isConfirmed) {
							window.location.href = baseurl + "staff/privilege";
						}
					});
				}
			},
			error: function (xhr, status, error) {
				console.error(
					"Error occurred while sending selected value to the controller."
				);
				// Handle error case
			}
		})
	});
});

$(document).ready(function () {
    $("#approval_staff").hide();

    $("#get_request").on("click", function () {
        var InstutionName = $("#InstutionName").val();
        var Department_attendance = $("#Department_attendance").val();
        var Staff_Type = $("#Staff_Type").val();
        var Month = $("#Month").val();

        $.ajax({
            type: "POST",
            url: baseurl + "Staff/approvals",
            data: {
                InstutionName: InstutionName,
                Department_attendance: Department_attendance,
                Staff_Type: Staff_Type,
                Month: Month,
            },
            success: function (response) {
                var responseData = JSON.parse(response);

                $("#Staff_Approvals tbody").empty();

                // Append each row to the table
                $.each(responseData, function (index, item) {
                    var row = `<tr>
                        <td>${index + 1}</td>
                        <td>${item.InstitutionName}</td>
                        <td>${item.DepartmentName}</td>
                        <td>${item.Staff_Type}</td>
                        <td>${item.Staff_Id}</td>
                        <td>${item.Staff_Name}</td>
                        <td>${item.Leave_Type}</td>
                        <td>${item.Description}</td>
                        <td>${item.Month}</td>
                        <td>${item.ApplyDate}</td>
                        <td>${item.PermissionDate}</td>
                        <td>${item.From_Date}</td>
                        <td>${item.To_Date}</td>
                        <td>${item.From_Time}</td>
                        <td>${item.To_Time}</td>
                        <td style="text-align: center;">
                            ${item.Approval_Status == 0 ?
                                '<span class="badge bg-danger">Not Approved</span>' :
                                '<span class="badge bg-success">Approved</span>'}
                        </td>
                        <td style="text-align: center;">
                            <div id="staff_${item.Staff_Id}">
                                <span class="confirm-icon" data-staff-id="${item.Staff_Id}" style="color: green; font-size: 20px; cursor: pointer;">&#10004;</span>&nbsp;&nbsp;
                                <span class="cancel-icon" 
                                      data-staff-id="${item.Staff_Id}" 
                                      data-month="${item.Month}" 
                                      data-permission-date="${item.PermissionDate}" 
                                      data-apply-date="${item.ApplyDate}" 
                                      style="font-size: 15px; cursor: pointer;">&#10060;</span>
                            </div>
                        </td>
                    </tr>`;

                    $("#Staff_Approvals tbody").append(row);
                });

                // Event listener for confirm icons
                $(document).on("click", ".confirm-icon", function () {
                    var staffId = $(this).data("staff-id");

                    // Find the corresponding item in responseData array
                    var itemToConfirm = responseData.find(item => item.Staff_Id == staffId);

                    // Show SweetAlert confirmation dialog
                    Swal.fire({
                        title: "Are you sure?",
                        text: "You are about to confirm staff #" + staffId + ". Proceed?",
                        icon: "question",
                        showCancelButton: true,
                        confirmButtonText: "Confirm",
                        cancelButtonText: "Cancel",
                    }).then((result) => {
                        if (result.isConfirmed) {
                            // If confirmed, send staff ID and additional data to AJAX function
                            confirmStaff(itemToConfirm);
                        }
                    });
                });

                // Function to handle AJAX request to confirm staff
                function confirmStaff(item) {
                    var Approval_Status = 1;
                    $.ajax({
                        url: baseurl + "Staff/update_approval_status",
                        type: "POST",
                        data: {
                            staffId: item.Staff_Id,
                            Month: item.Month,
                            PermissionDate: item.PermissionDate,
                            ApplyDate: item.ApplyDate,
                            Approval_Status: Approval_Status,
                        },
                        success: function (response) {
							Swal.fire({
								title: "Confirmed!",
								text: "Staff #" + item.Staff_Id + " has been confirmed.",
								icon: "success",
								showCancelButton: false, // Remove cancel button
								confirmButtonText: "OK",
							}).then((result) => {
								if (result.isConfirmed) {
									location.reload(); // Reload the page
								}
							});
						},
                        error: function (xhr, status, error) {
                            Swal.fire(
                                "Error!",
                                "Failed to confirm staff #" + item.Staff_Id + ".",
                                "error"
                            );
                        },
                    });
                }

                // Event listener for cancel icons
                $(document).on("click", ".cancel-icon", function () {
                    var staffId = $(this).data("staff-id");
                    var month = $(this).data("month");
                    var permissionDate = $(this).data("permission-date");
                    var applyDate = $(this).data("apply-date");
                    var approvalStatus = -1; // Set the Approval_Status for cancellation

                    // AJAX request
                    $.ajax({
                        url: baseurl + "Staff/update_approval_status",
                        type: "POST",
                        data: {
                            staffId: staffId,
                            Month: month,
                            PermissionDate: permissionDate,
                            ApplyDate: applyDate,
                            Approval_Status: approvalStatus,
                        },
                        success: function (response) {
							// Show Swal notification with OK button and reload page on OK
							Swal.fire({
								title: "Cancelled",
								text: "You cancelled the action for staff #" + staffId,
								icon: "info",
								showCancelButton: false, // Remove cancel button
								confirmButtonText: "OK",
							}).then((result) => {
								if (result.isConfirmed) {
									location.reload(); // Reload the page
								}
							});
						},
                        error: function (xhr, status, error) {
                            Swal.fire(
                                "Error!",
                                "Failed to cancel the action for staff #" + staffId + ".",
                                "error"
                            );
                        },
                    });
                });

                $("#approval_staff").show(); // Show the approval_staff element after appending rows
            },
            error: function (xhr, status, error) {
                console.error("Error occurred while sending selected value to the controller.");
            },
        });
    });
});


$(document).ready(function () {

	$("#permissions_container").hide();

	$("#permisiion_status_btn").on("click",function(){

		var InstutionName = $("#InstutionName").val();
        var Department_attendance = $("#Department_attendance").val();
        var Staff_Type = $("#Staff_Type").val();
		var Staff_name = $("#Staff_name").val();
		var Staff_id = $("#Staff_id").val();
        var Month = $("#Month").val();
       

				$.ajax({
					type: "POST",
					url: baseurl + "Staff/permission_status",
					data: {
						InstutionName: InstutionName,
						Department_attendance: Department_attendance,
						Staff_Type: Staff_Type,
						Month: Month,
						Staff_name: Staff_name,
						Staff_id: Staff_id
					},
					success: function (response) {
						var responseData = JSON.parse(response);

						$("#permissions_container").show();
		
						$("#permissions_status_tbl tbody").empty();
		
						// Append each row to the table
						$.each(responseData, function (index, item) {
							var row = `<tr>
								<td>${index + 1}</td>
								<td>${item.InstitutionName}</td>
								<td>${item.DepartmentName}</td>
								<td>${item.Staff_Type}</td>
								<td>${item.Staff_Id}</td>
								<td>${item.Staff_Name}</td>
								<td>${item.Leave_Type}</td>
								<td>${item.Description}</td>
								<td>${item.Month}</td>
								<td>${item.ApplyDate}</td>
								<td>${item.PermissionDate}</td>
								<td>${item.From_Date}</td>
								<td>${item.To_Date}</td>
								<td>${item.From_Time}</td>
								<td>${item.To_Time}</td>
								<td style="text-align: center;">
									${item.Approval_Status == 0 ?
										'<span class="badge bg-danger">Not Approved</span>' :
										'<span class="badge bg-success">Approved</span>'}
								</td>
								
							</tr>`;
		
							$("#permissions_status_tbl tbody").append(row);
						});
					},
					error: function (xhr, status, error) {
						console.error("Error occurred while sending selected value to the controller.");
					},
				})
	})
});

$(document).ready(function () {
	$("#get_staff_list").on("click",function(){

		InstutionName = $("#InstutionName").val();
		Stafftype = $("#Staff_Type").val();

		$.ajax({
			type: "POST",
            url: baseurl + "Staff/get_staff_list",
            data: {
                InstutionName: InstutionName,
                Stafftype: Stafftype
            },
            success: function (response) {
                var responseData = JSON.parse(response);

				var data = responseData.get_staff_list;

				$("#Staff_list tbody").empty();
				// Sort the 'data' array by Department_Name alphabetically
					data.sort(function(a, b) {
						// Convert both Department_Name values to lowercase to ensure case-insensitive sorting
						var nameA = a.Department_Name.toLowerCase();
						var nameB = b.Department_Name.toLowerCase();

						// Compare
						if (nameA < nameB) {
							return -1;
						}
						if (nameA > nameB) {
							return 1;
						}
						return 0; // names must be equal
					});

					// Append each sorted row to the table
					$.each(data, function(index, item) {
						var row = `<tr>
						<td>${index + 1}</td>
						<td>${item.Department_Name}</td>
						<td>${item.Staff_id}</td>
						<td>${item.Name}</td>
						<td>${item.Staff_Type}</td>
						<td>${item.Position}</td>
						<td>${item.Mobile}</td>
						<td>
                        <a  id="View_Staff" data-id='${item.Staff_id}'><i class='fas fa-eye text-info'></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
 						<a  href="edit/${item.Staff_id}" id="Edit_Staff" data-id='${item.Staff_id}' <i class='fas fa-edit text-primary' ></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
						<a id="Delete_Staff"  data-id='${item.Staff_id}' <i class='fas fa-trash text-danger'></i></a>
					</td>	
					</tr>`;

						$("#Staff_list tbody").append(row);
					});

			},
		})

	})

})

// //VIEW

$(document).on("click", "#View_Staff", function(){
	var staff_id = $(this).data("id");

	$.ajax({
		type: "POST",
        url: baseurl + "Staff/view_staff",
        data: {
            staff_id: staff_id
        },
        success: function (response) {
            var responseData = JSON.parse(response);
			var data = responseData.view_staff;
			
            $("#staff_view_modal").modal("show");

			
            $("#view_staff_id").val(data.Staff_id);
			$("#view_name").val(data.Name);
			$("#view_position").val(data.Position);
			$("#view_mobile").val(data.Mobile);
			$("#view_email").val(data.Email);
			$("#view_department").val(data.Department_Name);
			$("#view_staff_type").val(data.Staff_Type);
			$("#Aadhar_Number").val(data.Aadhar_Number);
			$("#view_DOB").val(data.DOB);
			$("#view_Blood_Groupl").val(data.Blood_Group);
			$("#view_department").val(data.Department_Name);
			$("#view_Marital_Status").val(data.Marital_Status);
			$("#view_address").val(data.Address
			);
		    $("#view_image").attr("src", baseurl + "uploads/Staff_Profile/" + data.Profile);

        },
        error: function (xhr, status, error) {
		}
	

})

			// Close the modal when the close button is clicked
			$("#close_pop").on("click", function() {
				$("#staff_view_modal").modal("hide");

				});
})
   

$(document).ready(function() {
    // When a file is selected in the file input
    $('#upload_image').change(function() {
        var file = this.files[0];
        if (file) {
            var reader = new FileReader();
            reader.onload = function(e) {
                // Update the src attribute of the img element to show the new image
                $('#current_image').attr('src', e.target.result);
            }
            reader.readAsDataURL(file);
        }
    });
});
