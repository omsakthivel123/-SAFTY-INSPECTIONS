

$(document).ready(function() {
    
    $('#wizard-form3').submit(function(event) {

        event.preventDefault(); // Prevent default form submission

        // Serialize form data
        var formData = $(this).serialize();

        // AJAX request
        $.ajax({
            type: 'POST',
            url: baseurl+'Substitution/add_Staff3',
            data: formData,
            dataType: 'json', // Expect JSON response
            success: function(response) {

                var responseData = JSON.parse(response);

                console.log(responseData)

                if (response == 1) {
                    Swal.fire({
                        icon: "success",
                        title: "Success!",
                        text: "Successfully Staff Assigned!",
                    }).then((result) => {
                        if (result.isConfirmed) {
                            location.reload(); // Reload the page immediately after user confirms
                        }
                    });
                    event.preventDefault();
                } else if (response == 'true') {
                    Swal.fire({
                        icon: "error",
                        title: "Error!",
                        text: "Already This Staff Assigned!",
                    }).then((result) => {
                        if (result.isConfirmed) {
                            location.reload(); // Reload the page immediately after user confirms
                        }
                    });
                    event.preventDefault();
                }
                
            },
            error: function(xhr, status, error) {
                // Handle error
                console.error(xhr.responseText);
                // Optionally show error message
            }
        });
    });
});



$(document).ready(function () {

    var departmentName = $("#Department_name0012").val();
	$.ajax({
		type: "POST",
		url: baseurl + "Substitution/Course_type010",
        data: { department_name: departmentName },
		success: function (response) {
			var responseData = JSON.parse(response);
			var dropdownOptions = { "": "Select course_type" }; 
			// Loop through the response data and add each district to the dropdown options
			for (var i = 0; i < responseData.length; i++) {
				var IName = responseData[i];
				dropdownOptions[IName.CourseType] = IName.CourseType;
			}
			// Update the dropdown with the new options
			$("#Course_type01").empty(); // Clear existing options
			$.each(dropdownOptions, function (key, value) {
				$("#Course_type01").append(
					$("<option></option>").attr("value", key).text(value)
				);
			});
          
		},
		error: function (xhr, status, error) {
			// Handle error response here
			console.error(
				"Error occurred while sending selected value to the controller."
			);
		},
	});


});

$(document).ready(function() {
    // Event handler for when Course_type dropdown changes
    $('#Course_type01').on('change', function() {
        fetchCourses1();
    });

    // Function to fetch courses based on selected course type
    function fetchCourses1() {
        var departmentName = $("#Department_name0012").val(); // Move inside fetchCourses function
        var courseType = $('#Course_type01').val();

        $.ajax({
            type: "POST",
            url: baseurl + "Substitution/get_batch",
            data: {
                department_name: departmentName,
                courseType: courseType
            },
            success: function(response) {
                try {
                    var responseData = JSON.parse(response);
                    var dropdownOptions = { '': 'Select Batch' };

                    // Populate dropdownOptions with Batch options
                    responseData.forEach(function(subject) {
                        dropdownOptions[subject.Batch] = subject.Batch;
                    });

                    // Clear previous options and populate #Batch1 dropdown
                    $('#Batch01').empty();
                    $.each(dropdownOptions, function(key, value) {
                        $('#Batch01').append($("<option></option>").attr("value", key).text(value));
                    });
                } catch (e) {
                    console.error('Error parsing response: ' + e);
                }
            },
            error: function(xhr, status, error) {
                console.error('Error occurred while fetching batches: ' + error);
            }
        });
    }
});

$(document).ready(function() {
    $('#Course_type01 , #Batch01').on('change', function() {
        fetchCourses2();
    });

    function fetchCourses2() {
        var departmentName = $("#Department_name0012").val();
        var courseType = $('#Course_type01').val();
        var Batch = $('#Batch01').val();

        $.ajax({
            type: "POST",
            url: baseurl + "Substitution/get_Section",
            data: {
                department_name: departmentName,
                courseType: courseType,
                Batch: Batch
            },
            success: function(response) {
                try {
                    var responseData = JSON.parse(response);
                    var dropdownOptions = { '': 'Section' };
             

                    responseData.forEach(function(subject) {
                        dropdownOptions[subject.Section] = subject.Section;
           
                    });

                    $('#Section01').empty();
              

                    $.each(dropdownOptions, function(key, value) {
                        $('#Section01').append($("<option></option>").attr("value", key).text(value));
                    });

               
                } catch (e) {
                    console.error('Error parsing response: ' + e);
                }
            },
            error: function(xhr, status, error) {
                console.error('Error occurred while fetching subjects: ' + error);
            }
        });
    }
});



$(document).ready(function() {
    // Event handler for when Course_type dropdown changes
    $('#Course_type01').on('change', function() {
        fetchCourses3();
    });

    // Function to fetch courses based on selected course type
    function fetchCourses3() {
        var departmentName = $("#Department_name0012").val(); // Move inside fetchCourses function
        var courseType = $('#Course_type01').val();

        $.ajax({
            type: "POST",
            url: baseurl + "Substitution/get_course_code",
            data: {
                department_name: departmentName,
                courseType: courseType
            },
            success: function(response) {
                try {
                    var responseData = JSON.parse(response);
                    var dropdownOptions = { '': 'Select course_code' };

                    // Populate dropdownOptions with Batch options
                    responseData.forEach(function(subject) {
                        dropdownOptions[subject.CourseCode] = subject.CourseCode;
                    });

                    // Clear previous options and populate #Batch1 dropdown
                    $('#CourseCode01').empty();
                    $.each(dropdownOptions, function(key, value) {
                        $('#CourseCode01').append($("<option></option>").attr("value", key).text(value));
                    });
                } catch (e) {
                    console.error('Error parsing response: ' + e);
                }
            },
            error: function(xhr, status, error) {
                console.error('Error occurred while fetching batches: ' + error);
            }
        });
    }
});


$(document).ready(function() {

    var instname = $("#Institution_name2").val();
 
    $.ajax({
        type: "POST",
        url: baseurl + "Substitution/get_department",
        data: { instname: instname }, // Send institution name as data
        success: function(response) {
            var responseData = JSON.parse(response);
            var dropdownOptions = {'': 'Select Department'}; // Initial dropdown options

            // Loop through the response data and add each department to the dropdown options
            $.each(responseData, function(index, department) {
                dropdownOptions[department.DepartmentName] = department.DepartmentName;
            });

            // Update the dropdown with the new options
            $('#Department_name21').empty(); // Clear existing options
            $.each(dropdownOptions, function(key, value) {
                $('#Department_name21').append($("<option></option>").attr("value", key).text(value));
            });
        },
        error: function(xhr, status, error) {
            console.error('Error occurred while fetching departments.');
        }
    });
});


$(document).ready(function() {
    $('#Department_name21').on('change', function() {
        fetchStaff4(); // Call the function to fetch staff names when department changes
    });

    function fetchStaff4() {
        var departmentName = $("#Department_name21").val(); // Get the selected department name

        $.ajax({
            type: "POST",
            url: baseurl + "Substitution/get_staff1",
            data: { department_name1: departmentName }, // Send department name as data
            success: function(response) {
                try {
                    var responseData = JSON.parse(response);
                    var dropdownOptions = { '': 'Select Staff' }; // Initial dropdown option

                    // Loop through the response data and add each staff name to dropdown options
                    for (var i = 0; i < responseData.length; i++) {
                        var staff = responseData[i];
                        dropdownOptions[staff.Staff_id] = staff.Staff_id;

                    }  

                    // Update the dropdown with new options
                    $('#New_Staff_Id').empty(); // Clear existing options
                    $.each(dropdownOptions, function(key, value) {
                        $('#New_Staff_Id').append($("<option></option>").attr("value", key).text(value));
                    });
                } catch (e) {   
                    console.error('Error parsing response: ' + e);
                }
            },
            error: function(xhr, status, error) {
                console.error('Error occurred while fetching staff names: ' + error);
            }
        });
    }
});
