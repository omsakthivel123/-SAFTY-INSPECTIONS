$(document).ready(function () {
	$("#InstutionName").on("change", function () {
		var InstutionName = $("#InstutionName").val();
		$("#Course_type").on("change", function () {
			var Course_type = $("#Course_type").val();
			$("#DepartmentName").on("change", function () {
				var DepartmentName = $("#DepartmentName").val();
				$("#Course_name").on("change", function () {
					var Course_name = $("#Course_name").val();
					$("#Batch").on("change", function () {
						var Batch = $("#Batch").val();

						$.ajax({
							type: "POST",
							url: baseurl + "Subject/get_subject",
							data: {
								InstutionName: InstutionName,
								Course_type: Course_type,
								DepartmentName: DepartmentName,
								Course_name: Course_name,
								Batch: Batch,
							},
							success: function (response) {
								var responseData = JSON.parse(response);
								var Semester = { "": "Select Semester" }; // Initial dropdown options
								var Subject_code = { "": "Select Subject Code" }; // Initial dropdown options

								for (var i = 0; i < responseData.length; i++) {
									var DName = responseData[i];
									Semester[DName.Semester] = DName.Semester;
								}
								// Update the dropdown with the new options
								$("#Semesters").empty(); // Clear existing options
								$.each(Semester, function (key, value) {
									$("#Semesters").append(
										$("<option></option>").attr("value", key).text(value)
									);
								});

								$("#Subject_code").empty(); // Clear existing options
								$.each(Subject_code, function (key, value) {
									$("#Subject_code").append(
										$("<option></option>").attr("value", key).text(value)
									);
								});
							},
							error: function (xhr, status, error) {
								// Handle error response here
								console.error(
									"Error occurred while sending selected value to the controller."
								);
							},
						});
					});
				});
			});
		});
	});
});

$(document).ready(function () {
	$("#Batch").on("change", function () {
		var Batch = $("#Batch").val();
		$("#Semesters").on("change", function () {
			var Semesters = $("#Semesters").val();
			$.ajax({
				type: "POST",
				url: baseurl + "Subject/get_subject_code",
				data: {
					Semesters: Semesters,
					Batch: Batch,
				},
				success: function (response) {
					var responseData = JSON.parse(response);
					var Subjeccode = { "": "Select Subject Code" }; // Initial dropdown options
					// Loop through the response data and add each district to the dropdown options
					for (var i = 0; i < responseData.length; i++) {
						var DName = responseData[i];
						Subjeccode[DName.SubjectCode] = DName.SubjectCode;
					}
					// Update the dropdown with the new options
					$("#Subject_code").empty(); // Clear existing options
					$.each(Subjeccode, function (key, value) {
						$("#Subject_code").append(
							$("<option></option>").attr("value", key).text(value)
						);
					});
				},
				error: function (xhr, status, error) {
					// Handle error response here
					console.error(
						"Error occurred while sending selected value to the controller."
					);
				},
			});
		});
	});
});

$(document).ready(function () {
	$("#Subject_code").on("change", function () {
		var Subject_code = $("#Subject_code").val();
		$.ajax({
			type: "POST",
			url: baseurl + "Subject/selected_subjects",
			data: {
				Subject_code: Subject_code,
			},
			success: function (response) {
				var responseData = JSON.parse(response);
				var SubjectName = { "": "Select Subject" }; // Initial dropdown options
				// Loop through the response data and add each district to the dropdown options
				for (var i = 0; i < responseData.length; i++) {
					var DName = responseData[i];
					SubjectName[DName.SubjectName] = DName.SubjectName;
				}
				// Update the dropdown with the new options
				$("#Subject_name").empty(); // Clear existing options
				$.each(SubjectName, function (key, value) {
					$("#Subject_name").append(
						$("<option></option>").attr("value", key).text(value)
					);
				});
				// Select the first option
				$("#Subject_name option:last").prop("selected", true);
			},
			error: function (xhr, status, error) {
				// Handle error response here
				console.error(
					"Error occurred while sending selected value to the controller."
				);
			},
		});
	});
});

$(document).ready(function () {

	$("#subject").hide();

	$("#get_subjects_for_assign").on("click", function () {
		// Clear previous content in the table before making the AJAX call

		var InstutionName = $("#InstutionName").val();
		var Course_type = $("#Course_type").val();
		var DepartmentName = $("#DepartmentName").val();
		var Course_name = $("#Course_name").val();
		var Batch = $("#Batch").val();
		var Semesters = $("#Semesters").val();

		$.ajax({
			type: "POST",
			url: baseurl + "Subject/assign_subject",
			data: {
				InstutionName: InstutionName,
				Course_type: Course_type,
				DepartmentName: DepartmentName,
				Course_name: Course_name,
				Batch: Batch,
				Semesters: Semesters,
			},
			success: function (response) {
				var responseData = JSON.parse(response);
				$.each(responseData, function (index, item) {
					
					$("#subject").show();

					// <td>${item.InstutionName}</td>
					// <td>${item.CourseType}</td>
					// <td>${item.DepartmentName}</td>

					var row = `<tr>
                            <td>${index + 1}</td>

                            <td>${item.CourseName}</td>
                            <td>${item.Batch}</td>
                            <td>${item.Semesters}</td>
                            <td>${item.SubjectCode}</td>
                            <td>${item.SubjectName}</td>
                            <td>${item.Category}</td>
                            <td>${item.Credits}</td>
                            <td>${item.QualifyingGrade}</td>
                            <td>${item.CreatedBy}</td>
                        </tr>`;
					$("#assign_subject_list").append(row);
				});
			},
			error: function (xhr, status, error) {
				// Handle error response here
				console.error(
					"Error occurred while sending selected value to the controller."
				);
			},
		});
	});
});

$(document).ready(function () {
	$("#DepartmentName").on("change", function () {
		var DepartmentName = $("#DepartmentName").val();
		$.ajax({
			type: "POST",
			url: baseurl + "Subject/staff",
			data: {
				DepartmentName: DepartmentName,
			},
			success: function (response) {
				var responseData = JSON.parse(response);
				var Mentor = { "": "Select Mentor" }; // Initial dropdown options
				// Loop through the response data and add each district to the dropdown options
				for (var i = 0; i < responseData.length; i++) {
					var DName = responseData[i];
					Mentor[DName.Name] = DName.Name;
				}
				// Update the dropdown with the new options
				$("#course_monter").empty(); // Clear existing options
				$.each(Mentor, function (key, value) {
					$("#course_monter").append(
						$("<option></option>").attr("value", key).text(value)
					);
				});
			},
			error: function (xhr, status, error) {
				// Handle error response here
				console.error(
					"Error occurred while sending selected value to the controller."
				);
			},
		});
	});
});

// subject report

$(document).ready(function () {
	$("#subject").hide(); // Hide the report table initially

	$("#get_subjects_for_assign").on("click", function () {
		var institutionName = $("#InstutionName").val();
		var courseType = $("#Course_type").val();
		var departmentName = $("#DepartmentName").val();
		var courseName = $("#Course_name").val();
		var batch = $("#Batch").val();
		var semester = $("#Semesters").val();

		$.ajax({
			type: "POST",
			url: baseurl + "Subject/Get_Subject_report ",
			data: {
				InstitutionName: institutionName,
				Course_type: courseType,
				Department_Name: departmentName,
				Course_name: courseName,
				Batch: batch,
				Semesters: semester,
			},
			success: function (response) {
				try {
					var responseData = JSON.parse(response);
					$("#assign_subject_list").empty(); // Clear existing table rows
					$("#subject").show(); // Show the table

					$.each(responseData.reports, function (index, item) {
						var row = `<tr>
                                <td>${index + 1}</td>
                                <td>${item.institution_name}</td>
                                <td>${item.course_type}</td>
                                <td>${item.department_name}</td>
                                <td>${item.course_name}</td>
                                <td>${item.batch}</td>
                                <td>${item.semester}</td>
                                <td>${item.subject_code}</td>
                                <td>${item.subject_name}</td>
                                <td>${item.category}</td>
                                <td>${item.credits}</td>
                                <td>${item.qualifying_grade}</td>
                                <td>${item.created_by}</td>
                            </tr>`;

						$("#assign_subject_list").append(row);
					});
				} catch (error) {
					console.error("Error parsing response:", error);
				}
			},
			error: function (xhr, status, error) {
				console.error("AJAX request failed:", status, error);
				// Optionally handle error display to the user
			},
		});
	});

	$("#download-button").click(function () {
		var a = $("#InstutionName").val();
		var b = $("#Course_type").val();
		var c = $("#DepartmentName").val();
		var d = $("#Course_name").val();
		var e = $("#Batch").val();
		var f = $("#Semesters").val();
		$("#data1").val(a);
		$("#data2").val(b);
		$("#data3").val(c);
		$("#data4").val(d);
		$("#data5").val(e);
		$("#data6").val(f);
		$("#download-form").submit();
	});
});

$(document).ready(function () {
	$("#course_mentor1").hide();
	// Hide the report table initially

	$("#get_mentor_for_assign").on("click", function () {
		var institutionName = $("#InstutionName").val();
		var courseType = $("#Course_type").val();
		var departmentName = $("#DepartmentName").val();
		var courseName = $("#Course_name").val();
		var batch = $("#Batch").val();
		var semester = $("#Semesters").val();
		var section = $("#Section").val();
		// alert("thugji");
		$.ajax({
			type: "POST",
			url: baseurl + "Subject/Get_Mentor_report",
			data: {
				InstitutionName: institutionName,
				Course_type: courseType,
				Department_Name: departmentName,
				Course_name: courseName,
				Batch: batch,
				Semesters: semester,
				Section: section,
			},
			success: function (response) {
				try {
					var responseData = JSON.parse(response);
					$("#Add_mentor").empty(); // Clear existing table rows

					$.each(responseData.reports, function (index, item) {
						var row = `<tr>
                                <td>${index + 1}</td>
                                <td>${item.InstutionName}</td>
                                <td>${item.CourseType}</td>
                                <td>${item.DepartmentName}</td>
                                <td>${item.CourseName}</td>
                                <td>${item.Batch}</td>
                                <td>${item.Semester}</td>
                                <td>${item.Section}</td>
                                <td>${item.SubjectCode}</td>
                                <td>${item.SubjectName}</td>
                                <td>${item.Category}</td>
                                <td>${item.Credits}</td>
                                <td>${item.QualifyingGrade}</td>
                                <td>${item.CourseMentor}</td>
                                <td>${item.Status}</td>
                                <td>${item.CreatedBy}</td>
                            </tr>`;
						$("#Add_mentor").append(row);
					});

					$("#course_mentor1").show(); // Show the mentor table after populating data
				} catch (error) {
					console.error("Error parsing response:", error);
				}
			},
			error: function (xhr, status, error) {
				console.error("AJAX Error:", error);
			},
		});
	});
});
