$(document).ready(function () {
	$.ajax({
		type: "POST",
		url: baseurl + "Department/get_instution",
		success: function (response) {
			var responseData = JSON.parse(response);
			var dropdownOptions = { "": "Select Instution" }; // Initial dropdown options

			// Loop through the response data and add each district to the dropdown options
			for (var i = 0; i < responseData.length; i++) {
				var IName = responseData[i];
				dropdownOptions[IName.InstutionName] = IName.InstutionName;
			}

			// Update the dropdown with the new options
			$("#InstutionName").empty(); // Clear existing options
			$.each(dropdownOptions, function (key, value) {
				$("#InstutionName").append(
					$("<option></option>").attr("value", key).text(value)
				);
			});
		},
		error: function (xhr, status, error) {
			// Handle error response here
			console.error(
				"Error occurred while sending selected value to the controller."
			);
		},
	});
});

$(document).ready(function () {
	$("#InstutionName").on("change", function () {
		var selectedValue = $("#InstutionName").val();
		$.ajax({
			type: "POST",
			url: baseurl + "Department/get_departments",
			data: { selectedValue: selectedValue },
			success: function (response) {
				var responseData = JSON.parse(response);
				var dropdownOptions = { "": "Select Department" }; // Initial dropdown options
				var instcode = {};
				// Loop through the response data and add each district to the dropdown options
				for (var i = 0; i < responseData.length; i++) {
					var DepartName = responseData[i];
					dropdownOptions[DepartName.DepartmentName] =
						DepartName.DepartmentName;
				}

				// Update the dropdown with the new options
				$("#Department_attendance").empty(); // Clear existing options
				$.each(dropdownOptions, function (key, value) {
					$("#Department_attendance").append(
						$("<option></option>").attr("value", key).text(value)
					);
				});
			},
			error: function (xhr, status, error) {
				// Handle error response here
				console.error(
					"Error occurred while sending selected value to the controller."
				);
			},
		});
	});
});


$(document).ready(function () {
    $("#table-attendance").hide();
    let attendanceLog = []; // Array to store attendance log entries

    // Function to fetch data based on institution, department, and staff type
    function fetchData(institution, department, staffType) {
        $.ajax({
            type: "POST",
            url: baseurl + "Staff_Attendance/get_list",
            data: {
                InstitutionName: institution,
                Department_attendance: department,
                Staff_Type: staffType
            },
            success: function (response) {
                $("#table-attendance").show();
                try {
                    let responseData = JSON.parse(response);

                    let get_list = responseData.get_list;
                    let get_staff_Check = responseData.get_staff_Check;

                    $("#table-attendance tbody").empty();

                    let currentDate = new Date();
                    let currentMonth = currentDate.getMonth();
                    let currentYear = currentDate.getFullYear();
                    let currentDay = currentDate.getDate();

                    let daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();

                    let headers = "<tr><th>sno</th><th>staff_id</th><th>staff_name</th><th>month</th>";

                    // Add headers for each day of the month
                    for (let day = 1; day <= daysInMonth; day++) {
                        headers += `<th>DAY_${day}</th>`;
                    }

                    // Add additional headers (total present, total absent, management leaves, government leaves)
                    headers += "<th>Total Present</th><th>Total Absent</th></tr>";

                    $("#table-attendance thead").html(headers);

                    // Loop through each staff member
                    $.each(get_list, function (index, item) {
                        let row = `<tr data-staff-id="${item.Staff_id}" data-staff-name="${item.Name}">
                            <td>${index + 1}</td>
                            <td>${item.Staff_id}</td>
                            <td>${item.Name}</td>
                            <td>${(currentMonth + 1).toString().padStart(2, "0")}/${currentYear}</td>`;

                        let presentCount = 0;
                        let absentCount = 0;

                        // Find the corresponding attendance record for the current staff member
                        let staffAttendance = get_staff_Check.find((record) => record.Staff_Id === item.Staff_id);

                        // If no attendance record is found, log an error or handle as needed
                        if (!staffAttendance) {
                            console.error(`No attendance record found for staff ID ${item.Staff_id}`);
                            return; // Skip to the next staff member
                        }

                        // Loop through each day of the month
                        for (let day = 1; day <= daysInMonth; day++) {
                            let isChecked = staffAttendance && staffAttendance[`DAY_${day}`] === "1";
                            let attendanceStatus = isChecked
                                ? `<button type='button' class='status-button present' style='background: none; border: none;' data-status='1' data-staff-id='${item.Staff_id}' data-date='${(currentMonth + 1).toString().padStart(2, "0")}/${day.toString().padStart(2, "0")}/${currentYear}'><span style='color: green; font-size: 15px;'>&#10004;</span></button>`
                                : `<button type='button' class='status-button absent' style='background: none; border: none;' data-status='0' data-staff-id='${item.Staff_id}' data-date='${(currentMonth + 1).toString().padStart(2, "0")}/${day.toString().padStart(2, "0")}/${currentYear}'><span style='font-size: 12px;'>&#10060;</span></button>`;

                            let cellContent = day === currentDay
                                ? `<div style="display: flex; justify-content: center; align-items: center; flex-direction: column;">
                                        <div class="attendance-buttons" style="display: flex; justify-content: center; align-items: center; margin-bottom: 10px;">
                                            <button type="button" class="status-button" style="background: none; border: none; padding: 0;" data-status="1" data-staff-id="${item.Staff_id}" data-date="${(currentMonth + 1).toString().padStart(2, "0")}/${day.toString().padStart(2, "0")}/${currentYear}">
                                                <span style="color: green; font-size: 20px;">&#10004;</span>
                                            </button>
                                            <button type="button" class="status-button" style="background: none; border: none; padding: 0; margin-left: 10px;" data-status="0" data-staff-id="${item.Staff_id}" data-date="${(currentMonth + 1).toString().padStart(2, "0")}/${day.toString().padStart(2, "0")}/${currentYear}">
                                                <span style="font-size: 15px;">&#10060;</span>
                                            </button>
                                        </div>
                                        <div class="value-box" style="width: 10px;"></div>
                                        <div class="current-date-message">${isChecked ? "Present" : "Absent"}</div>
                                    </div>`
                                : (staffAttendance && staffAttendance[`DAY_${day}`] === "-5")
                                    ? `<div style="background-color: #f0f0f0; height: 100%; width: 100%;"></div>` // Set background color for -5 case
                                    : attendanceStatus;

                            row += `<td class='' data-header-name='DAY_${day}'>${cellContent}</td>`;

                            if (isChecked) {
                                presentCount++;
                            } else if (!isChecked && staffAttendance && staffAttendance[`DAY_${day}`] !== "-5") {
                                absentCount++;
                            }
                        }

                        // Append additional columns for total present, total absent, management leaves, government leaves
                        row += `<td><input type='text' class='present-count' value='${presentCount}'></td>
                                <td><input type='text' class='absent-count' value='${absentCount}'></td>
                               </tr>`;

                        // Append the constructed row to the table body
                        $("#table-attendance tbody").append(row);
                    });
                } catch (error) {
                    console.error("Error parsing response:", error);
                }
            },
            error: function (xhr, status, error) {
                console.error("AJAX Error:", status, error);
            },
        });
    }

    // Event handler for Institution dropdown change
    $("#InstutionName").on("change", function () {
        let institution = $(this).val();

        // Event handler for Staff Type dropdown change
        $("#Staff_Type").on("change", function () {
            let staffType = $("#Staff_Type").val();

            // Event handler for Department dropdown change
            $("#Department_attendance").on("change", function () {
                let department = $(this).val();
                fetchData(institution, department, staffType); // Fetch data when all dropdowns are selected
            }).trigger("change"); // Trigger change event initially
        });
    });

    // Delegated click event handler for buttons with class 'status-button'
    $(document).on("click", ".status-button", function () {
        let $button = $(this);
        let status = $button.data("status");
        let $td = $button.closest("td");
        let $row = $button.closest("tr");

        let $presentCountInput = $row.find(".present-count");
        let $absentCountInput = $row.find(".absent-count");
        
        // Retrieve presentCount and absentCount values
        let presentCount = parseInt($presentCountInput.val());
        let absentCount = parseInt($absentCountInput.val());

        // Check if the clicked button is within the total rows section
        if ($td.find(".present-count").length > 0 ||
            $td.find(".absent-count").length > 0 ||
            $td.find(".management-leaves").length > 0 ||
            $td.find(".government-leaves").length > 0) {
            // This is a total row, do not log attendance change
            return;
        }

        let rowData = {}; // Object to store row data

        // Retrieve specific data from the clicked row
        rowData.staffId = $row.data("staff-id");
        rowData.staffName = $row.data("staff-name");
        rowData.date = $button.data("date");
        rowData.status = status;
        rowData.institution = $("#InstutionName").val();
        rowData.department = $("#Department_attendance").val();
        rowData.staffType = $("#Staff_Type").val();
        rowData.presentCount = presentCount; // Assign presentCount to rowData
        rowData.absentCount = absentCount; // Assign absentCount to rowData

        // Retrieve header name associated with the clicked button
        let headerName = $td.data("header-name");
        rowData.headerName = headerName;

        // Update presentCount and absentCount based on status
        if (status == "1") {
            presentCount++;
            absentCount--;
        } else {
            presentCount--;
            absentCount++;
        }
        rowData.presentCount = presentCount;
        rowData.absentCount = absentCount;

        // Push rowData object into attendanceLog
        attendanceLog.push(rowData);

        console.log("Attendance Log:", attendanceLog);

        // Update the value-box with the status symbol
        let $valueBox = $td.find(".value-box");
        if ($valueBox.length > 0) {
            $valueBox.html(
                status == "1"
                    ? '<span style="border: 1px solid green; padding: 5px;">P</span>'
                    : '<span style="border: 1px solid red; padding: 5px;">A</span>'
            );
        }

        // Update present and absent counts in the table
        $presentCountInput.val(presentCount);
        $absentCountInput.val(absentCount);
    });

    // Event handler for clicking on table headers
    $(document).on("click", "#table-attendance th", function () {
        let headerName = $(this).text().trim(); // Get the text content of the clicked header

        // Store header name in attendanceLog array
        attendanceLog.push({
            headerName: headerName,
        });

        console.log("Attendance Log:", attendanceLog);

        // Send AJAX request with the headerName included
        $.ajax({
            type: "POST",
            url: baseurl + "Staff_Attendance/update_header_log",
            contentType: "application/json",
            data: JSON.stringify({ headerName: headerName }), // Assuming backend expects JSON data
            success: function (response) {
                console.log("Header log updated successfully.");
            },
            error: function (xhr, status, error) {
                console.error("AJAX Error:", status, error);
            },
        });
    });

    // Event handler for update attendance button click
    $("#update_addendance").on("click", function () {
        if (attendanceLog.length === 0) {
            console.log("Attendance log is empty.");
            return;
        }

        // Extract staffId, staffName, date, status, institution, department from attendanceLog
        let dataToSend = attendanceLog.map(function (logEntry) {
            return {
                staffId: logEntry.staffId,
                staffName: logEntry.staffName,
                date: logEntry.date,
                status: logEntry.status,
                institution: logEntry.institution,
                department: logEntry.department,
                headerName: logEntry.headerName, // Include headerName in the data to send
                staffType: logEntry.staffType,
                presentCount: logEntry.presentCount,
                absentCount: logEntry.absentCount
            };
        });

        // Send all entries in attendanceLog as a single array in AJAX request
        $.ajax({
            type: "POST",
            url: baseurl + "Staff_Attendance/update",
            contentType: "application/json",
            data: JSON.stringify(dataToSend),
            success: function (response) {
                console.log(response);
                var responseData = JSON.parse(response);
                if (responseData === "Updated") {
                    Swal.fire({
                        title: "Good job!",
                        text: "Attendance for the current day and onwards has been successfully updated.",
                        icon: "success",
                        confirmButtonText: "OK",
                    }).then((result) => {
                        if (result.isConfirmed) {
                            window.location.href = baseurl + "Staff_Attendance";
                        }
                    });
                } else {
                    Swal.fire({
                        title: "Oops!",
                        text: "Failed to update attendance for the current day and onwards.",
                        icon: "error",
                        confirmButtonText: "OK",
                    }).then((result) => {
                        if (result.isConfirmed) {
                            window.location.href = baseurl + "Staff_Attendance";
                        }
                    });
                }
            },
            error: function (xhr, status, error) {
                console.error("AJAX Error:", status, error);
            },
        });

        // Clear the attendance log after updating
        attendanceLog = [];
        console.log("Attendance log cleared.");
    });

});




$(document).ready(function () {

	$("#get_satff_list").on("click" ,function (){

		var InstitutionName = $("#InstutionName");
		var Department = $("#Department_attendance");
		var StaffType  = $("#Staff_Type");
		var select_date =$("#select_date");

		$.ajax({
			type: "POST",
			url: baseurl + "Staff_Attendance/get_staff_list",
			
			data: {

				InstitutionName : InstitutionName.val(),
                Department : Department.val(),
                StaffType : StaffType.val(),
				select_date : select_date.val()

			}, 


			success: function (response) {

				var responseData = JSON.parse(response);

				var present = responseData.get_present.length;
				var absent = responseData.get_absent.length;
				var permission = responseData.get_permission.length;

				$("#present").text(present);
				$("#absent").text(absent);
				$("#permission").text(permission);
				
			
			},
			error: function (xhr, status, error) {
				console.error("AJAX Error:", status, error);
			},
		});


	})

})


$(document).ready(function () {
	$('#Staff-view1').hide();
	
    // alert("ehfid");
	$("#get_aten_list1").on("click", function () {
		var InstitutionName = $("#Institute_name").val();
		var Department = $("#Department_type1").val();
		var Staff_Type = $("#Staff_type").val();
		var date_1 = $("#date_1").val();
	
		$.ajax({       
			type: "POST",
			url: baseurl + "Staff_Attendance/get_atten_staff",
			data: {
				InstitutionName: InstitutionName,
				Department: Department,
				Staff_Type: Staff_Type,
				date_1: date_1,
			},
			success: function (response) {
				// alert(response);
				
				try {
					var responseData = JSON.parse(response);
	
					var present = responseData.get_present;
					var absent = responseData.get_absent;
					var permission = responseData.get_permission;
					var od = responseData.get_od;
	
					$('#present').text(present);
					$('#absent').text(absent);
					$('#permission').text(permission);
					$('#od').text(od);
	
					$('#Atten_stud1').empty(); // Clear existing table rows
	
					$.each(responseData.get_atten_students, function(index, item) {
						$('#Staff-view1').show();
						
						var row = `<tr>
							<td>${index + 1}</td>
							<td>${item.Staff_Id}</td>
							<td>${item.Staff_Name}</td>
							<td>${item.DepartmentName}</td>
							<td>${item.Staff_Type}</td>`;
	
						// Loop through days (1 to 31)
						for (let day = 1; day <= 31; day++) {
							let dayKey = `DAY_${day}`;
							let dayValue = item[dayKey] !== undefined ? item[dayKey] : '';
							// Convert '0' to 'L' and '1' to 'P'
							if (dayValue === '0') {
								dayValue = 'L';
							} else if (dayValue === '1') {
								dayValue = 'P';
							}
							row += `<td>${escapeHtml(dayValue)}</td>`;
						}
	
						row += `<td>${item.Total_Present}</td>
							<td>${item.Total_Absent}</td>
						</tr>`;
						
						$('#Atten_stud1').append(row);
					});
				} catch (error) {
					console.error("Error parsing response:", error);
				}
			},
			error: function (xhr, status, error) {
				console.error("AJAX request failed:", status, error);
				// Optionally handle error display to the user
			}
		});
	});
	
	// Function to escape HTML characters
	function escapeHtml(unsafe) {
		return typeof unsafe === 'string'
			? unsafe.replace(/[&<"']/g, function(m) {
				switch (m) {
					case '&':
						return '&amp;';
					case '<':
						return '&lt;';
					case '"':
						return '&quot;';
					case "'":
						return '&#39;';
					default:
						return m;
				}
			})
			: unsafe;
	}
});


$(document).ready(function () {
    $('#Staff-view2').hide();
    
    $("#Staff_details").on("click", function () {
        var InstitutionName = $("#Inst_name_1").val();
        var Inst_codes = $("#Inst_codes").val();
        var Department_Name = $("#Department_Name11").val();
    
        $.ajax({       
            type: "POST",
            url: baseurl + "Staff/get_staffs",
            data: {
                InstitutionName: InstitutionName,
                Inst_codes: Inst_codes,
                Department_Name: Department_Name,
            },
            success: function (response) {
                try {
                    var responseData = JSON.parse(response);
            
                    $('#Staff_detail1').empty(); // Clear existing table rows
                    $.each(responseData.reports, function(index, item) {
            
                        $('#Staff-view2').show();
                        
                        var row = `<tr>
                            <td>${index + 1}</td>
                            <td>${escapeHtml(item.InstutionCode)}</td>
                            <td>${escapeHtml(item.InstutionName)}</td>
                            <td>${escapeHtml(item.Staff_Type)}</td>
                            <td>${escapeHtml(item.Staff_id)}</td>
                            <td>${escapeHtml(item.Title)}</td>
                            <td>${escapeHtml(item.Gender)}</td>
                            <td>${escapeHtml(item.Initial)}</td>
                            <td>${escapeHtml(item.Name)}</td>
                            <td>${escapeHtml(item.DOB)}</td>
                            <td>${escapeHtml(item.Blood_Group)}</td>
                            <td>${escapeHtml(item.Place_Of_Birth)}</td>
                            <td>${escapeHtml(item.Marital_Status)}</td>
                            <td>${escapeHtml(item.Religion)}</td>
                            <td>${escapeHtml(item.Physical_Disability)}</td>
                            <td>${escapeHtml(item.Community)}</td>
                            <td>${escapeHtml(item.Caste)}</td>
                            <td>${escapeHtml(item.Mobile)}</td>
                            <td>${escapeHtml(item.Email)}</td>
                            <td>${escapeHtml(item.Aadhar_Number)}</td>
                            <td>${escapeHtml(item.Mother_Tongue)}</td>
                            <td>${escapeHtml(item.Language)}</td>
                            <td>${escapeHtml(item.IFSC)}</td>
                            <td>${escapeHtml(item.Bank_name)}</td>
                            <td>${escapeHtml(item.Bank_address)}</td>
                            <td>${escapeHtml(item.MICR_No)}</td>
                            <td>${escapeHtml(item.Account_No)}</td>
                            <td>${escapeHtml(item.PAN_Card)}</td>
                            <td>${escapeHtml(item.Address)}</td>
                            <td>${escapeHtml(item.Address_1)}</td>
                            <td>${escapeHtml(item.postal_Code)}</td>
                            <td>${escapeHtml(item.Post_Office_Name)}</td>
                            <td>${escapeHtml(item.District)}</td>
                            <td>${escapeHtml(item.Department_Name)}</td>
                            <td>${escapeHtml(item.Course_Type)}</td>
                            <td>${escapeHtml(item.Degree)}</td>
                            <td>${escapeHtml(item.Passing_Year)}</td>
                            <td>${escapeHtml(item.University_Name)}</td>
                            <td>${escapeHtml(item.Instiute)}</td>
                            <td>${escapeHtml(item.CourseMode_Type)}</td>
                            <td>${escapeHtml(item.Percentace)}</td>
                            <td>${escapeHtml(item.Specialization)}</td>
                            <td>${escapeHtml(item.Course_Type1)}</td>
                            <td>${escapeHtml(item.Degree1)}</td>
                            <td>${escapeHtml(item.Passing_Year1)}</td>
                            <td>${escapeHtml(item.University_Name1)}</td>
                            <td>${escapeHtml(item.Instiute1)}</td>
                            <td>${escapeHtml(item.CourseMode_Type1)}</td>
                            <td>${escapeHtml(item.Percentace1)}</td>
                            <td>${escapeHtml(item.Specialization1)}</td>
                            <td>${escapeHtml(item.Course_Type2)}</td>
                            <td>${escapeHtml(item.Degree2)}</td>
                            <td>${escapeHtml(item.Passing_Year2)}</td>
                            <td>${escapeHtml(item.University_Name2)}</td>
                            <td>${escapeHtml(item.Instiute2)}</td>
                            <td>${escapeHtml(item.CourseMode_Type2)}</td>
                            <td>${escapeHtml(item.Percentace2)}</td>
                            <td>${escapeHtml(item.Specialization2)}</td>
                            <td>${escapeHtml(item.Course_Type3)}</td>
                            <td>${escapeHtml(item.Degree3)}</td>
                            <td>${escapeHtml(item.Passing_Year3)}</td>
                            <td>${escapeHtml(item.University_Name3)}</td>
                            <td>${escapeHtml(item.Instiute3)}</td>
                            <td>${escapeHtml(item.CourseMode_Type3)}</td>
                            <td>${escapeHtml(item.Percentace3)}</td>
                            <td>${escapeHtml(item.Specialization3)}</td>
                            <td>${escapeHtml(item.Course_Type4)}</td>
                            <td>${escapeHtml(item.Degree4)}</td>
                            <td>${escapeHtml(item.Passing_Year4)}</td>
                            <td>${escapeHtml(item.University_Name4)}</td>
                            <td>${escapeHtml(item.Instiute4)}</td>
                            <td>${escapeHtml(item.CourseMode_Type4)}</td>
                            <td>${escapeHtml(item.Percentace4)}</td>
                            <td>${escapeHtml(item.Specialization4)}</td>
                            <td>${escapeHtml(item.Course_Type5)}</td>
                            <td>${escapeHtml(item.Degree5)}</td>
                            <td>${escapeHtml(item.Passing_Year5)}</td>
                            <td>${escapeHtml(item.University_Name5)}</td>
                            <td>${escapeHtml(item.Instiute5)}</td>
                            <td>${escapeHtml(item.CourseMode_Type5)}</td>
                            <td>${escapeHtml(item.Percentace5)}</td>
                            <td>${escapeHtml(item.Specialization5)}</td>
                            <td>${escapeHtml(item.Course_Type6)}</td>
                            <td>${escapeHtml(item.Degree6)}</td>
                            <td>${escapeHtml(item.Passing_Year6)}</td>
                            <td>${escapeHtml(item.University_Name6)}</td>
                            <td>${escapeHtml(item.Instiute6)}</td>
                            <td>${escapeHtml(item.CourseMode_Type6)}</td>
                            <td>${escapeHtml(item.Percentace6)}</td>
                            <td>${escapeHtml(item.Specialization6)}</td>
                        </tr>`;
                        
                        $('#Staff_detail1').append(row);
                    });
                } catch (error) {
                    console.error("Error parsing response:", error);
                }
            },
            error: function (xhr, status, error) {
                console.error("AJAX request failed:", status, error);
                // Optionally handle error display to the user
            }
        });
    });
    
    // Function to escape HTML characters
    function escapeHtml(unsafe) {
        return typeof unsafe === 'string'
            ? unsafe.replace(/[&<"']/g, function(m) {
                switch (m) {
                    case '&':
                        return '&amp;';
                    case '<':
                        return '&lt;';
                    case '"':
                        return '&quot;';
                    case "'":
                        return '&#39;';
                    default:
                        return m;
                }
            })
            : unsafe;
    }
});

$(document).ready(function(){
    $("#get_month_details").on("click",function(){
       var InstutionName = $("#InstutionName").val();
       var Staff_Type = $("#Staff_Types").val();
       var Year = $("#FinYear").val();
       var Month = $("#Month").val();

       $.ajax({
            type: "POST",
            url: baseurl + "Staff_Attendance/get_month_attendance",
            data:{
                InstutionName : InstutionName,
                Staff_Type : Staff_Type,
                Year : Year,
                Month : Month
            },
            success: function (response) {

                var responseData = JSON.parse(response);
                $.each(responseData.get_month_attendance, function(index, item) {

                    // Function to determine display value for each day
                    function getDayDisplayValue(value) {
                        if (value == 1) {
                            return 'PR'; // Present
                        } else if (value == 0) {
                            return 'AB'; // Absent
                        } else if (value == -5) {
                            return 'WH'; // Empty for -5
                        } else {
                            return value; // Use the value as-is for other cases
                        }
                    }
                
                    // Function to determine background color inline
                    function getBackgroundColor(value) {
                        if (value == 1) {
                            return 'blue'; // Blue for Present
                        } else if (value == 0) {
                            return 'red'; // Orange for Absent
                        } else {
                            return 'gray'; // No background color for other cases
                        }
                    }
                
                    var row = `<tr>
                        <td>${index + 1}</td>
                        <td>${item.Staff_Id}</td>
                        <td>${item.Staff_Name}</td>
                        <td>${item.DepartmentName}</td>
                        <td>${item.Staff_Type}</td>
                        <td>${""}</td>
                        <td>${""}</td>
                        <td>${""}</td>
                        <td>${item.Total_Present}</td>
                        <td>${item.Total_Absent}</td>
                        <td style="color: ${getBackgroundColor(item.DAY_1)};">${getDayDisplayValue(item.DAY_1)}</td>
                        <td style="color: ${getBackgroundColor(item.DAY_2)};">${getDayDisplayValue(item.DAY_2)}</td>
                        <td style="color: ${getBackgroundColor(item.DAY_3)};">${getDayDisplayValue(item.DAY_3)}</td>
                        <td style="color: ${getBackgroundColor(item.DAY_4)};">${getDayDisplayValue(item.DAY_4)}</td>
                        <td style="color: ${getBackgroundColor(item.DAY_5)};">${getDayDisplayValue(item.DAY_5)}</td>
                        <td style="color: ${getBackgroundColor(item.DAY_6)};">${getDayDisplayValue(item.DAY_6)}</td>
                        <td style="color: ${getBackgroundColor(item.DAY_7)};">${getDayDisplayValue(item.DAY_7)}</td>
                        <td style="color: ${getBackgroundColor(item.DAY_8)};">${getDayDisplayValue(item.DAY_8)}</td>
                        <td style="color: ${getBackgroundColor(item.DAY_9)};">${getDayDisplayValue(item.DAY_9)}</td>
                        <td style="color: ${getBackgroundColor(item.DAY_10)};">${getDayDisplayValue(item.DAY_10)}</td>
                        <td style="color: ${getBackgroundColor(item.DAY_11)};">${getDayDisplayValue(item.DAY_11)}</td>
                        <td style="color: ${getBackgroundColor(item.DAY_12)};">${getDayDisplayValue(item.DAY_12)}</td>
                        <td style="color: ${getBackgroundColor(item.DAY_13)};">${getDayDisplayValue(item.DAY_13)}</td>
                        <td style="color: ${getBackgroundColor(item.DAY_14)};">${getDayDisplayValue(item.DAY_14)}</td>
                        <td style="color: ${getBackgroundColor(item.DAY_15)};">${getDayDisplayValue(item.DAY_15)}</td>
                        <td style="color: ${getBackgroundColor(item.DAY_16)};">${getDayDisplayValue(item.DAY_16)}</td>
                        <td style="color: ${getBackgroundColor(item.DAY_17)};">${getDayDisplayValue(item.DAY_17)}</td>
                        <td style="color: ${getBackgroundColor(item.DAY_18)};">${getDayDisplayValue(item.DAY_18)}</td>
                        <td style="color: ${getBackgroundColor(item.DAY_19)};">${getDayDisplayValue(item.DAY_19)}</td>
                        <td style="color: ${getBackgroundColor(item.DAY_20)};">${getDayDisplayValue(item.DAY_20)}</td>
                        <td style="color: ${getBackgroundColor(item.DAY_21)};">${getDayDisplayValue(item.DAY_21)}</td>
                        <td style="color: ${getBackgroundColor(item.DAY_22)};">${getDayDisplayValue(item.DAY_22)}</td>
                        <td style="color: ${getBackgroundColor(item.DAY_23)};">${getDayDisplayValue(item.DAY_23)}</td>
                        <td style="color: ${getBackgroundColor(item.DAY_24)};">${getDayDisplayValue(item.DAY_24)}</td>
                        <td style="color: ${getBackgroundColor(item.DAY_25)};">${getDayDisplayValue(item.DAY_25)}</td>
                        <td style="color: ${getBackgroundColor(item.DAY_26)};">${getDayDisplayValue(item.DAY_26)}</td>
                        <td style="color: ${getBackgroundColor(item.DAY_27)};">${getDayDisplayValue(item.DAY_27)}</td>
                        <td style="color: ${getBackgroundColor(item.DAY_28)};">${getDayDisplayValue(item.DAY_28)}</td>
                        <td style="color: ${getBackgroundColor(item.DAY_29)};">${getDayDisplayValue(item.DAY_29)}</td>
                        <td style="color: ${getBackgroundColor(item.DAY_30)};">${getDayDisplayValue(item.DAY_30)}</td>
                        <td style="color: ${getBackgroundColor(item.DAY_31)};">${getDayDisplayValue(item.DAY_31)}</td>
                    </tr>`;
                
                    $('#month_attendance').append(row);
                });
                

            },
            error: function (xhr, status, error) {
                console.error("AJAX request failed:", status, error);
            }
                
})
})
})

$(document).ready(function () {

     $("#month_attendance").on("click", function () {
        var Staff_id = $("#Staff_id").val();
        var Month = $("#Month").val();
        var Year = $("#FinYear").val();

        $.ajax({
            type: "POST",
            url: baseurl + "Staff_Attendance/get_attendance_profile",
            data: {
                Staff_id: Staff_id,
                Month: Month,
                Year: Year
            },
            success: function (response) {

                var responseData = JSON.parse(response);

                var Profile = responseData.get_attendance_profile;
                // var PALE = responseData.get_leave_permission;

                var month_year = Profile.Month;
                var year_month =  Profile.FinYear;
                var Total_Present = Profile.Total_Present;
                var Total_Absent = Profile.Total_Absent;
                // var permission = PALE.Total_Permission_Hour;
                // var converthourse = permission + " Hrs";
                

                var Title = month_year+'  '+year_month;
                $("#Month_Year").html(Title);
                $("#Month_details").html(Title);
                $("#Present").html(Total_Present);
                $("#Absent").html(Total_Absent);
                // $("#Permission").html(converthourse);


                function setAttendance(day, value) {
                    var dayElement = $("#DAY_" + day);
                    var text = "";
                    var weekhalf = parseInt($("#Weekoff").text()); // Get current weekhalf count
                
                    if (value == 1) {
                        dayElement.css("background-color", "green"); // Present
                        text = "PR";
                    } else if (value == 0) {
                        dayElement.css("background-color", "red");   // Absent
                        text = "AB";
                    } else if (value == -5) {
                        weekhalf++;
                        dayElement.css("background-color", "orange"); // Work from Home
                        text = "WH";
                    }
                
                    dayElement.css("color", "white"); 
                    dayElement.html(day + "<br>" + text); 
                    $("#Weekoff").text(weekhalf); // Update weekhalf count in the HTML element
                }
                
                

                for (var day = 1; day <= 31; day++) {
                    var dayValue = Profile["DAY_" + day];
                    setAttendance(day, dayValue);
                }
            },

})
})
})


			

