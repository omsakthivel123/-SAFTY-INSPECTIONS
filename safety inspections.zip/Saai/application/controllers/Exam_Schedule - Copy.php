<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


class Exam_Schedule extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->helper('url');
        $this->load->helper('form');
        $this->load->helper('file');
        $this->load->library('session');
        $this->load->model('Subject_model');
        $this->load->model('Staff_model');
        $this->load->model('Exam_Schedule_model');
        $this->load->library('form_validation');
    }

    public function index()
    {

        $username = $this->session->userdata('userdata');
        if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {

            $this->load->view('Frontend/header');
            $this->load->view('Frontend/sidebar');
            $this->load->view('Exam_Schedule/index');
            $this->load->view('Frontend/footer');
        } else {
            redirect('Auth', 'refresh');
        }
    }


    public function get_subject()
    {

        $username = $this->session->userdata('userdata');
        if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {

            $InstutionName = $this->input->post('InstutionName');
            $Course_type = $this->input->post('Course_type');
            $DepartmentName = $this->input->post('DepartmentName');
            $Course_name = $this->input->post('Course_name');
            $Batch = $this->input->post('Batch');
            $Semesters = $this->input->post('Semesters');

            $this->data['get_subjects'] = $get_subjects = $this->Subject_model->get_subjects($InstutionName, $Course_type, $DepartmentName, $Course_name, $Batch, $Semesters);
            echo json_encode($get_subjects);
        } else {
            redirect('Auth', 'refresh');
        }
    }

    public function update()
{
    $username = $this->session->userdata('userdata');
    if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {
        
        if ($this->input->server('REQUEST_METHOD') === 'POST') {

            $examScheduleJson = $this->input->post('ExamSchedule');
            $examScheduleArray = json_decode($examScheduleJson, true);

            $institutionName = $this->input->post('InstitutionName');
            $courseType = $this->input->post('CourseType');
            $departmentName = $this->input->post('DepartmentName');
            $batch = $this->input->post('Batch');
            $examCategory = $this->input->post('ExamCategory');
            $semester = $this->input->post('Semester');
            $Course_name = $this->input->post('Course_name');

            $check_entry = $this->Exam_Schedule_model->check_entry($institutionName, $courseType, $departmentName, $batch, $examCategory, $semester,$Course_name);
          
            if ($check_entry == 1) {
                $Er ='ALREADY';
                echo json_encode($Er);
            } else {
               
                $save_exam = $this->Exam_Schedule_model->save_exam();
                
                if ($save_exam) {
                    $Su ='SAVE';
                    echo json_encode($Su);
                } 
            }
        }
    } else {
        redirect('Auth', 'refresh');
    }
}



public function Exam_report()
    {

        $username = $this->session->userdata('userdata');
        if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {

            $this->load->view('Frontend/header');
            $this->load->view('Frontend/sidebar');
            $this->load->view('Exam_Schedule/Exam_Schedule_report');
            $this->load->view('Frontend/footer');
        } else {
            redirect('Auth', 'refresh');
        }
    }
    public function Get_Exam_Schedule() {
        // Get data from AJAX request
        $InstitutionName = $this->input->post('InstitutionName');
        $Course_type = $this->input->post('Course_type');
        $DepartmentName = $this->input->post('DepartmentName');
        $Course_name = $this->input->post('Course_name');
        $Batch = $this->input->post('Batch');
        $ExamCategory = $this->input->post('ExamCategory');
        $Semesters = $this->input->post('Semesters');

        // Fetch data from the model based on the provided inputs
        $data = $this->Exam_Schedule_model->get_exam_schedule($InstitutionName, $Course_type, $DepartmentName, $Course_name, $Batch, $ExamCategory, $Semesters);

        // Respond with the fetched data
        echo json_encode(['reports' => $data]);
    }


}
