<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


class CourseMentor extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->helper('url');
        $this->load->helper('form');
        $this->load->helper('file');
        $this->load->library('session');
        $this->load->model('Subject_model'); 
        $this->load->model('Staff_model');
        $this->load->model('Course_Mentor_model');
        $this->load->library('form_validation');
    }


    protected function set_rules()
    {

        $rules = array(
            array(
                'field' => 'InstutionName',
                'label' => 'InstutionName',
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'Course_type',
                'label' => 'Course_type',
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'DepartmentName',
                'label' => 'DepartmentName ',
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'Course_name',
                'label' => 'Course_name',
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'Batch',
                'label' => 'Batch',
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'Semesters',
                'label' => 'Semesters',
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'Subject_code',
                'label' => 'Subject_code',
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'Subject_name',
                'label' => 'Subject_name',
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'Category',
                'label' => 'Category',
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'Credits',
                'label' => 'Credits',
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'Qualifying_Grade',
                'label' => 'Qualifying_Grade',
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'course_monter',
                'label' => 'course_monter',
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'Section',
                'label' => 'Section',
                'rules' => 'trim|required'
            ),
            
        );

        return $rules;
    }



    public function index(){

        // Check if user is logged in
        $username = $this->session->userdata('userdata');
        if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {

            $this->data['get_mentor'] = $get_mentor = $this->Course_Mentor_model->get_mentor();

            if($_POST){

                $rules = $this->set_rules();
                $this->form_validation->set_rules($rules);

                if ($this->form_validation->run() == FALSE) {

                    $this->data['form_validation'] = validation_errors();
                } else {

                      $DepartmentName = $this->input->post('DepartmentName');
                      $Course_name = $this->input->post('Course_name');
                      $Batch = $this->input->post('Batch');
                      $Semesters = $this->input->post('Semesters');
                      $Section = $this->input->post('Section');
                      $course_monter = $this->input->post('course_monter');
                      $Subject_name = $this->input->post('Subject_name');

                      $this->data['check_entry'] = $check_entry = $this->Course_Mentor_model->check_staff($DepartmentName,$Course_name,$Batch,$Semesters,$Section,$course_monter,$Subject_name );

                     if($check_entry == 1){
                        $this->session->set_flashdata('category_error', 'The Course Mentor has already been assigned and cannot be reassigned.');
                        redirect('CourseMentor');
                     }
                     $this->data['save_montor'] = $save_montor = $this->Course_Mentor_model->save_montor();

                        $this->session->set_flashdata('success', 'The assignment of the Course Mentor has been completed successfully..');
                        redirect('CourseMentor');
                }
            }                     

            // Load the view for adding a subject
            $this->load->view('Frontend/header');
            $this->load->view('Frontend/sidebar');
            $this->load->view('Subject/add_mentor', $this->data); 
            $this->load->view('Frontend/footer');
        } else {
            redirect('Auth', 'refresh');
        }
   }

}