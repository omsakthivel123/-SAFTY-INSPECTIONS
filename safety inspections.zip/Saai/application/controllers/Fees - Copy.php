<?php

require 'vendor/autoload.php'; // Make sure this path is correct for autoloading PHPMailer

require_once FCPATH . 'vendor/razorpay/razorpay/Razorpay.php';

use Razorpay\Api\Api;

class Fees extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->helper('url');
        $this->load->helper('form');
        $this->load->helper('file');
        $this->load->model('Student_model');
        $this->load->model('Staff_Attendance_model');
        $this->load->model('Fees_model');
        $this->load->library('session');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['students'] = $this->Student_model->get_all_students();
        $this->load->view('fees/index', $data);
    }

    public function get_fees_data()
    {
        $username = $this->session->userdata('userdata');
        if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {

            $FeesType = $this->input->post('FeesType');

            $StudentID = $username['Id'];
            $this->data['my_profile'] = $StudentID;

            $this->data['get_fees_details'] = $get_fees_details = $this->Fees_model->get_fees_details($StudentID, $FeesType);

            $semester = $get_fees_details[0]->Semester;
            $feestype = $get_fees_details[0]->FeesType;

            $this->data['get_con_fees_details'] = $get_con_fees_details = $this->Fees_model->get_con_fees_details($StudentID, $semester);


            if($feestype == 'Tuition Fees'){

                $consession = $get_con_fees_details[0]->ConsessionFees;
                $Amount = $get_fees_details[0]->Fees;

                //consession reduce session
                $consession_reduce = $Amount -  $consession;

                 $Amount = $consession_reduce;
            $AmountInteger = intval($Amount);
            $AmountInPaise = $AmountInteger * 100; 
          
            }

            // echo '<pre>';
           
            if ($get_fees_details == false) {

                echo json_encode(0);
                return;
            }

            $Amount = $get_fees_details[0]->Fees;
            $AmountInteger = intval($Amount);
            $AmountInPaise = $AmountInteger * 100;

            $api_key = $this->config->item('Rayzorpay_api_key');
            $api_secret = $this->config->item('Rayzorpay_secret_key');
            $api = new Api($api_key, $api_secret);


            $orderData = [
                'amount' => $AmountInPaise,
                'currency' => 'INR',
                'receipt' => 'order_rcptid_' . time(),
                'payment_capture' => 1
            ];

            $razorpayOrder = $api->order->create($orderData);
            $razorpayOrderId = $razorpayOrder['id'];

            $id = $get_fees_details[0]->Fees_Id;
            $sample = array(

                'fees_details' => $get_fees_details,

            );

            echo json_encode($sample);
        } else {
        }
    }




    public function fetch_fee()
    {
        $username = $this->session->userdata('userdata');
        if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {

            $semester = $this->input->post('semester');
            $amount = $this->input->post('totalAmount');

            $semester_array = json_decode($semester, true);
            $get_semester = isset($semester_array[0]['semester']) ? $semester_array[0]['semester'] : null;
            $get_feestype = isset($semester_array[0]['feestype']) ? $semester_array[0]['feestype'] : null;

            if ($amount > 0) {
                $amount_in_paise = $amount * 100;
            } else {
                echo json_encode(['error' => 'You Have No Fees Pending']);
                return;
            }

            // Get student ID from session data
            $studentID = $username['Id'];
            $this->data['my_profile'] = $studentID;

            // Fetch student fee details from model
            $studentdetails = $this->Fees_model->get_fee($studentID, $get_feestype, $get_semester);
            $this->data['studentdetails'] = $studentdetails;

            // Setup Razorpay API credentials
            $keyId = "rzp_test_ERi8OTWrDXP06W";
            $keySecret = "OKoqpHyItVsgJQVhwckW37j4";
            $razorpay = new Razorpay\Api\Api($keyId, $keySecret);

            // Create an order on Razorpay
            $orderData = [
                'amount' => $amount_in_paise,
                'currency' => 'INR',
                'receipt' => 'xyz',
                'payment_capture' => 1, // Auto capture payment
            ];

            // Attempt to create order
            $order = $razorpay->order->create($orderData);
            $orderId = isset($order['id']) ? $order['id'] : null;

            if ($orderId) {
                $details = [
                    'order_id' => $orderId,
                    'amount' => $amount,
                    'fees_type' => $get_feestype,
                    'semester' => $get_semester,
                ];

                // Prepare response data
                $response = array(
                    'data1' => $studentdetails,
                    'data2' => $details,
                );

                // Output JSON response
                echo json_encode($response);
            } else {
                echo json_encode(['error' => 'Failed to create order']);
            }
        } else {
            // Redirect to login page if not logged in
            redirect('Auth', 'refresh');
        }
    }

    public function callback()
    {
        // Retrieve user session data
        $username = $this->session->userdata('userdata');
        if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {


            if (!empty($this->input->post('payment_id')) && !empty($this->input->post('order_id'))) {

                // Extract necessary POST data
                $payment_id = $this->input->post('payment_id');
                $order_id = $this->input->post('order_id');
                $selectedSemesters = $this->input->post('selectedSemesters');
                $totalAmount = $this->input->post('totalAmount');

                // Decode selectedSemesters JSON data
                $semestersData = json_decode($selectedSemesters, true);

                $payment_status = $this->checkPaymentStatus($payment_id);

                $userId = $username['Id'];
                if ($payment_status['status'] === 'captured') {
                    $this->session->set_userdata('payment_data', $payment_status);

                    $pay_data = $this->session->userdata('payment_data');
                    $pay_id = $pay_data['id'];

                    $pay_sts = $pay_data['status'];
                    if ($pay_sts == "captured") {
                        $payment_status = "Success";
                    }
                    $amt = $pay_data['amount'];
                    $pay_amount = $amt / 100;
                    $pay_order_id = $pay_data['order_id'];
                    $pay_method = $pay_data['method'];
                    $pay_email = $pay_data['email'];
                    $pay_phone = $pay_data['contact'];
                    $payment_date_and_time = date('Y-m-d');

                    // Initialize variables for specific payment method details
                    $pay_card_id = null;
                    $pay_entity = null;
                    $pay_cardLast4 = null;
                    $pay_type = null;
                    $pay_upi = null;
                    $pay_upi_trans_id = null;
                    $pay_wallet_name = null;

                    // Determine payment method specifics
                    if ($pay_method == "card") {
                        $pay_card_id = $pay_data['card_id'];
                        $pay_entity = $pay_data['card']['entity'];
                        $pay_cardLast4 = $pay_data['card']['last4'];
                        $pay_type = $pay_data['card']['type'];
                    } elseif ($pay_method == "upi") {
                        $pay_upi = $pay_data['vpa'];
                        $pay_upi_trans_id = $pay_data['acquirer_data']['upi_transaction_id'];
                    } elseif ($pay_method == "wallet" || $pay_method == "paylater") {
                        $pay_wallet_name = $pay_data['wallet'];
                    }

                    // Construct payment result string
                    $result = "Online Transfer: " . 'pay_Nzirw16z' . ", Mode: " . ucfirst(strtolower($pay_method));

                    // Fetch user details from Student_model (assuming this model exists and is correctly defined)
                    $student = $this->Student_model->student($userId);

                    if (!empty($student)) {
                        // Extract student details from the first record (assuming it returns an array of objects)
                        $studentInfo = $student[0];

                        // Extract relevant student information
                        $institutionName = $studentInfo->InstitutionName_1;
                        $courseType = $studentInfo->CourseType_1;
                        $section = $studentInfo->Section_1;
                        $studentInitial = $studentInfo->initial;
                        $studentName = $studentInfo->name;
                        $studentFullName = $studentInitial . ' ' . $studentName;
                        $rollNo = $studentInfo->RollNo;
                        $examRegNumber = $studentInfo->ExamRegNumber;
                        $departmentName = $studentInfo->DepartmentName_1;
                        $batch = $studentInfo->Batch_1;
                        $dob = $studentInfo->dob;
                        $formattedDob = date('Y-m-d', strtotime($dob));
                        $courseName = $studentInfo->CourseName_1;
                        $semester1 = $studentInfo->Semester_1;
                        $studentId = $studentInfo->Student_Id;
                        $AdmisssionNo = $studentInfo->AdmissionNo; // Assuming AdmissionNo is a unique identifier for each student

                        // Iterate through each semester's payment details
                        foreach ($semestersData as $semesterData) {


                            $lastId = $this->Fees_model->get_last_id(); // Get the last ID from the mode
                            $Last_Reciept_id = $this->Fees_model->Last_Reciept_id(); // Get the last ID from the model

                            $semester = $semesterData['semester'];
                            $amount = $semesterData['amount'];
                            $feeType = $semesterData['feestype'];

                            // Check if the totalAmount is sufficient for the current semester's fee
                            if ($totalAmount >= $amount) {
                                $totalAmount -= $amount;


                                // Initialize pay_details array based on payment method
                                $pay_details = array(
                                    'InstitutionName' => $institutionName,
                                    'CourseType' => $courseType,
                                    'Section' => $section,
                                    'AdmissionNo' => $AdmisssionNo,
                                    'Student_Id' => $studentId,
                                    'Roll_No' => $rollNo,
                                    'Exam_Reg_Id' => $examRegNumber,
                                    'Student_Name' => $studentFullName,
                                    'Department' => $departmentName,
                                    'CourseName' => $courseName,
                                    'Batch' => $batch,
                                    'Semester' => $semester,
                                    'Mobile_Number' =>   $pay_phone, // Replace with actual mobile number logic
                                    'Email_Id' => $pay_email, // Replace with actual email logic
                                    'Payment_For' => $feeType,
                                    'payment_type' => 'Online',
                                    'Payment_Mode' => $pay_method,
                                    'payment_id' => $pay_id,
                                    'order_id' => $pay_order_id,
                                    'pay_amount' => $amount,
                                    'payment_status' => $payment_status,
                                    'payment_date' => $payment_date_and_time,
                                    'created_date' => $payment_date_and_time,
                                    'created_by' => 'Admin',
                                    'dob' => $formattedDob,
                                    'Status' => '1',
                                    'PaymentStatus' => 'PAID',
                                    'Get_id' =>  $lastId,
                                    'Receipt_No' => $Last_Reciept_id

                                );


                                // Additional fields based on payment method
                                if ($pay_method === "card") {
                                    $pay_details['Card_last_4_num'] = $pay_cardLast4;
                                    $pay_details['Card_id'] = $pay_card_id;
                                    $pay_details['Card_entity'] = $pay_entity;
                                    $pay_details['Card_type'] = $pay_type;
                                } elseif ($pay_method === "upi") {
                                    $pay_details['upi_id'] = $pay_upi;
                                    $pay_details['upi_transaction_id'] = $pay_upi_trans_id;
                                } elseif ($pay_method === "wallet" || $pay_method === "paylater") {
                                    $pay_details['Payment_Mode'] = $pay_method;
                                }

                                // echo '<pre>';
                                // print_r($pay_details);

                                // exit;

                                $this->session->set_userdata('payment_id', $pay_id);

                                $saveResult = $this->Fees_model->save_payment($studentId, $semester, $pay_details);

                                if ($saveResult == 1) {

                                    redirect('Fees/live_payment_reciept');
                                } else {
                                    $this->session->set_flashdata('category_error', 'Error occurred while saving payment');

                                    redirect('management/fees');
                                }
                            } else {
                                // Insufficient amount for the current semester's fee
                                echo 'Insufficient amount for the current semester\'s fee.';
                            }
                        }
                    } else {
                        // Unable to fetch student details
                        echo 'Unable to fetch student details.';
                    }
                } else {
                    // Missing payment_id or order_id in POST data
                    echo 'Missing payment_id or order_id in POST data.';
                }
            } else {
                // User not logged in or session data incomplete
                echo 'User not logged in or session data incomplete.';
            }
        }
    }



    public function checkPaymentStatus($payment_id)
    {

        // print_r($_POST);exit;
        $url = 'https://api.razorpay.com/v1/payments/' . $payment_id;
        $key_id = 'rzp_test_ERi8OTWrDXP06W';
        $key_secret = 'OKoqpHyItVsgJQVhwckW37j4';

        // Initialize cURL session
        $ch = curl_init();

        // Set cURL options
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Authorization: Basic ' . base64_encode($key_id . ':' . $key_secret)
        ));

        // Execute cURL session
        $result = curl_exec($ch);
        $http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        // Check if request was successful
        if ($http_status === 200) {
            $response_array = json_decode($result, true);
            curl_close($ch); // Close cURL session
            return $response_array;
        } else {
            curl_close($ch); // Close cURL session
            return 'error';
        }
    }

    public function live_payment_reciept()
    {

        $username = $this->session->userdata('userdata');
        if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {

            $payment_id = $this->session->userdata('payment_id');

            $this->data['result'] = $payment_data = $this->Fees_model->live_payment_id($payment_id);

            $this->load->view('Frontend/header');
            $this->load->view('Frontend/sidebar');
            $this->load->view('Fees/live_payment_receipt', $this->data);
            $this->load->view('Frontend/footer');
        } else {
            redirect('Auth', 'refresh');
        }
    }


    public function reciept_table()
    {

        $username = $this->session->userdata('userdata');
        if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {

            $rollNumber = $username['Id'];
            $this->data['result'] = $get = $this->Fees_model->receipt($rollNumber);

            // print_r( $this->data);exit;

            $this->load->view('Frontend/header');
            $this->load->view('Frontend/sidebar');
            $this->load->view('Fees/reciept_table', $this->data);
            $this->load->view('Frontend/footer');
        } else {
            redirect('Auth', 'refresh');
        }
    }


    public function payment_reciept_live($student_id)
    {
        $username = $this->session->userdata('userdata');
        if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {

            $sql = "SELECT * FROM Web_Student_Payment_details_Mst WHERE Get_Id = '$student_id'";
            $query = $this->db->query($sql);
            $this->data['result'] = $query->row();

            $this->load->view('Frontend/header');
            $this->load->view('Frontend/sidebar');
            $this->load->view('Fees/instant_receipt', $this->data);
            $this->load->view('Frontend/footer');
        } else {
            redirect('Auth', 'refresh');
        }
    }


    public function payment_reciept($student_id)
    {
        $username = $this->session->userdata('userdata');
        if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {

            $sql = "SELECT * FROM Web_Student_Payment_details_Mst WHERE Get_Id = '$student_id'";
            $query = $this->db->query($sql);
            $this->data['result'] = $query->row();

            $this->load->view('Frontend/header');
            $this->load->view('Frontend/sidebar');
            $this->load->view('Fees/dwonload_reciept', $this->data);
            $this->load->view('Frontend/footer');
        } else {
            redirect('Auth', 'refresh');
        }
    }
}
