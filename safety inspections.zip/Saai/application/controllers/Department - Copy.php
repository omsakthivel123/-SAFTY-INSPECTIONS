<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


class Department extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();

		$this->load->helper('url');
		$this->load->helper('form');
		$this->load->helper('file');
		$this->load->library('session');
		$this->load->model('Department_model');
		$this->load->library('form_validation');
	}

	protected function set_rules()
	{

		$rules = array(
			array(
				'field' => 'Department',
				'label' => 'Department',
				'rules' => 'trim|required'
			),
			array(
				'field' => 'Staff_Name',
				'label' => 'Staff_Name',
				'rules' => 'trim|required'
			),
			array(
				'field' => 'Course_type',
				'label' => 'Course_type ',
				'rules' => 'trim|required'
			),
			array(
				'field' => 'Batch',
				'label' => 'Batch',
				'rules' => 'trim|required'
			),
			array(
				'field' => 'Course',
				'label' => 'Course',
				'rules' => 'trim|required'
			),
			array(
				'field' => 'Section',
				'label' => 'Section',
				'rules' => 'trim|required'
			),
		);
	}



	public function index()
	{
		$username = $this->session->userdata('userdata');
		if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {

			$this->data['get_assign_staff'] = $get_assign_staff = $this->Department_model->get_assign_staff();

			$this->load->view('Frontend/header');
			$this->load->view('Frontend/sidebar');
			$this->load->view('Department/add_incharge', $this->data);
			$this->load->view('Frontend/footer');
		} else {
			redirect('Auth', 'refresh');
		}
	}

	public function get_department()
	{
		$username = $this->session->userdata('userdata');
		if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {

			$InstutionName = $this->input->post('InstutionName');

			$this->data['Get_Department'] = $Get_Department = $this->Department_model->get_department($InstutionName);
			echo json_encode($Get_Department);
		} else {
			redirect('Auth', 'refresh');
		}
	}

	public function get_staff()
	{
		$username = $this->session->userdata('userdata');
		if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {

			$department = $this->input->post('selectedValue');
			$this->data['Get_Staff'] = $get_Staff = $this->Department_model->get_staffs($department);
			echo json_encode($get_Staff);
		} else {
			redirect('Auth', 'refresh');
		}
	}

	public function get_batch()
	{

		$username = $this->session->userdata('userdata');
		if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {

			$department_type = $this->input->post('department_type');
			$course_type = $this->input->post('course_type');
			$this->data['get_batch'] = $get_batch = $this->Department_model->get_batch($department_type, $course_type);
			echo json_encode($get_batch);
		} else {
			redirect('Auth', 'refresh');
		}
	}

	public function get_batch_1()
	{

		$username = $this->session->userdata('userdata');
		if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {

			$department_type = $this->input->post('Department_Name');
			$course_type = $this->input->post('Course_type');
			$this->data['get_batch'] = $get_batch = $this->Department_model->get_batchs($department_type, $course_type);
			echo json_encode($get_batch);
		} else {
			redirect('Auth', 'refresh');
		}
	}

	public function assign_incharge()
	{

		$username = $this->session->userdata('userdata');
		if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {

			if ($_POST) {

				$InstutionName = $this->input->post('InstutionName');
				$department_name = $this->input->post('Department_Name');
				$staff_name = $this->input->post('Staff_Name');
				$course_type = $this->input->post('Course_type');
				$batch = $this->input->post('Batch');
				$course = $this->input->post('Course');
				$section = $this->input->post('Section');

				$this->data['get_inst_code'] = $get_inst_code = $this->Department_model->get_instutions_code($InstutionName);
				$this->data['get_dept_code'] = $get_dept_code = $this->Department_model->get_dept_code($department_name);

				$inst_Code = $get_inst_code[0]->InstutionName_Code;
				$inst_dept = $get_dept_code[0]->DepartmentCode;

				// Check if the staff is already assigned for the particular department
				$check_assign_incharge = $this->Department_model->check_assign_incharge($InstutionName, $department_name, $staff_name, $course_type, $batch, $course, $section);

				if ($check_assign_incharge == 1) {
					$this->session->set_flashdata('error', 'Staff is already assigned for this department.');
				} else {
					$query = $this->Department_model->save_incharge_data($inst_Code, $inst_dept);

					if ($query == 1) {
						$this->session->set_flashdata('success', 'Staff assigned successfully.');
					} else {
						$this->session->set_flashdata('error', 'Error assigning staff. Please try again later.');
					}
				}

				redirect('Department', 'refresh');
			} else {
				redirect('Department', 'refresh');
			}
		} else {
			redirect('Auth', 'refresh');
		}
	}

	public function get_instution()
	{

		$username = $this->session->userdata('userdata');
		if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {

			$this->data['get_instutions'] = $get_instutions = $this->Department_model->get_instutions();
			echo json_encode($get_instutions);
		} else {
			redirect('Auth', 'refresh');
		}
	}

	public function get_departments()
	{

		$username = $this->session->userdata('userdata');
		if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {

			$department = $this->input->post('selectedValue');

			$this->data['get_department_all'] = $get_department_all = $this->Department_model->get_department_all($department);
			echo json_encode($get_department_all);
		} else {
			redirect('Auth', 'refresh');
		}
	}

	public function Inst_Code()
	{

		$username = $this->session->userdata('userdata');
		if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {

			$instutions = $this->input->post('selectedValue');

			$this->data['get_instutions_code'] = $get_instutions_code = $this->Department_model->get_instutions_code($instutions);
			echo json_encode($get_instutions_code);
		} else {
			redirect('Auth', 'refresh');
		}
	}

	public function get_staff_depat()
	{

		$username = $this->session->userdata('userdata');
		if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {

			$InstutionName = $this->input->post('InstutionName');

			$this->data['get_staff_depat'] = $get_staff_depat = $this->Department_model->get_staff_depat_stass($InstutionName);
			echo json_encode($get_staff_depat);
		} else {
			redirect('Auth', 'refresh');
		}
	}

	public function get_Inst()
	{

		$username = $this->session->userdata('userdata');
		if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {

			$department = $this->input->post('selectedValue');

			$this->data['get_Insts'] = $get_Insts = $this->Department_model->get_Insts($department);
			echo json_encode($get_Insts);
		} else {
			redirect('Auth', 'refresh');
		}
	}

	public function gets_staff()
	{

		$username = $this->session->userdata('userdata');
		if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {

			$department = $this->input->post('selectedValue');

			$this->data['get_staffss'] = $get_staffss = $this->Department_model->get_staffss($department);
			echo json_encode($get_staffss);
		} else {
			redirect('Auth', 'refresh');
		}
	}


	public function get_batchs()
	{

		$username = $this->session->userdata('userdata');
		if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {

			$department = $this->input->post('Department_Name');
			$coursetype = $this->input->post('Course_type');

			$this->data['gets_batches'] = $gets_batches = $this->Department_model->gets_batches($department, $coursetype);
			echo json_encode($gets_batches);
		} else {
			redirect('Auth', 'refresh');
		}
	}

	// public function get_course_type()
	// {

	// 	$username = $this->session->userdata('userdata');
	// 	if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {

	// 		$InstutionName = $this->input->post('selectedValue');

	// 		$this->data['get_course_types'] = $get_course_types = $this->Department_model->get_course_types($InstutionName );
	// 		echo json_encode($get_course_types);
	// 	} else {
	// 		redirect('Auth', 'refresh');
	// 	}
	// }



	//Class Incharge

	public function get_class_incharge()
	{
		$username = $this->session->userdata('userdata');
		if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {
			$this->load->view('Frontend/header');
			$this->load->view('Frontend/sidebar');
			$this->load->view('Department/get_class_incharge');
			$this->load->view('Frontend/footer');
		} else {
			redirect('Auth', 'refresh');
		}
	}


	public function Get_class_inchar()

	{
		$username = $this->session->userdata('userdata');
		if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {
			$institution_name = $this->input->post('InstitutionName');
			$Inst_codes = $this->input->post('Inst_codes');
			$Department_Name = $this->input->post('Department_Name');
			$Course_type = $this->input->post('Course_type');
			$Section = $this->input->post('Section');
			$Batch = $this->input->post('Batch');
			$Approval = $this->input->post('Approval');
			$data['reports'] = $this->Department_model->get_Department_wise1($institution_name, $Inst_codes, $Department_Name, $Course_type, $Section, $Batch, $Approval);
			// echo '<pre>';
			// print_r($data);
			// exit; 
			echo json_encode($data);
		} else {
			redirect('Auth', 'refresh');
		}
	}
	
}
