<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Absent_Report extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->helper('form');
        $this->load->helper('file');
        $this->load->model('Absent_report_model');
        $this->load->library('session');
        $this->load->library('form_validation');
    }

    
    public function index()
    {
        $username = $this->session->userdata('userdata');
        if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {

            $this->load->view('Frontend/header');
            $this->load->view('Frontend/sidebar');
            $this->load->view('Absent_Report/Absent_report_view');
            $this->load->view('Frontend/footer');
        } else {
            redirect('Auth', 'refresh');
        }
    }

    public function get_reports()
    {
        $username = $this->session->userdata('userdata');
        if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {
            $institution_name = $this->input->post('Institute_name');
            $date = $this->input->post('date');

            $data['reports'] = $this->Absent_report_model->get_absent_reports($institution_name, $date);

            $this->load->view('Frontend/header');
            $this->load->view('Frontend/sidebar');
            $this->load->view('Absent_Report/Absent_report_view', $data);
            $this->load->view('Frontend/footer');
        } else {
            redirect('Auth', 'refresh');
        }
    }


    public function get_Staff_reports()
    {
        $username = $this->session->userdata('userdata');
        if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {
            $institution_name = $this->input->post('Institute_name');
            $Department = $this->input->post('Department');
            $Staff_type = $this->input->post('Staff_type');
            $date = $this->input->post('date');
    
            $data['reports'] = $this->Absent_report_model->get_staff_absent_reports($institution_name, $Department, $Staff_type, $date);
    
            $this->load->view('Frontend/header');
            $this->load->view('Frontend/sidebar');
            $this->load->view('Attendance/Staff_attendance_report_view', $data);
            $this->load->view('Frontend/footer');
        } else {
            redirect('Auth', 'refresh');
        }
    }
    
}
    
 

