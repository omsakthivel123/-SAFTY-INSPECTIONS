<?php
require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Reader\Csv as ReaderCsv;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Csv;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;


if (!defined('BASEPATH')) exit('No direct script access allowed');


class Downloader extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->helper('url');
        $this->load->helper('form');
        $this->load->helper('file');
        $this->load->library('session');
        $this->load->helper('download');
        $this->load->model('Absent_report_model');
        $this->load->model('Department_model');
        $this->load->model('Subject_model');
        $this->load->model('Exam_Schedule_model');
        $this->load->model('Student_model');
        $this->load->model('Absent_report_model');
        $this->load->model('Staff_model');
        $this->load->model('TimeTable_model');


    }
   
public function data(){
    $data= $this->data['records'] = $this->Absent_report_model->get_aadmin_ass_data();
      
    if(count($data)>0){
        $spreadsheet = new Spreadsheet();
        $sheet=$spreadsheet->getActiveSheet();
        $sheet->setCellValue('A1','InstitutionName');
        $sheet->setCellValue('B1','DepartmentName');
        $sheet->setCellValue('C1','CourseName');
        $sheet->setCellValue('D1','Date');
 
        
        $row=2;

        foreach($data as $datas){

            $sheet->setCellValue('A'.$row, $datas['InstitutionName']);
            $sheet->setCellValue('B'.$row, $datas['DepartmentName']);
            $sheet->setCellValue('C'.$row, $datas['CourseName']);
            $sheet->setCellValue('D'.$row, $datas['Date']);
  
                  $row++;
        }
        $filename = 'Reports' . date('Y-m-d') . '.csv';
                // Write the file to the output
                $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
           header('Content-type:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
           header('Content-Disposition:attachment;filename='.$filename.'.csv');
           header('Cache-Control:max-age=0');
           $writer->save('php://output');
    }else{
         echo 'no data exported';
    }
}

public function incharge(){

    //  print_r($this->input->post());

     $institution_name = $this->input->post('Inst_name_1');
     $Inst_codes = $this->input->post('Inst_codes');
     $Department_Name = $this->input->post('department');
     $Course_type = $this->input->post('Course_type');
     $Section = $this->input->post('Section');
     $Batch = $this->input->post('Batch');


    $data = $this->Department_model->get_Department_wise1( $institution_name,$Inst_codes,$Department_Name,$Course_type,$Section,$Batch);
   
    // echo '<pre>';
    // print_r($data);
    // exit;
    
    if(count($data) > 0){
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setCellValue('A1', 'InstutionCode');
        $sheet->setCellValue('B1', 'Instution_Name');
        $sheet->setCellValue('C1', 'Department_Code');
        $sheet->setCellValue('D1', 'Department_Name');
        $sheet->setCellValue('E1', 'Staff_Name');
        $sheet->setCellValue('F1', 'Course_type');
        $sheet->setCellValue('G1', 'Batch');
        $sheet->setCellValue('H1', 'Course_Name'); 
        $sheet->setCellValue('I1', 'Section');


        
        
        $row = 2;
        foreach($data as $datas){
            $sheet->setCellValue('A'.$row, $datas['InstutionCode']);
            $sheet->setCellValue('B'.$row, $datas['Instution_Name']);
            $sheet->setCellValue('C'.$row, $datas['Department_Code']);
            $sheet->setCellValue('D'.$row, $datas['Department_Name']);
            $sheet->setCellValue('E'.$row, $datas['Staff_Name']);
            $sheet->setCellValue('F'.$row, $datas['Course_type']);
            $sheet->setCellValue('G'.$row, $datas['Batch']);
            $sheet->setCellValue('H'.$row, $datas['Course_Name']);
            $sheet->setCellValue('I'.$row, $datas['Section']);
            $row++;
        }
        
        $filename = 'Reports_' . date('Y-m-d') . '.csv';
        // Write the file to the output
        $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename='.$filename);
        header('Cache-Control: max-age=0');
        $writer->save('php://output');
    } else {
        echo 'No data exported';
    }
}

public function subject()
{
    $institution_name = $this->input->post('InstutionName');
    $course_type = $this->input->post('Course_type');
    $department_name = $this->input->post('DepartmentName');
    $course_name = $this->input->post('Course_name');
    $batch = $this->input->post('Batch');
    $semester = $this->input->post('Semesters');

    $data = $this->Subject_model->get_subject_report($institution_name, $course_type, $department_name, $course_name, $batch, $semester);

    if (count($data) > 0) {
        $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        // Set header row
        $sheet->setCellValue('A1', 'S.No');
        $sheet->setCellValue('B1', 'Institution Name');
        $sheet->setCellValue('C1', 'Course Type');
        $sheet->setCellValue('D1', 'Department');
        $sheet->setCellValue('E1', 'Course Name');
        $sheet->setCellValue('F1', 'Batch');
        $sheet->setCellValue('G1', 'Semester');
        $sheet->setCellValue('H1', 'Subject Code');
        $sheet->setCellValue('I1', 'Subject Name');
        $sheet->setCellValue('J1', 'Category');
        $sheet->setCellValue('K1', 'Credits');
        $sheet->setCellValue('L1', 'Qualifying Grade');
        $sheet->setCellValue('M1', 'Created By');

        // Populate data rows
        $row = 2;
        foreach ($data as $index => $item) {
            $sheet->setCellValue('A'.$row, $index + 1);
            $sheet->setCellValue('B'.$row, $item['InstutionName']);
            $sheet->setCellValue('C'.$row, $item['CourseType']);
            $sheet->setCellValue('D'.$row, $item['DepartmentName']);
            $sheet->setCellValue('E'.$row, $item['CourseName']);
            $sheet->setCellValue('F'.$row, $item['Batch']);
            $sheet->setCellValue('G'.$row, $item['Semesters']);
            $sheet->setCellValue('H'.$row, $item['SubjectCode']);
            $sheet->setCellValue('I'.$row, $item['SubjectName']);
            $sheet->setCellValue('J'.$row, $item['Category']);
            $sheet->setCellValue('K'.$row, $item['Credits']);
            $sheet->setCellValue('L'.$row, $item['Qualifying_grade']);
            $sheet->setCellValue('M'.$row, $item['CreatedBy']);
            $row++;
        }

        $filename = 'Subject_Report_' . date('Y-m-d') . '.csv';

        // Write the file to the output
        $writer = new \PhpOffice\PhpSpreadsheet\Writer\Csv($spreadsheet);
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename='.$filename);
        header('Cache-Control: max-age=0');
        $writer->save('php://output');
    } else {
        echo 'No data available for export';
    }
}

public function Mentor()
{
    // Retrieve POST data
    $institutionName = $this->input->post('InstutionName');
    $courseType = $this->input->post('Course_type');
    $departmentName = $this->input->post('DepartmentName');
    $courseName = $this->input->post('Course_name');
    $batch = $this->input->post('Batch');
    $semester = $this->input->post('Semesters');
    $section = $this->input->post('Section');

    // Debug: Print POST data to check values
  

    // Fetch data from model
    $data = $this->Subject_model->get_Mentor($institutionName, $courseType, $departmentName, $courseName, $batch, $semester, $section);

    // Debug: Print fetched data to check what is returned
    // echo "<pre>";
    // print_r($data);
    // echo "</pre>";

    // If data is available, proceed to create and download the CSV
    if (!empty($data)) {
        // Generate CSV and download logic here
        $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        // Set header row
        $sheet->setCellValue('A1', 'S.No');
        $sheet->setCellValue('B1', 'Institution Name');
        $sheet->setCellValue('C1', 'Course Type');
        $sheet->setCellValue('D1', 'Department');
        $sheet->setCellValue('E1', 'Course Name');
        $sheet->setCellValue('F1', 'Batch');
        $sheet->setCellValue('G1', 'Semester');
        $sheet->setCellValue('H1', 'Section');
        $sheet->setCellValue('I1', 'Subject Code');
        $sheet->setCellValue('J1', 'Subject Name');
        $sheet->setCellValue('K1', 'Category');
        $sheet->setCellValue('L1', 'Credits');
        $sheet->setCellValue('M1', 'Qualifying Grade');
        $sheet->setCellValue('N1', 'Created By');

        // Populate data rows
        $row = 2;
        foreach ($data as $index => $item) {
            $sheet->setCellValue('A'.$row, $index + 1);
            $sheet->setCellValue('B'.$row, $item['InstutionName']);
            $sheet->setCellValue('C'.$row, $item['CourseType']);
            $sheet->setCellValue('D'.$row, $item['DepartmentName']);
            $sheet->setCellValue('E'.$row, $item['CourseName']);
            $sheet->setCellValue('F'.$row, $item['Batch']);
            $sheet->setCellValue('G'.$row, $item['Semester']);
            $sheet->setCellValue('H'.$row, $item['Section']);
            $sheet->setCellValue('I'.$row, $item['Subject_code']);
            $sheet->setCellValue('J'.$row, $item['Subject_name']);
            $sheet->setCellValue('K'.$row, $item['Category']);
            $sheet->setCellValue('L'.$row, $item['Credits']);
            $sheet->setCellValue('M'.$row, $item['QualifyingGrade']);
            $sheet->setCellValue('N'.$row, $item['CreatedBy']);
            $row++;
        }

        // Set headers for download
        $filename = 'Course_Mentor_Report_' . date('Y-m-d') . '.csv';
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="'.$filename.'"');
        header('Cache-Control: max-age=0');

        // Output to browser
        $writer = new \PhpOffice\PhpSpreadsheet\Writer\Csv($spreadsheet);
        $writer->setDelimiter(',');
        $writer->setEnclosure('"');
        $writer->setLineEnding("\r\n");
        $writer->setSheetIndex(0);
        $writer->save('php://output');
        exit;
    } else {
        echo 'No data available for export';
    }
}


public function Exam_Schedule_Report()
{
//  print_r($this->input->post());

//     exit;
   
    $institution_name = $this->input->post('InstutionName');
    $course_type = $this->input->post('Course_type');
    $department_name = $this->input->post('DepartmentName');
    $course_name = $this->input->post('Course_name');
    $batch = $this->input->post('Batch');
    $semester = $this->input->post('Semesters');
    $section = $this->input->post('Section');
    $exam_category = $this->input->post('ExamCategory');

    $data = $this->Exam_Schedule_model->get_exam_schedule_report($institution_name, $course_type, $department_name, $course_name, $batch, $semester, $section, $exam_category);
    
    if (count($data) > 0) {
        // Generate CSV and download logic here
        $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        // $spreadsheet = new Spreadsheet();
        // $sheet = $spreadsheet->getActiveSheet();

        // Set header row
        $sheet->setCellValue('A1', 'S.No');
        $sheet->setCellValue('B1', 'Institution Name');
        $sheet->setCellValue('C1', 'Course Type');
        $sheet->setCellValue('D1', 'Department Name');
        $sheet->setCellValue('E1', 'Course Name');
        $sheet->setCellValue('F1', 'Batch');
        $sheet->setCellValue('G1', 'Semester');
        $sheet->setCellValue('H1', 'Exam Category');
        $sheet->setCellValue('I1', 'Subject Code');
        $sheet->setCellValue('J1', 'Subject Name');
        $sheet->setCellValue('K1', 'Exam Date');
        $sheet->setCellValue('L1', 'Session');

        // Populate data rows
        $row = 2;
        foreach ($data as $index => $item) {
            $sheet->setCellValue('A'.$row, $index + 1);
            $sheet->setCellValue('B'.$row, $item['InstitutionName']);
            $sheet->setCellValue('C'.$row, $item['CourseType']);
            $sheet->setCellValue('D'.$row, $item['DepartmentName']);
            $sheet->setCellValue('E'.$row, $item['CourseName']);
            $sheet->setCellValue('F'.$row, $item['Batch']);
            $sheet->setCellValue('G'.$row, $item['Semester']);
            $sheet->setCellValue('H'.$row, $item['ExamCategory']);
            $sheet->setCellValue('I'.$row, $item['SubjectCode']);
            $sheet->setCellValue('J'.$row, $item['SubjectName']);
            $sheet->setCellValue('K'.$row, $item['ExamDate']);
            $sheet->setCellValue('L'.$row, $item['Session']);
            $row++;
        }

        $filename = 'Exam_Schedule_Report_' . date('Y-m-d') . '.csv';

        // Write the file to the output
        $writer = new \PhpOffice\PhpSpreadsheet\Writer\Csv($spreadsheet);
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename='.$filename);
        header('Cache-Control: max-age=0');
        $writer->save('php://output');
    } else {
        echo 'No data available for export';
    }
}


public function Student_department_wise()
    {
        // Retrieve POST data

        // print_r($this->input->post());
    // exit;
        $institutionName = $this->input->post('Inst_name_1');
        $institutionCode = $this->input->post('Inst_codes');
        $departmentName = $this->input->post('department');
        $courseType = $this->input->post('Course_type');

        // Example data query (adjust according to your actual data retrieval logic)
        $data = $this->Student_model->get_student_department_data($institutionName, $institutionCode, $departmentName, $courseType);

        // Check if data is available
        if (count($data) > 0) {
            // Initialize PhpSpreadsheet
            $spreadsheet = new Spreadsheet();
            $sheet = $spreadsheet->getActiveSheet();

            // Set header row
            $sheet->setCellValue('A1', 'S.No');
            $sheet->setCellValue('B1', 'Student Id');
            $sheet->setCellValue('C1', 'Name');
            $sheet->setCellValue('D1', 'Department Name');
            $sheet->setCellValue('E1', 'Course Type');
            $sheet->setCellValue('F1', 'Semester');
            $sheet->setCellValue('G1', 'Batch');
            $sheet->setCellValue('H1', 'Section');
            $sheet->setCellValue('I1', 'Father Name');
            $sheet->setCellValue('J1', 'Mother Name');
            $sheet->setCellValue('K1', 'Institution Name');
            $sheet->setCellValue('L1', 'Institution Code');
            $sheet->setCellValue('M1', 'Course Name');
            $sheet->setCellValue('N1', 'Course Type For Previous');
            $sheet->setCellValue('O1', 'Exam Reg No');
            $sheet->setCellValue('P1', 'Initial');
            $sheet->setCellValue('Q1', 'DOB');
            $sheet->setCellValue('R1', 'Place of Birth');
            $sheet->setCellValue('S1', 'Mother Tongue');
            $sheet->setCellValue('T1', 'Father Occupation');
            $sheet->setCellValue('U1', 'Father Income');
            $sheet->setCellValue('V1', 'Blood Group');
            $sheet->setCellValue('W1', 'Mother Occupation');
            $sheet->setCellValue('X1', 'Mother Income');
            $sheet->setCellValue('Y1', 'Aadhar Card No');
            $sheet->setCellValue('Z1', 'Mobile No');
            $sheet->setCellValue('AA1', 'Alternate Mobile No');
            $sheet->setCellValue('AB1', 'Student Mobile Number');
            $sheet->setCellValue('AC1', 'Email Id');
            $sheet->setCellValue('AD1', 'First Language');
            $sheet->setCellValue('AE1', 'Parents');
            $sheet->setCellValue('AF1', 'Religion');
            $sheet->setCellValue('AG1', 'Community');
            $sheet->setCellValue('AH1', 'Caste');
            $sheet->setCellValue('AI1', 'Guardian Name');
            $sheet->setCellValue('AJ1', 'Extra Curricular Activities');
            $sheet->setCellValue('AK1', 'Physical Disability');
            $sheet->setCellValue('AL1', 'Volunteers');
            $sheet->setCellValue('AM1', 'Gender');
            $sheet->setCellValue('AN1', 'Permanent Address Pincode');
            $sheet->setCellValue('AO1', 'Permanent Address Post Office');
            $sheet->setCellValue('AP1', 'Permanent Address District');
            $sheet->setCellValue('AQ1', 'Permanent Address State');
            $sheet->setCellValue('AR1', 'Communication Address Pincode');
            $sheet->setCellValue('AS1', 'Communication Address Post Office');
            $sheet->setCellValue('AT1', 'Communication Address District');
            $sheet->setCellValue('AU1', 'Communication Address State');
            $sheet->setCellValue('AV1', 'Permanent Address Line 1');
            $sheet->setCellValue('AW1', 'Permanent Address Line 2');
            $sheet->setCellValue('AX1', 'Communication Address Line 1');
            $sheet->setCellValue('AY1', 'Communication Address Line 2');
            $sheet->setCellValue('AZ1', 'School Name');
            $sheet->setCellValue('BA1', 'Subject 1 Name');
            $sheet->setCellValue('BB1', 'Subject 1 Mark');
            $sheet->setCellValue('BC1', 'Subject 2 Name');
            $sheet->setCellValue('BD1', 'Subject 2 Mark');
            $sheet->setCellValue('BE1', 'Subject 3 Name');
            $sheet->setCellValue('BF1', 'Subject 3 Mark');
            $sheet->setCellValue('BG1', 'Subject 4 Name');
            $sheet->setCellValue('BH1', 'Subject 4 Mark');
            $sheet->setCellValue('BI1', 'Subject 5 Name');
            $sheet->setCellValue('BJ1', 'Subject 5 Mark');
            $sheet->setCellValue('BK1', 'Subject 6 Name');
            $sheet->setCellValue('BL1', 'Subject 6 Mark');
            $sheet->setCellValue('BM1', 'HSC Mark');
            $sheet->setCellValue('BN1', 'HSC Mark Percentage');
            $sheet->setCellValue('BO1', 'Month and Year of Passing HSC');
            $sheet->setCellValue('BP1', 'Studied Group');
            $sheet->setCellValue('BQ1', 'HSC Roll Number');
            $sheet->setCellValue('BR1', 'Medium of Study');
            $sheet->setCellValue('BS1', 'Total Maximum Marks');
            $sheet->setCellValue('BT1', 'EMIS Number');
            $sheet->setCellValue('BU1', 'Aadhar Card');
            $sheet->setCellValue('BV1', 'Bank Pass Book');
            $sheet->setCellValue('BW1', 'Community Certificate');
            $sheet->setCellValue('BX1', 'Transfer Certificate');
            $sheet->setCellValue('BY1', '10th Mark Sheet');
            $sheet->setCellValue('BZ1', '12th Mark Sheet');
            $sheet->setCellValue('CA1', 'Examination Passed');
            $sheet->setCellValue('CB1', 'IFSC Code');
            $sheet->setCellValue('CC1', 'Bank Name');
            $sheet->setCellValue('CD1', 'Bank Address');
            $sheet->setCellValue('CE1', 'Account Number');
            $sheet->setCellValue('CF1', 'MICR Code');
            $sheet->setCellValue('CG1', 'Student Degree');
            $sheet->setCellValue('CH1', 'Student Degree Type');
            $sheet->setCellValue('CI1', 'Year of Passing');
            $sheet->setCellValue('CJ1', 'University Name');
            $sheet->setCellValue('CK1', 'Institution Name');
            $sheet->setCellValue('CL1', 'Studied Mode');
            $sheet->setCellValue('CM1', 'Pass Percentage');
            $sheet->setCellValue('CN1', 'Specialization');
            $sheet->setCellValue('CO1', 'Date of Admission');
            $sheet->setCellValue('CP1', 'Roll Number');
            $sheet->setCellValue('CQ1', 'Department Name');
            $sheet->setCellValue('CR1', 'Department Code');
            $sheet->setCellValue('CS1', 'Course Year');
            $sheet->setCellValue('CT1', 'Course Name (Short)');
            $sheet->setCellValue('CU1', 'Course Name (Full)');
            $sheet->setCellValue('CV1', 'Course Code');
            $sheet->setCellValue('CW1', 'Brother/Sister Studying/Studied');
            $sheet->setCellValue('CX1', 'Name of Brother/Sister');
            $sheet->setCellValue('CY1', 'Mode of Transport');
            $sheet->setCellValue('CZ1', 'Boarding Point');
            $sheet->setCellValue('DA1', 'Image File Name');
            $sheet->setCellValue('DB1', 'Image Content Type');
            $sheet->setCellValue('DC1', 'Image Data');
            $sheet->setCellValue('DD1', 'Hostel');
            $sheet->setCellValue('DE1', 'Scholarship');
            $sheet->setCellValue('DF1', 'Scholarship Type');
            $sheet->setCellValue('DG1', 'Charity Scholarship');
            $sheet->setCellValue('DH1', 'Charity Amount');
            $sheet->setCellValue('DI1', 'Management Scholarship');
            $sheet->setCellValue('DJ1', 'Quota');
            $sheet->setCellValue('DK1', 'Concession');
            $sheet->setCellValue('DL1', 'Remarks');
            $sheet->setCellValue('DM1', 'Referred by');
            $sheet->setCellValue('DN1', 'TC Received Date');
            $sheet->setCellValue('DO1', 'Documents Enclosed');
            $sheet->setCellValue('DP1', 'Documents Not Enclosed');
            $sheet->setCellValue('DQ1', 'Institution Code');
            $sheet->setCellValue('DR1', 'Status');
            $sheet->setCellValue('DS1', 'Last Date');
            $sheet->setCellValue('DT1', 'Reason for Leaving');

            // Populate data rows
            $row = 2;
            foreach ($data as $index => $item) {
                $sheet->setCellValue('A'.$row, $index + 1);
                $sheet->setCellValue('B'.$row, $item['Student_Id']);
                $sheet->setCellValue('C'.$row, $item['name']);
                $sheet->setCellValue('D'.$row, $item['DepartmentName_1']);
                $sheet->setCellValue('E'.$row, $item['CourseType_1']);
                $sheet->setCellValue('F'.$row, $item['Semester_1']);
                $sheet->setCellValue('G'.$row, $item['Batch_1']);
                $sheet->setCellValue('H'.$row, $item['Section_1']);
                $sheet->setCellValue('I'.$row, $item['father_name']);
                $sheet->setCellValue('J'.$row, $item['mother_name']);
                $sheet->setCellValue('K'.$row, $item['InstitutionName_1']);
                $sheet->setCellValue('L'.$row, $item['Institutioncode_1']);
                $sheet->setCellValue('M'.$row, $item['CourseName_1']);
                $sheet->setCellValue('N'.$row, $item['course_type']);
                $sheet->setCellValue('O'.$row, $item['Exam_Reg_No']);
                $sheet->setCellValue('P'.$row, $item['initial']);
                $sheet->setCellValue('Q'.$row, $item['dob']);
                $sheet->setCellValue('R'.$row, $item['place_of_birth']);
                $sheet->setCellValue('S'.$row, $item['mother_tongue']);
                $sheet->setCellValue('T'.$row, $item['father_occupation']);
                $sheet->setCellValue('U'.$row, $item['father_income']);
                $sheet->setCellValue('V'.$row, $item['blood_group']);
                $sheet->setCellValue('W'.$row, $item['mother_occupation']);
                $sheet->setCellValue('X'.$row, $item['mother_income']);
                $sheet->setCellValue('Y'.$row, $item['aadhar_card_no']);
                $sheet->setCellValue('Z'.$row, $item['mobile_no']);
                $sheet->setCellValue('AA'.$row, $item['alternate_mobile_no']);
                $sheet->setCellValue('AB'.$row, $item['stu_mobile_number']);
                $sheet->setCellValue('AC'.$row, $item['email_id']);
                $sheet->setCellValue('AD'.$row, $item['first_language']);
                $sheet->setCellValue('AE'.$row, $item['parents']);
                $sheet->setCellValue('AF'.$row, $item['religion']);
                $sheet->setCellValue('AG'.$row, $item['community']);
                $sheet->setCellValue('AH'.$row, $item['caste']);
                $sheet->setCellValue('AI'.$row, $item['guardian_name']);
                $sheet->setCellValue('AJ'.$row, $item['extra_curricular_activities']);
                $sheet->setCellValue('AK'.$row, $item['physical_disability']);
                $sheet->setCellValue('AL'.$row, $item['volunteers']);
                $sheet->setCellValue('AM'.$row, $item['gender']);
                $sheet->setCellValue('AN'.$row, $item['per_addr_pincode']);
                $sheet->setCellValue('AO'.$row, $item['per_addr_post_office']);
                $sheet->setCellValue('AP'.$row, $item['per_addr_district']);
                $sheet->setCellValue('AQ'.$row, $item['per_addr_state']);
                $sheet->setCellValue('AR'.$row, $item['communi_addr_pincode']);
                $sheet->setCellValue('AS'.$row, $item['communi_addr_post_office']);
                $sheet->setCellValue('AT'.$row, $item['communi_addr_district']);
                $sheet->setCellValue('AU'.$row, $item['communi_addr_state']);
                $sheet->setCellValue('AV'.$row, $item['PerAddr1']);
                $sheet->setCellValue('AW'.$row, $item['PerAddr2']);
                $sheet->setCellValue('AX'.$row, $item['ComAddr1']);
                $sheet->setCellValue('AY'.$row, $item['ComAddr2']);
                $sheet->setCellValue('AZ'.$row, $item['SchoolName']);
                $sheet->setCellValue('BA'.$row, $item['Sub1Name']);
                $sheet->setCellValue('BB'.$row, $item['Sub1Mark']);
                $sheet->setCellValue('BC'.$row, $item['Sub2Name']);
                $sheet->setCellValue('BD'.$row, $item['Sub2Mark']);
                $sheet->setCellValue('BE'.$row, $item['Sub3Name']);
                $sheet->setCellValue('BF'.$row, $item['Sub3Mark']);
                $sheet->setCellValue('BG'.$row, $item['Sub4Name']);
                $sheet->setCellValue('BH'.$row, $item['Sub4Mark']);
                $sheet->setCellValue('BI'.$row, $item['Sub5Name']);
                $sheet->setCellValue('BJ'.$row, $item['Sub5Mark']);
                $sheet->setCellValue('BK'.$row, $item['Sub6Name']);
                $sheet->setCellValue('BL'.$row, $item['Sub6Mark']);
                $sheet->setCellValue('BM'.$row, $item['HSCMark']);
                $sheet->setCellValue('BN'.$row, $item['HSCMarkPer']);
                $sheet->setCellValue('BO'.$row, $item['MonthAndYearOfPass']);
                $sheet->setCellValue('BP'.$row, $item['StudiedGroup']);
                $sheet->setCellValue('BQ'.$row, $item['HSCRollNo']);
                $sheet->setCellValue('BR'.$row, $item['MediumofStudy']);
                $sheet->setCellValue('BS'.$row, $item['TotalMaxMark']);
                $sheet->setCellValue('BT'.$row, $item['EMISNo']);
                $sheet->setCellValue('BU'.$row, $item['AadharCard']);
                $sheet->setCellValue('BV'.$row, $item['BankPassBook']);
                $sheet->setCellValue('BW'.$row, $item['CommunityCertif']);
                $sheet->setCellValue('BX'.$row, $item['TransferCertif']);
                $sheet->setCellValue('BY'.$row, $item['XthMarkSheet']);
                $sheet->setCellValue('BZ'.$row, $item['XIthMarkSheet']);
                $sheet->setCellValue('CA'.$row, $item['ExaminationPassed']);
                $sheet->setCellValue('CB'.$row, $item['IFSCCode']);
                $sheet->setCellValue('CC'.$row, $item['BankName']);
                $sheet->setCellValue('CD'.$row, $item['BankAddress']);
                $sheet->setCellValue('CE'.$row, $item['AccountNumber']);
                $sheet->setCellValue('CF'.$row, $item['MICRCode']);
                $sheet->setCellValue('CG'.$row, $item['StuDegr']);
                $sheet->setCellValue('CH'.$row, $item['StuDegType']);
                $sheet->setCellValue('CI'.$row, $item['YearofPassing']);
                $sheet->setCellValue('CJ'.$row, $item['UniversityName']);
                $sheet->setCellValue('CK'.$row, $item['InstituionName']);
                $sheet->setCellValue('CL'.$row, $item['StudiedMode']);
                $sheet->setCellValue('CM'.$row, $item['PassPercent']);
                $sheet->setCellValue('CN'.$row, $item['Specialization']);
                $sheet->setCellValue('CO'.$row, $item['DateOfAdmission']);
                $sheet->setCellValue('CP'.$row, $item['RollNo']);
                $sheet->setCellValue('CQ'.$row, $item['DepName']);
                $sheet->setCellValue('CR'.$row, $item['DepCode']);
                $sheet->setCellValue('CS'.$row, $item['CourseYear']);
                $sheet->setCellValue('CT'.$row, $item['CourseNameSD']);
                $sheet->setCellValue('CU'.$row, $item['CourseNameBD']);
                $sheet->setCellValue('CV'.$row, $item['CourseCode']);
                $sheet->setCellValue('CW'.$row, $item['BroSysStudyingStudied']);
                $sheet->setCellValue('CX'.$row, $item['NameBroSys']);
                $sheet->setCellValue('CY'.$row, $item['ModeOFTransport']);
                $sheet->setCellValue('CZ'.$row, $item['BoardingPoint']);
                $sheet->setCellValue('DA'.$row, $item['ImageFileName']);
                $sheet->setCellValue('DB'.$row, $item['ImageContentType']);
                $sheet->setCellValue('DC'.$row, $item['ImageData']);
                $sheet->setCellValue('DD'.$row, $item['Hostel']);
                $sheet->setCellValue('DE'.$row, $item['ScholarShip']);
                $sheet->setCellValue('DF'.$row, $item['ScholarShipType']);
                $sheet->setCellValue('DG'.$row, $item['CharityScholarship']);
                $sheet->setCellValue('DH'.$row, $item['CharityAmount']);
                $sheet->setCellValue('DI'.$row, $item['ManagementScholarship']);
                $sheet->setCellValue('DJ'.$row, $item['Quota']);
                $sheet->setCellValue('DK'.$row, $item['Concession']);
                $sheet->setCellValue('DL'.$row, $item['Remark']);
                $sheet->setCellValue('DM'.$row, $item['Referredby']);
                $sheet->setCellValue('DN'.$row, $item['TCReceivedDate']);
                $sheet->setCellValue('DO'.$row, $item['DocEnclosed']);
                $sheet->setCellValue('DP'.$row, $item['DocNotEnclosed']);
                $sheet->setCellValue('DQ'.$row, $item['InstitutCode']);
                $sheet->setCellValue('DR'.$row, $item['Status']);
                $sheet->setCellValue('DS'.$row, $item['LastDate']);
                $sheet->setCellValue('DT'.$row, $item['Reasonforleaving']);

                $row++;
            }

            // Prepare the spreadsheet for download
           
            $filename = 'Dtudent_DepartmentWise_report' . date('Y-m-d') . '.csv';

            // Write the file to the output
            $writer = new \PhpOffice\PhpSpreadsheet\Writer\Csv($spreadsheet);
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment;filename='.$filename);
            header('Cache-Control: max-age=0');
            $writer->save('php://output');
        } else {
            // Handle case when no data is found
            echo "No data found";
        }
}


public function Student_Class_wise()
    {

    //     print_r($this->input->post());
    // exit;
        // Retrieve POST data
        $institution_name = $this->input->post('Inst_name_1');
        $Inst_codes = $this->input->post('Inst_codes');
        $Department_Name = $this->input->post('department');
        $Course_type = $this->input->post('Course_type');
        $Batch = $this->input->post('Batch');
        $Semester = $this->input->post('Semester');
        $Section = $this->input->post('Section');


        // Example data query (adjust according to your actual data retrieval logic)
        $data = $this->Student_model->get_class_wise_download($institution_name, $Inst_codes, $Department_Name, $Course_type, $Semester, $Batch, $Section);


        // Check if data is available
        if (count($data) > 0) {
            // Initialize PhpSpreadsheet
            $spreadsheet = new Spreadsheet();
            $sheet = $spreadsheet->getActiveSheet();

            // Set header row
            $sheet->setCellValue('A1', 'S.No');
            $sheet->setCellValue('B1', 'Student Id');
            $sheet->setCellValue('C1', 'Name');
            $sheet->setCellValue('D1', 'Department Name');
            $sheet->setCellValue('E1', 'Course Type');
            $sheet->setCellValue('F1', 'Semester');
            $sheet->setCellValue('G1', 'Batch');
            $sheet->setCellValue('H1', 'Section');
            $sheet->setCellValue('I1', 'Father Name');
            $sheet->setCellValue('J1', 'Mother Name');
            $sheet->setCellValue('K1', 'Institution Name');
            $sheet->setCellValue('L1', 'Institution Code');
            $sheet->setCellValue('M1', 'Course Name');
            $sheet->setCellValue('N1', 'Course Type For Previous');
            $sheet->setCellValue('O1', 'Exam Reg No');
            $sheet->setCellValue('P1', 'Initial');
            $sheet->setCellValue('Q1', 'DOB');
            $sheet->setCellValue('R1', 'Place of Birth');
            $sheet->setCellValue('S1', 'Mother Tongue');
            $sheet->setCellValue('T1', 'Father Occupation');
            $sheet->setCellValue('U1', 'Father Income');
            $sheet->setCellValue('V1', 'Blood Group');
            $sheet->setCellValue('W1', 'Mother Occupation');
            $sheet->setCellValue('X1', 'Mother Income');
            $sheet->setCellValue('Y1', 'Aadhar Card No');
            $sheet->setCellValue('Z1', 'Mobile No');
            $sheet->setCellValue('AA1', 'Alternate Mobile No');
            $sheet->setCellValue('AB1', 'Student Mobile Number');
            $sheet->setCellValue('AC1', 'Email Id');
            $sheet->setCellValue('AD1', 'First Language');
            $sheet->setCellValue('AE1', 'Parents');
            $sheet->setCellValue('AF1', 'Religion');
            $sheet->setCellValue('AG1', 'Community');
            $sheet->setCellValue('AH1', 'Caste');
            $sheet->setCellValue('AI1', 'Guardian Name');
            $sheet->setCellValue('AJ1', 'Extra Curricular Activities');
            $sheet->setCellValue('AK1', 'Physical Disability');
            $sheet->setCellValue('AL1', 'Volunteers');
            $sheet->setCellValue('AM1', 'Gender');
            $sheet->setCellValue('AN1', 'Permanent Address Pincode');
            $sheet->setCellValue('AO1', 'Permanent Address Post Office');
            $sheet->setCellValue('AP1', 'Permanent Address District');
            $sheet->setCellValue('AQ1', 'Permanent Address State');
            $sheet->setCellValue('AR1', 'Communication Address Pincode');
            $sheet->setCellValue('AS1', 'Communication Address Post Office');
            $sheet->setCellValue('AT1', 'Communication Address District');
            $sheet->setCellValue('AU1', 'Communication Address State');
            $sheet->setCellValue('AV1', 'Permanent Address Line 1');
            $sheet->setCellValue('AW1', 'Permanent Address Line 2');
            $sheet->setCellValue('AX1', 'Communication Address Line 1');
            $sheet->setCellValue('AY1', 'Communication Address Line 2');
            $sheet->setCellValue('AZ1', 'School Name');
            $sheet->setCellValue('BA1', 'Subject 1 Name');
            $sheet->setCellValue('BB1', 'Subject 1 Mark');
            $sheet->setCellValue('BC1', 'Subject 2 Name');
            $sheet->setCellValue('BD1', 'Subject 2 Mark');
            $sheet->setCellValue('BE1', 'Subject 3 Name');
            $sheet->setCellValue('BF1', 'Subject 3 Mark');
            $sheet->setCellValue('BG1', 'Subject 4 Name');
            $sheet->setCellValue('BH1', 'Subject 4 Mark');
            $sheet->setCellValue('BI1', 'Subject 5 Name');
            $sheet->setCellValue('BJ1', 'Subject 5 Mark');
            $sheet->setCellValue('BK1', 'Subject 6 Name');
            $sheet->setCellValue('BL1', 'Subject 6 Mark');
            $sheet->setCellValue('BM1', 'HSC Mark');
            $sheet->setCellValue('BN1', 'HSC Mark Percentage');
            $sheet->setCellValue('BO1', 'Month and Year of Passing HSC');
            $sheet->setCellValue('BP1', 'Studied Group');
            $sheet->setCellValue('BQ1', 'HSC Roll Number');
            $sheet->setCellValue('BR1', 'Medium of Study');
            $sheet->setCellValue('BS1', 'Total Maximum Marks');
            $sheet->setCellValue('BT1', 'EMIS Number');
            $sheet->setCellValue('BU1', 'Aadhar Card');
            $sheet->setCellValue('BV1', 'Bank Pass Book');
            $sheet->setCellValue('BW1', 'Community Certificate');
            $sheet->setCellValue('BX1', 'Transfer Certificate');
            $sheet->setCellValue('BY1', '10th Mark Sheet');
            $sheet->setCellValue('BZ1', '12th Mark Sheet');
            $sheet->setCellValue('CA1', 'Examination Passed');
            $sheet->setCellValue('CB1', 'IFSC Code');
            $sheet->setCellValue('CC1', 'Bank Name');
            $sheet->setCellValue('CD1', 'Bank Address');
            $sheet->setCellValue('CE1', 'Account Number');
            $sheet->setCellValue('CF1', 'MICR Code');
            $sheet->setCellValue('CG1', 'Student Degree');
            $sheet->setCellValue('CH1', 'Student Degree Type');
            $sheet->setCellValue('CI1', 'Year of Passing');
            $sheet->setCellValue('CJ1', 'University Name');
            $sheet->setCellValue('CK1', 'Institution Name');
            $sheet->setCellValue('CL1', 'Studied Mode');
            $sheet->setCellValue('CM1', 'Pass Percentage');
            $sheet->setCellValue('CN1', 'Specialization');
            $sheet->setCellValue('CO1', 'Date of Admission');
            $sheet->setCellValue('CP1', 'Roll Number');
            $sheet->setCellValue('CQ1', 'Department Name');
            $sheet->setCellValue('CR1', 'Department Code');
            $sheet->setCellValue('CS1', 'Course Year');
            $sheet->setCellValue('CT1', 'Course Name (Short)');
            $sheet->setCellValue('CU1', 'Course Name (Full)');
            $sheet->setCellValue('CV1', 'Course Code');
            $sheet->setCellValue('CW1', 'Brother/Sister Studying/Studied');
            $sheet->setCellValue('CX1', 'Name of Brother/Sister');
            $sheet->setCellValue('CY1', 'Mode of Transport');
            $sheet->setCellValue('CZ1', 'Boarding Point');
            $sheet->setCellValue('DA1', 'Image File Name');
            $sheet->setCellValue('DB1', 'Image Content Type');
            $sheet->setCellValue('DC1', 'Image Data');
            $sheet->setCellValue('DD1', 'Hostel');
            $sheet->setCellValue('DE1', 'Scholarship');
            $sheet->setCellValue('DF1', 'Scholarship Type');
            $sheet->setCellValue('DG1', 'Charity Scholarship');
            $sheet->setCellValue('DH1', 'Charity Amount');
            $sheet->setCellValue('DI1', 'Management Scholarship');
            $sheet->setCellValue('DJ1', 'Quota');
            $sheet->setCellValue('DK1', 'Concession');
            $sheet->setCellValue('DL1', 'Remarks');
            $sheet->setCellValue('DM1', 'Referred by');
            $sheet->setCellValue('DN1', 'TC Received Date');
            $sheet->setCellValue('DO1', 'Documents Enclosed');
            $sheet->setCellValue('DP1', 'Documents Not Enclosed');
            $sheet->setCellValue('DQ1', 'Institution Code');
            $sheet->setCellValue('DR1', 'Status');
            $sheet->setCellValue('DS1', 'Last Date');
            $sheet->setCellValue('DT1', 'Reason for Leaving');

            // Populate data rows
            $row = 2;
            foreach ($data as $index => $item) {
                $sheet->setCellValue('A'.$row, $index + 1);
                $sheet->setCellValue('B'.$row, $item['Student_Id']);
                $sheet->setCellValue('C'.$row, $item['name']);
                $sheet->setCellValue('D'.$row, $item['DepartmentName_1']);
                $sheet->setCellValue('E'.$row, $item['CourseType_1']);
                $sheet->setCellValue('F'.$row, $item['Semester_1']);
                $sheet->setCellValue('G'.$row, $item['Batch_1']);
                $sheet->setCellValue('H'.$row, $item['Section_1']);
                $sheet->setCellValue('I'.$row, $item['father_name']);
                $sheet->setCellValue('J'.$row, $item['mother_name']);
                $sheet->setCellValue('K'.$row, $item['InstitutionName_1']);
                $sheet->setCellValue('L'.$row, $item['Institutioncode_1']);
                $sheet->setCellValue('M'.$row, $item['CourseName_1']);
                $sheet->setCellValue('N'.$row, $item['course_type']);
                $sheet->setCellValue('O'.$row, $item['Exam_Reg_No']);
                $sheet->setCellValue('P'.$row, $item['initial']);
                $sheet->setCellValue('Q'.$row, $item['dob']);
                $sheet->setCellValue('R'.$row, $item['place_of_birth']);
                $sheet->setCellValue('S'.$row, $item['mother_tongue']);
                $sheet->setCellValue('T'.$row, $item['father_occupation']);
                $sheet->setCellValue('U'.$row, $item['father_income']);
                $sheet->setCellValue('V'.$row, $item['blood_group']);
                $sheet->setCellValue('W'.$row, $item['mother_occupation']);
                $sheet->setCellValue('X'.$row, $item['mother_income']);
                $sheet->setCellValue('Y'.$row, $item['aadhar_card_no']);
                $sheet->setCellValue('Z'.$row, $item['mobile_no']);
                $sheet->setCellValue('AA'.$row, $item['alternate_mobile_no']);
                $sheet->setCellValue('AB'.$row, $item['stu_mobile_number']);
                $sheet->setCellValue('AC'.$row, $item['email_id']);
                $sheet->setCellValue('AD'.$row, $item['first_language']);
                $sheet->setCellValue('AE'.$row, $item['parents']);
                $sheet->setCellValue('AF'.$row, $item['religion']);
                $sheet->setCellValue('AG'.$row, $item['community']);
                $sheet->setCellValue('AH'.$row, $item['caste']);
                $sheet->setCellValue('AI'.$row, $item['guardian_name']);
                $sheet->setCellValue('AJ'.$row, $item['extra_curricular_activities']);
                $sheet->setCellValue('AK'.$row, $item['physical_disability']);
                $sheet->setCellValue('AL'.$row, $item['volunteers']);
                $sheet->setCellValue('AM'.$row, $item['gender']);
                $sheet->setCellValue('AN'.$row, $item['per_addr_pincode']);
                $sheet->setCellValue('AO'.$row, $item['per_addr_post_office']);
                $sheet->setCellValue('AP'.$row, $item['per_addr_district']);
                $sheet->setCellValue('AQ'.$row, $item['per_addr_state']);
                $sheet->setCellValue('AR'.$row, $item['communi_addr_pincode']);
                $sheet->setCellValue('AS'.$row, $item['communi_addr_post_office']);
                $sheet->setCellValue('AT'.$row, $item['communi_addr_district']);
                $sheet->setCellValue('AU'.$row, $item['communi_addr_state']);
                $sheet->setCellValue('AV'.$row, $item['PerAddr1']);
                $sheet->setCellValue('AW'.$row, $item['PerAddr2']);
                $sheet->setCellValue('AX'.$row, $item['ComAddr1']);
                $sheet->setCellValue('AY'.$row, $item['ComAddr2']);
                $sheet->setCellValue('AZ'.$row, $item['SchoolName']);
                $sheet->setCellValue('BA'.$row, $item['Sub1Name']);
                $sheet->setCellValue('BB'.$row, $item['Sub1Mark']);
                $sheet->setCellValue('BC'.$row, $item['Sub2Name']);
                $sheet->setCellValue('BD'.$row, $item['Sub2Mark']);
                $sheet->setCellValue('BE'.$row, $item['Sub3Name']);
                $sheet->setCellValue('BF'.$row, $item['Sub3Mark']);
                $sheet->setCellValue('BG'.$row, $item['Sub4Name']);
                $sheet->setCellValue('BH'.$row, $item['Sub4Mark']);
                $sheet->setCellValue('BI'.$row, $item['Sub5Name']);
                $sheet->setCellValue('BJ'.$row, $item['Sub5Mark']);
                $sheet->setCellValue('BK'.$row, $item['Sub6Name']);
                $sheet->setCellValue('BL'.$row, $item['Sub6Mark']);
                $sheet->setCellValue('BM'.$row, $item['HSCMark']);
                $sheet->setCellValue('BN'.$row, $item['HSCMarkPer']);
                $sheet->setCellValue('BO'.$row, $item['MonthAndYearOfPass']);
                $sheet->setCellValue('BP'.$row, $item['StudiedGroup']);
                $sheet->setCellValue('BQ'.$row, $item['HSCRollNo']);
                $sheet->setCellValue('BR'.$row, $item['MediumofStudy']);
                $sheet->setCellValue('BS'.$row, $item['TotalMaxMark']);
                $sheet->setCellValue('BT'.$row, $item['EMISNo']);
                $sheet->setCellValue('BU'.$row, $item['AadharCard']);
                $sheet->setCellValue('BV'.$row, $item['BankPassBook']);
                $sheet->setCellValue('BW'.$row, $item['CommunityCertif']);
                $sheet->setCellValue('BX'.$row, $item['TransferCertif']);
                $sheet->setCellValue('BY'.$row, $item['XthMarkSheet']);
                $sheet->setCellValue('BZ'.$row, $item['XIthMarkSheet']);
                $sheet->setCellValue('CA'.$row, $item['ExaminationPassed']);
                $sheet->setCellValue('CB'.$row, $item['IFSCCode']);
                $sheet->setCellValue('CC'.$row, $item['BankName']);
                $sheet->setCellValue('CD'.$row, $item['BankAddress']);
                $sheet->setCellValue('CE'.$row, $item['AccountNumber']);
                $sheet->setCellValue('CF'.$row, $item['MICRCode']);
                $sheet->setCellValue('CG'.$row, $item['StuDegr']);
                $sheet->setCellValue('CH'.$row, $item['StuDegType']);
                $sheet->setCellValue('CI'.$row, $item['YearofPassing']);
                $sheet->setCellValue('CJ'.$row, $item['UniversityName']);
                $sheet->setCellValue('CK'.$row, $item['InstituionName']);
                $sheet->setCellValue('CL'.$row, $item['StudiedMode']);
                $sheet->setCellValue('CM'.$row, $item['PassPercent']);
                $sheet->setCellValue('CN'.$row, $item['Specialization']);
                $sheet->setCellValue('CO'.$row, $item['DateOfAdmission']);
                $sheet->setCellValue('CP'.$row, $item['RollNo']);
                $sheet->setCellValue('CQ'.$row, $item['DepName']);
                $sheet->setCellValue('CR'.$row, $item['DepCode']);
                $sheet->setCellValue('CS'.$row, $item['CourseYear']);
                $sheet->setCellValue('CT'.$row, $item['CourseNameSD']);
                $sheet->setCellValue('CU'.$row, $item['CourseNameBD']);
                $sheet->setCellValue('CV'.$row, $item['CourseCode']);
                $sheet->setCellValue('CW'.$row, $item['BroSysStudyingStudied']);
                $sheet->setCellValue('CX'.$row, $item['NameBroSys']);
                $sheet->setCellValue('CY'.$row, $item['ModeOFTransport']);
                $sheet->setCellValue('CZ'.$row, $item['BoardingPoint']);
                $sheet->setCellValue('DA'.$row, $item['ImageFileName']);
                $sheet->setCellValue('DB'.$row, $item['ImageContentType']);
                $sheet->setCellValue('DC'.$row, $item['ImageData']);
                $sheet->setCellValue('DD'.$row, $item['Hostel']);
                $sheet->setCellValue('DE'.$row, $item['ScholarShip']);
                $sheet->setCellValue('DF'.$row, $item['ScholarShipType']);
                $sheet->setCellValue('DG'.$row, $item['CharityScholarship']);
                $sheet->setCellValue('DH'.$row, $item['CharityAmount']);
                $sheet->setCellValue('DI'.$row, $item['ManagementScholarship']);
                $sheet->setCellValue('DJ'.$row, $item['Quota']);
                $sheet->setCellValue('DK'.$row, $item['Concession']);
                $sheet->setCellValue('DL'.$row, $item['Remark']);
                $sheet->setCellValue('DM'.$row, $item['Referredby']);
                $sheet->setCellValue('DN'.$row, $item['TCReceivedDate']);
                $sheet->setCellValue('DO'.$row, $item['DocEnclosed']);
                $sheet->setCellValue('DP'.$row, $item['DocNotEnclosed']);
                $sheet->setCellValue('DQ'.$row, $item['InstitutCode']);
                $sheet->setCellValue('DR'.$row, $item['Status']);
                $sheet->setCellValue('DS'.$row, $item['LastDate']);
                $sheet->setCellValue('DT'.$row, $item['Reasonforleaving']);

                $row++;
            }

            // Prepare the spreadsheet for download
            

            $filename = 'student_Class_Wise_report' . date('Y-m-d') . '.csv';

            // Write the file to the output
            $writer = new \PhpOffice\PhpSpreadsheet\Writer\Csv($spreadsheet);
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment;filename='.$filename);
            header('Cache-Control: max-age=0');
            $writer->save('php://output');
        } else {
            // Handle case when no data is found
            echo "No data found";
        }
}


public function Student_absent_report()
{

    print_r($this->input->post());
    exit;
    $institution_name = $this->input->post('Institute_name');
    $date = $this->input->post('date');

    $data = $this->Absent_report_model->get_absent_reports($institution_name, $date);

    if (count($data) > 0) {
        $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        // Set header row
        $sheet->setCellValue('A1', 'S.No');
        $sheet->setCellValue('B1', 'Institution Name');
        $sheet->setCellValue('C1', 'Department Name');
        $sheet->setCellValue('D1', 'Course Name');
        $sheet->setCellValue('E1', 'Total Student');
        $sheet->setCellValue('F1', 'Total Present');
        $sheet->setCellValue('G1', 'Total Absent');
        $sheet->setCellValue('H1', 'OD');
        $sheet->setCellValue('I1', 'Permission');
        $sheet->setCellValue('J1', 'Late');
        $sheet->setCellValue('K1', 'Attendance Date');

        // Populate data rows
        $row = 2;
        foreach ($data as $index => $item) {
            $sheet->setCellValue('A'.$row, $index + 1);
            $sheet->setCellValue('B'.$row, $item->InstitutionName);
            $sheet->setCellValue('C'.$row, $item->DepartmentName);
            $sheet->setCellValue('D'.$row, $item->CourseName);
            $sheet->setCellValue('E'.$row, $item->TotalCount);
            $sheet->setCellValue('F'.$row, $item->PresentCount);
            $sheet->setCellValue('G'.$row, $item->TotalAbsent);
            $sheet->setCellValue('H'.$row, $item->OD);
            $sheet->setCellValue('I'.$row, $item->PermissionCount);
            $sheet->setCellValue('J'.$row, $item->LateCount);
            $sheet->setCellValue('K'.$row, $item->Date);
            $row++;
        }

        $filename = 'Student_Absent_Report_' . date('Y-m-d') . '.xlsx';

        // Write the file to the output
        $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="' . $filename . '"');
        header('Cache-Control: max-age=0');
        $writer->save('php://output');
    } else {
        echo 'No data available for export';
    }
}



public function Staff_Details()
{
    $institution_name = $this->input->post('Inst_name_1');
    $Inst_codes = $this->input->post('Inst_codes');
    $Department_Name = $this->input->post('department');
    
    // Assuming $this->Staff_model->get_Staffs_Details retrieves data from database
    $data = $this->Staff_model->get_Staffs_Details($institution_name, $Inst_codes, $Department_Name);

    // echo '<pre>';
    // print_r($data);
    // exit;

    if (count($data) > 0) {
        // Initialize PhpSpreadsheet
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        // Set header row
        $sheet->setCellValue('A1', 'S.No');
        $sheet->setCellValue('B1', 'Institution Code');
        $sheet->setCellValue('C1', 'Institution Name');
        $sheet->setCellValue('D1', 'Staff Type');
        $sheet->setCellValue('E1', 'Staff ID');
        $sheet->setCellValue('F1', 'Title');
        $sheet->setCellValue('G1', 'Gender');
        $sheet->setCellValue('H1', 'Initial');
        $sheet->setCellValue('I1', 'Name');
        $sheet->setCellValue('J1', 'DOB');
        $sheet->setCellValue('K1', 'Blood Group');
        $sheet->setCellValue('L1', 'Place Of Birth');
        $sheet->setCellValue('M1', 'Marital Status');
        $sheet->setCellValue('N1', 'Religion');
        $sheet->setCellValue('O1', 'Physical Disability');
        $sheet->setCellValue('P1', 'Community');
        $sheet->setCellValue('Q1', 'Caste');
        $sheet->setCellValue('R1', 'Mobile');
        $sheet->setCellValue('S1', 'Email');
        $sheet->setCellValue('T1', 'Aadhar Number');
        $sheet->setCellValue('U1', 'Mother Tongue');
        $sheet->setCellValue('V1', 'Language');
        $sheet->setCellValue('W1', 'IFSC');
        $sheet->setCellValue('X1', 'Bank Name');
        $sheet->setCellValue('Y1', 'Bank Address');
        $sheet->setCellValue('Z1', 'MICR No');
        $sheet->setCellValue('AA1', 'Account No');
        $sheet->setCellValue('AB1', 'PAN Card');
        $sheet->setCellValue('AC1', 'Address');
        $sheet->setCellValue('AD1', 'Address 1');
        $sheet->setCellValue('AE1', 'Postal Code');
        $sheet->setCellValue('AF1', 'Post Office Name');
        $sheet->setCellValue('AG1', 'District');
        $sheet->setCellValue('AH1', 'Department Name');
        $sheet->setCellValue('AI1', 'Course Type');
        $sheet->setCellValue('AJ1', 'Degree');
        $sheet->setCellValue('AK1', 'Passing Year');
        $sheet->setCellValue('AL1', 'University Name');
        $sheet->setCellValue('AM1', 'Institute');
        $sheet->setCellValue('AN1', 'Course Mode Type');
        $sheet->setCellValue('AO1', 'Percentage');
        $sheet->setCellValue('AP1', 'Specialization');
        $sheet->setCellValue('AQ1', 'Course Type 1');
        $sheet->setCellValue('AR1', 'Degree 1');
        $sheet->setCellValue('AS1', 'Passing Year 1');
        $sheet->setCellValue('AT1', 'University Name 1');
        $sheet->setCellValue('AU1', 'Institute 1');
        $sheet->setCellValue('AV1', 'Course Mode Type 1');
        $sheet->setCellValue('AW1', 'Percentage 1');
        $sheet->setCellValue('AX1', 'Specialization 1');
        $sheet->setCellValue('AY1', 'Course Type 2');
        $sheet->setCellValue('AZ1', 'Degree 2');
        $sheet->setCellValue('BA1', 'Passing Year 2');
        $sheet->setCellValue('BB1', 'University Name 2');
        $sheet->setCellValue('BC1', 'Institute 2');
        $sheet->setCellValue('BD1', 'Course Mode Type 2');
        $sheet->setCellValue('BE1', 'Percentage 2');
        $sheet->setCellValue('BF1', 'Specialization 2');
        $sheet->setCellValue('BG1', 'Course Type 3');
        $sheet->setCellValue('BH1', 'Degree 3');
        $sheet->setCellValue('BI1', 'Passing Year 3');
        $sheet->setCellValue('BJ1', 'University Name 3');
        $sheet->setCellValue('BK1', 'Institute 3');
        $sheet->setCellValue('BL1', 'Course Mode Type 3');
        $sheet->setCellValue('BM1', 'Percentage 3');
        $sheet->setCellValue('BN1', 'Specialization 3');
        $sheet->setCellValue('BO1', 'Course Type 4');
        $sheet->setCellValue('BP1', 'Degree 4');
        $sheet->setCellValue('BQ1', 'Passing Year 4');
        $sheet->setCellValue('BR1', 'University Name 4');
        $sheet->setCellValue('BS1', 'Institute 4');
        $sheet->setCellValue('BT1', 'Course Mode Type 4');
        $sheet->setCellValue('BU1', 'Percentage 4');
        $sheet->setCellValue('BV1', 'Specialization 4');
        $sheet->setCellValue('BW1', 'Course Type 5');
        $sheet->setCellValue('BX1', 'Degree 5');
        $sheet->setCellValue('BY1', 'Passing Year 5');
        $sheet->setCellValue('BZ1', 'University Name 5');
        $sheet->setCellValue('CA1', 'Institute 5');
        $sheet->setCellValue('CB1', 'Course Mode Type 5');
        $sheet->setCellValue('CC1', 'Percentage 5');
        $sheet->setCellValue('CD1', 'Specialization 5');
        $sheet->setCellValue('CE1', 'Course Type 6');
        $sheet->setCellValue('CF1', 'Degree 6');
        $sheet->setCellValue('CG1', 'Passing Year 6');
        $sheet->setCellValue('CH1', 'University Name 6');
        $sheet->setCellValue('CI1', 'Institute 6');
        $sheet->setCellValue('CJ1', 'Course Mode Type 6');
        $sheet->setCellValue('CK1', 'Percentage 6');
        $sheet->setCellValue('CL1', 'Specialization 6');

        $row = 2;
         foreach ($data as $index => $item) {
            $sheet->setCellValue('A'.$row, $index + 1);
            $sheet->setCellValue('B'.$row, $item['InstutionCode']);
            $sheet->setCellValue('C'.$row, $item['InstutionName']);
            $sheet->setCellValue('D'.$row, $item['Staff_Type']);
            $sheet->setCellValue('E'.$row, $item['Staff_id']);
            $sheet->setCellValue('F'.$row, $item['Title']);
            $sheet->setCellValue('G'.$row, $item['Gender']);
            $sheet->setCellValue('H'.$row, $item['Initial']);
            $sheet->setCellValue('I'.$row, $item['Name']);
            $sheet->setCellValue('J'.$row, $item['DOB']);
            $sheet->setCellValue('K'.$row, $item['Blood_Group']);
            $sheet->setCellValue('L'.$row, $item['Place_Of_Birth']);
            $sheet->setCellValue('M'.$row, $item['Marital_Status']);
            $sheet->setCellValue('N'.$row, $item['Religion']);
            $sheet->setCellValue('O'.$row, $item['Physical_Disability']);
            $sheet->setCellValue('P'.$row, $item['Community']);
            $sheet->setCellValue('Q'.$row, $item['Caste']);
            $sheet->setCellValue('R'.$row, $item['Mobile']);
            $sheet->setCellValue('S'.$row, $item['Email']);
            $sheet->setCellValue('T'.$row, $item['Aadhar_Number']);
            $sheet->setCellValue('U'.$row, $item['Mother_Tongue']);
            $sheet->setCellValue('V'.$row, $item['Language']);
            $sheet->setCellValue('W'.$row, $item['IFSC']);
            $sheet->setCellValue('X'.$row, $item['Bank_name']);
            $sheet->setCellValue('Y'.$row, $item['Bank_address']);
            $sheet->setCellValue('Z'.$row, $item['MICR_No']);
            $sheet->setCellValue('AA'.$row, $item['Account_No']);
            $sheet->setCellValue('AB'.$row, $item['PAN_Card']);
            $sheet->setCellValue('AC'.$row, $item['Address']);
            $sheet->setCellValue('AD'.$row, $item['Address_1']);
            $sheet->setCellValue('AE'.$row, $item['postal_Code']);
            $sheet->setCellValue('AF'.$row, $item['Post_Office_Name']);
            $sheet->setCellValue('AG'.$row, $item['District']);
            $sheet->setCellValue('AH'.$row, $item['Department_Name']);
            $sheet->setCellValue('AI'.$row, $item['Course_Type']);
            $sheet->setCellValue('AJ'.$row, $item['Degree']);
            $sheet->setCellValue('AK'.$row, $item['Passing_Year']);
            $sheet->setCellValue('AL'.$row, $item['University_Name']);
            $sheet->setCellValue('AM'.$row, $item['Instiute']);
            $sheet->setCellValue('AN'.$row, $item['CourseMode_Type']);
            $sheet->setCellValue('AO'.$row, $item['Percentace']);
            $sheet->setCellValue('AP'.$row, $item['Specialization']);
            $sheet->setCellValue('AQ'.$row, $item['Course_Type1']);
            $sheet->setCellValue('AR'.$row, $item['Degree1']);
            $sheet->setCellValue('AS'.$row, $item['Passing_Year1']);
            $sheet->setCellValue('AT'.$row, $item['University_Name1']);
            $sheet->setCellValue('AU'.$row, $item['Instiute1']);
            $sheet->setCellValue('AV'.$row, $item['CourseMode_Type1']);
            $sheet->setCellValue('AW'.$row, $item['Percentace1']);
            $sheet->setCellValue('AX'.$row, $item['Specialization1']);
            $sheet->setCellValue('AY'.$row, $item['Course_Type2']);
            $sheet->setCellValue('AZ'.$row, $item['Degree2']);
            $sheet->setCellValue('BA'.$row, $item['Passing_Year2']);
            $sheet->setCellValue('BB'.$row, $item['University_Name2']);
            $sheet->setCellValue('BC'.$row, $item['Instiute2']);
            $sheet->setCellValue('BD'.$row, $item['CourseMode_Type2']);
            $sheet->setCellValue('BE'.$row, $item['Percentace2']);
            $sheet->setCellValue('BF'.$row, $item['Specialization2']);
            $sheet->setCellValue('BG'.$row, $item['Course_Type3']);
            $sheet->setCellValue('BH'.$row, $item['Degree3']);
            $sheet->setCellValue('BI'.$row, $item['Passing_Year3']);
            $sheet->setCellValue('BJ'.$row, $item['University_Name3']);
            $sheet->setCellValue('BK'.$row, $item['Instiute3']);
            $sheet->setCellValue('BL'.$row, $item['CourseMode_Type3']);
            $sheet->setCellValue('BM'.$row, $item['Percentace3']);
            $sheet->setCellValue('BN'.$row, $item['Specialization3']);
            $sheet->setCellValue('BO'.$row, $item['Course_Type4']);
            $sheet->setCellValue('BP'.$row, $item['Degree4']);
            $sheet->setCellValue('BQ'.$row, $item['Passing_Year4']);
            $sheet->setCellValue('BR'.$row, $item['University_Name4']);
            $sheet->setCellValue('BS'.$row, $item['Instiute4']);
            $sheet->setCellValue('BT'.$row, $item['CourseMode_Type4']);
            $sheet->setCellValue('BU'.$row, $item['Percentace4']);
            $sheet->setCellValue('BV'.$row, $item['Specialization4']);
            $sheet->setCellValue('BW'.$row, $item['Course_Type5']);
            $sheet->setCellValue('BX'.$row, $item['Degree5']);
            $sheet->setCellValue('BY'.$row, $item['Passing_Year5']);
            $sheet->setCellValue('BZ'.$row, $item['University_Name5']);
            $sheet->setCellValue('CA'.$row, $item['Instiute5']);
            $sheet->setCellValue('CB'.$row, $item['CourseMode_Type5']);
            $sheet->setCellValue('CC'.$row, $item['Percentace5']);
            $sheet->setCellValue('CD'.$row, $item['Specialization5']);
            $sheet->setCellValue('CE'.$row, $item['Course_Type6']);
            $sheet->setCellValue('CF'.$row, $item['Degree6']);
            $sheet->setCellValue('CG'.$row, $item['Passing_Year6']);
            $sheet->setCellValue('CH'.$row, $item['University_Name6']);
            $sheet->setCellValue('CI'.$row, $item['Instiute6']);
            $sheet->setCellValue('CJ'.$row, $item['CourseMode_Type6']);
            $sheet->setCellValue('CK'.$row, $item['Percentace6']);
            $sheet->setCellValue('CL'.$row, $item['Specialization6']);
            $row++;
        }


        $filename = 'Staff_Details_Report_' . date('Y-m-d') . '.csv';

            // Write the file to the output
            $writer = new \PhpOffice\PhpSpreadsheet\Writer\Csv($spreadsheet);
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment;filename='.$filename);
            header('Cache-Control: max-age=0');
            $writer->save('php://output');
    } else {
        echo 'No data available for export';
    }
}


public function HOD_Reports()
{

    // print_r($this->input->post());
    // exit;

    $institution_name = $this->input->post('Inst_name_1');
    $Inst_codes = $this->input->post('Inst_codes');
    // $Department_Name = $this->input->post('department');
    
    // Assuming $this->Staff_model->get_Staffs_Details retrieves data from database
    // $data = $this->TimeTable_model->get_Staffs_Details($institution_name, $Inst_codes, $Department_Name);
    $data = $this->TimeTable_model->get_Hod_Details($institution_name, $Inst_codes);
    


    // echo '<pre>';
    // print_r($data);
    // exit;

    if (count($data) > 0) {
        // Initialize PhpSpreadsheet
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        // Set header row
        $sheet->setCellValue('A1', 'S.No');
        $sheet->setCellValue('B1', 'Institution Name');
        $sheet->setCellValue('C1', 'Institution Code');
        $sheet->setCellValue('D1', 'Department');
        $sheet->setCellValue('E1', 'Hod Names');
      

        $row = 2;
         foreach ($data as $index => $item) {
            $sheet->setCellValue('A'.$row, $index + 1);
            $sheet->setCellValue('B'.$row, $item['InstitutionName']);
            $sheet->setCellValue('C'.$row, $item['InstitutionCode']);
            $sheet->setCellValue('D'.$row, $item['Department']);
            $sheet->setCellValue('E'.$row, $item['Hod_Name']);
            $row++;
        }


        $filename = 'Staff_Details_Report_' . date('Y-m-d') . '.csv';

            // Write the file to the output
            $writer = new \PhpOffice\PhpSpreadsheet\Writer\Csv($spreadsheet);
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment;filename='.$filename);
            header('Cache-Control: max-age=0');
            $writer->save('php://output');
    } else {
        echo 'No data available for export';
    }
}


}



