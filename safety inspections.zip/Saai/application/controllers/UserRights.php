<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


class UserRights extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();

		$this->load->helper('url');
		$this->load->helper('form');
		$this->load->helper('file');
		$this->load->model('UserRight_model');
		$this->load->library('session');
	}

	public function rights()
	{
		$username = $this->session->userdata('userdata');
		if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {

			$this->load->view('Frontend/header');
			$this->load->view('Frontend/sidebar');
			$this->load->view('UserRights/index');
			$this->load->view('Frontend/footer');
		} else {
			redirect('Auth', 'refresh');
		}
	}

	public function Get_UserType()
	{
		$username = $this->session->userdata('userdata');
		if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {

			$this->data['Get_Menu'] = $Get_Menu = $this->UserRight_model->get_menus();
			echo json_encode($Get_Menu);
		} else {
			redirect('Auth', 'refresh');
		}
	}

	public function Get_SubMenus()
	{
		$username = $this->session->userdata('userdata');
		if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {

			$Menus = $this->input->post('selectedValue');
			$usertype = $this->input->post('user');
			$this->data['get_active_details'] = $get_active_details = $this->UserRight_model->get_active_details($Menus,$usertype);
			$this->data['Get_SubMenu'] = $Get_SubMenu = $this->UserRight_model->get_sub_menus($Menus);
			echo json_encode($this->data);
		} else {
			redirect('Auth', 'refresh');
		}
	}
	public function Delete_old_data()
	{
		$username = $this->session->userdata('userdata');
		if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {

			$selectedUserType = $this->input->post('selectedUserType');
			$selectedMenuId = $this->input->post('selectedMenuId');

			// print_r($selectedUserType ." ".$selectedMenuId);exit;	

			$this->data['delete_priviopus'] = $delete_priviopus = $this->UserRight_model->delete_priviopus($selectedUserType, $selectedMenuId);
			echo json_encode($delete_priviopus);
		} else {
			redirect('Auth', 'refresh');
		}
	}

	public function Insert_new_data()
	{
		$username = $this->session->userdata('userdata');
		if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {

			$checkbox = $this->input->post('checkboxIds');
			$UserType = $this->input->post('selectedUserType');
			$MenuId = $this->input->post('selectedMenuId');
			$rowDataArray = json_decode($checkbox, true);

			foreach ($rowDataArray as $rowData) {

				$FormName = $rowData['FormName'];
				$Add = $rowData['Add'];
				$delete = $rowData['Delete'];
				$Edit = $rowData['Edit'];
				$View = $rowData['View'];

				$data = array(
					'UserType' => $UserType,
					'Menus' => $MenuId,
					'SubMenus' => $FormName,
					'Adds' => $Add,
					'Deletes' => $delete,
					'Edits' => $Edit,
					'Views ' => $View
				);

				$this->data['user_rights_save'] = $user_rights_save = $this->UserRight_model->user_rights_save($data);
				echo json_encode($user_rights_save);
			}
		} else {
			redirect('Auth', 'refresh');
		}
	}
}
