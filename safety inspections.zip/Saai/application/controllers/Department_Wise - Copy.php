<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Department_Wise extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->helper('form');
        $this->load->helper('file');
        $this->load->model('Department_wise_model');
        $this->load->library('session');
        $this->load->library('form_validation');
    }
    public function index()
    {
        $username = $this->session->userdata('userdata');

        if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {
            $this->data['DepartmentName'] = $username['DepartmentName'];
            $this->data['InstitutionName'] = $username['InstitutionName'];

            $this->load->view('Frontend/header');
            $this->load->view('Frontend/sidebar');
            $this->load->view('TimeTable/Department_Wise_TimeTable',$this->data);
            $this->load->view('Frontend/footer');
        } else {

            redirect('Auth', 'refresh');
        }
    }

    // Endpoint to fetch session data
    public function fetchSessionData()
    {
        $username = $this->session->userdata('userdata');
        if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {
            $this->data['InstitutionName'] = $username['InstitutionName'];
            $this->data['DepartmentName'] = $username['DepartmentName'];
            echo json_encode($this->data);
        } else {
            echo json_encode(array('error' => 'Unauthorized'));
        }
    }


    public function get_departs()
    {
        $username = $this->session->userdata('userdata');
        if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {

            $Institution_name= $this->input->post('instname');
            $department = $this->Department_wise_model->get_departs1( $Institution_name);

            echo json_encode($department);
        } else {
            redirect('Auth', 'refresh');
        }
    }

    public function get_staff_Id()
    {
        $username = $this->session->userdata('userdata');
        if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {
            $department = $this->input->post('selectedValue');
            $get_Staff = $this->Department_wise_model->get_staffs_Id($department);
            // echo"<pre>";
            // print_r($get_Staff);
            // exit;
            echo json_encode($get_Staff);
        } else {
            redirect('Auth', 'refresh');
        }
    }
    public function get_staff()
    {
        $username = $this->session->userdata('userdata');
        if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {
            $Staff_Id = $this->input->post('selectedValue');
            $get_Staff = $this->Department_wise_model->get_staffs($Staff_Id);
            // echo"<pre>";
            // print_r($get_Staff);
            // exit;
            echo json_encode($get_Staff);
        } else {
            redirect('Auth', 'refresh');
        }
    }

    public function get_subjects()
{
    $username = $this->session->userdata('userdata');
    if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {
        $Institution_name = $this->input->post('Institution_name');
        $Department = $this->input->post('Department');
        $courseType = $this->input->post('courseType');
        $CourseCode = $this->input->post('CourseCode');
        $Batch = $this->input->post('Batch');
        $Semesters = $this->input->post('Semesters');
        
        $courses = $this->Department_wise_model->get_subjects($Institution_name,$Department, $courseType, $CourseCode,$Batch,$Semesters);
        echo json_encode($courses);
    } else {
        redirect('Auth', 'refresh'); // Redirect if user is not logged in
    }
}

    public function get_Hod()
    {
        $username = $this->session->userdata('userdata');
        if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {
            $department = $this->input->post('selectedValue');
            $courses = $this->Department_wise_model->get_Hod_Name($department);
          
            echo json_encode($courses);
        } else {
            redirect('Auth', 'refresh'); // Redirect if user is not logged in
        }
    }

    public function course()
    {
        $username = $this->session->userdata('userdata');
        if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {
            $department = $this->input->post('selectedValue');
            $courses = $this->Department_wise_model->get_course($department);
            // echo '<pre>';
            // print_r($courses);
            // exit;
            echo json_encode($courses);
        } else {
            redirect('Auth', 'refresh'); // Redirect if user is not logged in
        }
    }

    public function course_code()
    {
        $username = $this->session->userdata('userdata');
        if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {
            $department = $this->input->post('department');
            $courseType = $this->input->post('courseType'); // Added courseType parameter
            $courses = $this->Department_wise_model->get_course_code($department, $courseType);
            //   echo '<pre>';
            // print_r($courses);
            // exit;
            echo json_encode($courses);
        } else {
            redirect('Auth', 'refresh'); // Redirect if user is not logged in
        }
    }




    public function Section_Batch1()
    {
        $username = $this->session->userdata('userdata');
        if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {
            $Department = $this->input->post('Department');
            $courseType = $this->input->post('courseType');
            $courses = $this->Department_wise_model->get_Section_Batch($Department, $courseType);
            echo json_encode($courses);
        } else {
            redirect('Auth', 'refresh'); // Redirect if user is not logged in
        }
    }

    public function Section0()
    {
        $username = $this->session->userdata('userdata');
        if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {
            $Department = $this->input->post('Department');
            $courseType = $this->input->post('courseType');
            $batch = $this->input->post('batch');
            $courses = $this->Department_wise_model->get_Section($Department, $courseType, $batch);
            echo json_encode($courses);
        } else {
            redirect('Auth', 'refresh'); // Redirect if user is not logged in
        }
    }



    public function get_departs11()
    {
        $username = $this->session->userdata('userdata');
        if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {
            $Class_Section = $this->Department_wise_model->get_departs_11();
            echo json_encode($Class_Section);
        } else {
            redirect('Auth', 'refresh');
        }
    }




    public function Course_type1()
    {
        $username = $this->session->userdata('userdata');
        if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {
            $department_name = $this->input->post('department_name');
            // Fetch course types based on department name from the model
            $course_types = $this->Department_wise_model->get_course_types_by_department($department_name);

            // Prepare JSON response
            echo json_encode($course_types);
        } else {
            redirect('Auth', 'refresh');
        }
    }

    public function get_section11()
    {
        $username = $this->session->userdata('userdata');
        if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {
            $course_types = $this->input->post('courseType');
            $department_name = $this->input->post('department_name');
            $Class_Section = $this->Department_wise_model->get_section2($course_types, $department_name);
            echo json_encode($Class_Section);
        } else {
            redirect('Auth', 'refresh');
        }
    }



    public function Section231()
    {
        $username = $this->session->userdata('userdata');
        if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {
            $course_types = $this->input->post('courseType');
            $department_name = $this->input->post('department_name');
            $Batch = $this->input->post('Batch');

            // print_r($_POST);
            // exit;   


            $Class_Section = $this->Department_wise_model->Section231($course_types, $department_name, $Batch);
            echo json_encode($Class_Section);
        } else {
            redirect('Auth', 'refresh');
        }
    }

   
public function get_timetable1()
{
    $username = $this->session->userdata('userdata');
    if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {
        $department_name = $this->input->post('department_name');
        $course_type = $this->input->post('courseType');
        $batch = $this->input->post('Batch');
        $semester = $this->input->post('Semester');
        $section = $this->input->post('section');

        // Fetch timetable data based on department, course type, and section
        $timetable_data = $this->Department_wise_model->get_timetable_data($department_name, $course_type, $batch, $semester, $section);

        echo json_encode($timetable_data);
    } else {
        // Handle case when the user is not authenticated
        echo json_encode([]);
    }

}
    public function add_Staff1()
    {

        // print_r($_POST);
        // exit;
        // Form validation rules
        $this->form_validation->set_rules('Institute_name', 'Institute Name', 'required');
        $this->form_validation->set_rules('Department', 'Department', 'required');
        $this->form_validation->set_rules('Hod', 'Hod', 'required');
        $this->form_validation->set_rules('Staff_Name', 'Staff Name', 'required');
        $this->form_validation->set_rules('Staff_ID', 'Staff_ID', 'required');
        $this->form_validation->set_rules('Dayss', 'Dayss', 'required');
        $this->form_validation->set_rules('Date', 'Date');
        $this->form_validation->set_rules('Shift', 'Shift');
        $this->form_validation->set_rules('Course_Type', 'courseType',);
        $this->form_validation->set_rules('CourseCode', 'CourseCode', 'required');
        $this->form_validation->set_rules('Class_Section', 'Class Section', 'required');
        $this->form_validation->set_rules('Subjects', 'Subjects');
        $this->form_validation->set_rules('Batch', 'batch');
        $this->form_validation->set_rules('Semester', 'Semester');


        // Form validation
        if ($this->form_validation->run() == FALSE) {
            $response = array('status' => 'error', 'message' => validation_errors());
            echo json_encode($response);
        } else {
            $selectedHours = $this->input->post('selectedHours');
            $data = array(
                'Institute_name' => $this->input->post('Institute_name'),
                'Department' => $this->input->post('Department'),
                'Hod' => $this->input->post('Hod'),
                'Staff_name' => $this->input->post('Staff_Name'),
                'Assign_Staff_Id' => $this->input->post('Staff_ID'),
                'Dayss' => $this->input->post('Dayss'),
                'Date' => $this->input->post('Date'),
                'Shift' => $this->input->post('Shift'),
                'Course_type' => $this->input->post('courseType'),
                'CourseCode' => $this->input->post('CourseCode'),
                'Class_Section' => $this->input->post('Class_Section'),
                'Subjects' => $this->input->post('Subjects'),
                'Batch' => $this->input->post('batch'),
                'Semester' => $this->input->post('Semester'),
                'Hour_1' => in_array('1', $selectedHours) ? 1 : 0,
                'Hour_2' => in_array('2', $selectedHours) ? 1 : 0,
                'Hour_3' => in_array('3', $selectedHours) ? 1 : 0,
                'Hour_4' => in_array('4', $selectedHours) ? 1 : 0,
                'Hour_5' => in_array('5', $selectedHours) ? 1 : 0,
                'Hour_6' => in_array('6', $selectedHours) ? 1 : 0,
            );

         

            // Check for duplicate entry
            $exists = $this->Department_wise_model->check_duplicate_entry(
                $this->input->post('Dayss'),
                $data['Hour_1'],
                $data['Hour_2'],
                $data['Hour_3'],
                $data['Hour_4'],
                $data['Hour_5'],
                $data['Hour_6'],
            );

            if ($exists == true) {
                $true = 'true';
                $response = array('status' => 'error', 'message' => 'Duplicate entry found.');
                echo json_encode($true);
            } else {
                // Insert data into database
                $inserted_id = $this->Department_wise_model->insert_timetable($data);

                if ($inserted_id) {
                    $response = array('status' => 'success', 'message' => 'Data inserted successfully.');
                    echo json_encode($inserted_id);
                } else {
                    $response = array('status' => 'error', 'message' => 'Failed to insert data.');
                    echo json_encode($response);
                }
            }
        }
    }

    public function Semaster()
{
    $username = $this->session->userdata('userdata');
    if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {
        $Institution_name = $this->input->post('Institution_name');
        $Department = $this->input->post('Department');
        $courseType = $this->input->post('courseType');
        
        $courses = $this->Department_wise_model->Get_Semaster($Institution_name,$Department, $courseType);
        echo json_encode($courses);
    } else {
        redirect('Auth', 'refresh'); // Redirect if user is not logged in
    }
}

public function Get_Semaster() {
    $username = $this->session->userdata('userdata');
    if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {
    $department_name = $this->input->post('Department');
    $courseType = $this->input->post('courseType');
    $data = $this->Department_wise_model->getSemesters($department_name, $courseType);
    echo json_encode($data);
} else {
    redirect('Auth', 'refresh'); // Redirect if user is not logged in
}

}}
