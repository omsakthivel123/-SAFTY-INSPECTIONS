<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Student Module/</span>Semester Report</h4>

        <!-- Basic Layout & Basic with Icons -->

        <div class="row">

            <!-- Basic Layout -->
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-body">

                        <div class="row">
                            <div class="col-sm-12">
                                <!-- Material tab card start -->
                                <div class="card">
                                    <div class="card-block">
                                        <div class="row py-3">

                                            <div class="col-md-3">
                                                <label for="InstutionName" class="text-dark"> Instution</label>
                                                <select name="InstutionName" class="form-control" id="InstutionName" required></select>
                                            </div>
                                            <div class="col-md-3">
                                                <label for="Course_type" class="text-dark">Course Type</label>
                                                <select name="Course_type" class="form-control" id="Course_type" required></select>
                                            </div>
                                            <div class="col-md-3">
                                                <label for="DepartmentName" class="text-dark">Department</label>
                                                <select name="DepartmentName" class="form-control" id="DepartmentName" required> </select>
                                            </div>
                                            <div class="col-md-3">
                                                <label for="Batch" class="text-dark">Batch</label>
                                                <select name="Batch" class="form-control" id="Batch" required> </select>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-3">
                                                <label for="Course_name" class="text-dark">Course Name</label>
                                                <select name="Course_name" class="form-control" id="Course_name" required> </select>
                                            </div>
                                            <div class="col-md-3">
                                                <label for="Section" class="text-dark">Section</label>
                                                <select name="Section" class="form-control" id="Section" required> </select>
                                            </div>
                                            <div class="col-md-3">
                                                <label for="Semester" class="text-dark">Semester</label>
                                                <select name="Semester" class="form-control" id="Semester" required> </select>
                                            </div>

                                        </div>
                                        <div class="row justify-content-end py-3" id="view-btn">
                                            <div class="col-auto">
                                                <button type="button" class="btn btn-outline-danger btn-sm" id="get_sem_data">View</button>
                                            </div>
                                        </div>



                                    </div>

                                    <!-- Row start -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card mb-4" id="semester-view">
                    <div class="card-body">
                        <div class="row">
                            <div id="semester-record">
                                <div id="table-container" style="overflow-x: auto;">
                                    <table id="sheet" class="table table-striped">
                                        <thead style="background-color: #302c63; color: white;">
                                            <tr>
                                                <th>S.No</th>
                                                <th>Student ID</th>
                                                <th> Exam Reg No</th>
                                                <th>Semester</th>
                                                <th>Name</th>
                                                <th>Total Present</th>
                                                <th>Total Absent</th>
                                                <th>Percentage</th>
                                                <th>Total Days</th>
                                                <th>Created By</th>
                                            </tr>
                                        </thead>
                                        <tbody id="sem_stud">

                                        </tbody>
                                    </table>

                                </div>
                            </div>

                        </div>
                    </div>
                </div>

            </div>