<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">User Rights/</span>Rights</h4>

        <!-- Basic Layout & Basic with Icons -->
        <div class="row">
            <!-- Basic Layout -->
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-12">
                                <!-- Material tab card start -->
                                <div class="card">
                                    <div class="card-block">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <label for="Users" class="text-dark">User Type</label>
                                                <select name="Users" class="form-control" id="User_Type" required>
                                                    <option value="Select">Select UserType</option>
                                                    <option value="Admin">Admin</option>
                                                    <option value="HOD">HOD</option>
                                                    <option value="Staff">Staff</option>
                                                    <option value="Student">Student</option>
                                                </select>
                                            </div>
                                            <div class="col-md-4">
                                                <label for="Menus">Menus</label>
                                                <select name="Menus_id" class="form-control" id="Menus_id" required></select>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Row start -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card mb-4">
                    <div class="card-body">
                        <!-- Table Container Row Start -->
                        <div class="row">
                            <div class="col-sm-12">
                                <!-- Material tab card start -->
                                <div class="card">
                                    <div class="card-block py-4">
                                        <form id="myForm">
                                            <table id="table" class="table table-bordered" style="width:100%">
                                                <thead>
                                                    <tr>
                                                        <th>Sub Menus</th>
                                                        <th>Screens</th>
                                                        <th>Delete</th>
                                                        <th>Edit</th>
                                                        <th>View</th>
                                                    </tr>
                                                </thead>
                                                <tbody id="good"></tbody>
                                            </table>

                                        </form>


                                    </div>
                                    <div class="d-flex justify-content-end">
                                        <button class="btn btn-outline-danger btn-sm " type="button" id="Form-Update">Cancel</button>
                                        <button class="btn btn-outline-primary btn-sm ml-2" type="button" id="form_data">Submit</button>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Table Container Row End -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>