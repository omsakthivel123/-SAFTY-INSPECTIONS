<body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
        <div class="layout-container">
            <!-- sidebar -->
            <!-- Menu -->

            <aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
                <div class="app-brand demo">

                    <img src="<?php echo base_url('assets/img/logo/avc.png') ?>" width="180px" height="50" alt="subaranahg">

                    <!-- <span class="app-brand-text demo menu-text fw-bold text-capitalize ms-2">AVCAS</span> -->
                    </a>

                    <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
                        <i class="bx bx-chevron-left bx-sm align-middle"></i>
                    </a>
                </div>

                <div class="menu-inner-shadow"></div>
                <?php
                $UserData = $this->session->userdata('userdata');
                if (!empty($UserData) && isset($UserData['IsOnLogin']) && $UserData['IsOnLogin'] === true) {
                    $us_code = $UserData['UserCode'];
                    $S_Code = $this->db->query('SELECT * FROM Web_UserManagement WHERE UserCode = ?', array($us_code));
                    $S_c = $S_Code->row();
                    if ($S_Code->num_rows() > 0 && $S_c->UserRole == "Student") {

                ?>


                        <ul class="menu-inner py-1">
                            <!-- Dashboards -->
                            <li class="menu-item active open">
                                <a href="<?php echo base_url('Home') ?>" class="menu-link">
                                    <i class="menu-icon tf-icons bx bx-home-circle"></i>
                                    <div data-i18n="Dashboards">Dashboards</div>
                                    <div class="badge bg-danger rounded-pill ms-auto">5</div>
                                </a>
                            </li>

                            <li class="menu-item">
                                <a href="javascript:void(0);" class="menu-link menu-toggle">
                                    <i class="menu-icon tf-icons bx bx-layout"></i>
                                    <div data-i18n="Layouts">Management</div>
                                </a>
                                <ul class="menu-sub">
                                    <li class="menu-item">
                                        <a href="<?php echo base_url('Management') ?>" class="menu-link">
                                            <div data-i18n="Without menu">Fees Assign</div>
                                        </a>
                                    </li>
                                    <li class="menu-item">
                                        <a href="<?php echo base_url('Staff_Attendance') ?>" class="menu-link">
                                            <div data-i18n="Without navbar">Attendance</div>
                                        </a>
                                    </li>
                                    <li class="menu-item">
                                        <a href="<?php echo base_url('staff/privilege') ?>" class="menu-link">
                                            <div data-i18n="Without menu">Privilege</div>
                                        </a>
                                    </li>

                                </ul>
                            </li>

                            <li class="menu-item">
                                <a href="javascript:void(0);" class="menu-link menu-toggle">
                                    <i class="menu-icon tf-icons bx bx-layout"></i>
                                    <div data-i18n="Layouts">HOD</div>
                                </a>


                                <ul class="menu-sub">
                                    <li class="menu-item">
                                        <a href="<?php echo base_url('staff/hod') ?>" class="menu-link">
                                            <div data-i18n="Without menu">Leave And Permission</div>
                                        </a>
                                    </li>
                                    <!-- <li class="menu-item">
                                    <a href="<?php echo base_url('UserRights/rights') ?>" class="menu-link">
                                        <div data-i18n="Without navbar">Super Admin</div>
                                    </a>
                                </li> -->

                                </ul>
                            </li>

                            <!-- Layouts -->
                            <li class="menu-item">
                                <a href="javascript:void(0);" class="menu-link menu-toggle">
                                    <i class="menu-icon tf-icons bx bx-layout"></i>
                                    <div data-i18n="Layouts">User Rights</div>
                                </a>


                                <ul class="menu-sub">
                                    <li class="menu-item">
                                        <a href="<?php echo base_url('Home/sample') ?>" class="menu-link">
                                            <div data-i18n="Without menu">Admin</div>
                                        </a>
                                    </li>
                                    <li class="menu-item">
                                        <a href="<?php echo base_url('UserRights/rights') ?>" class="menu-link">
                                            <div data-i18n="Without navbar">Set Users Rights</div>
                                        </a>
                                    </li>

                                </ul>
                            </li>


                            <li class="menu-item">
                                <a href="javascript:void(0);" class="menu-link menu-toggle">
                                    <i class="menu-icon tf-icons bx bx-layout"></i>
                                    <div data-i18n="Layouts">Time Table</div>
                                </a>


                                <ul class="menu-sub">
                                    <li class="menu-item">
                                        <a href="<?php echo base_url('timetable') ?>" class="menu-link">
                                            <div data-i18n="Without menu">Assign Time Table</div>
                                        </a>
                                    </li>
                                    <li class="menu-item">
                                        <a href="<?php echo base_url('department_Wise') ?>" class="menu-link">
                                            <div data-i18n="Without navbar">Department Wise TimeTable </div>
                                        </a>
                                    </li>
                                    <li class="menu-item">
                                        <a href="<?php echo base_url('student_timetable') ?>" class="menu-link">
                                            <div data-i18n="Without navbar">Student TimeTable</div>
                                        </a>
                                    </li>
                                    <li class="menu-item">
                                        <a href="<?php echo base_url('substitution') ?>" class="menu-link">
                                            <div data-i18n="Without navbar">Assign Substitution</div>
                                        </a>
                                    </li>

                                </ul>
                            </li>

                            <li class="menu-item">
                                <a href="javascript:void(0);" class="menu-link menu-toggle">
                                    <i class="menu-icon tf-icons bx bx-layout"></i>
                                    <div data-i18n="Layouts">Department</div>
                                </a>


                                <ul class="menu-sub">
                                    <li class="menu-item">
                                        <a href="<?php echo base_url('Department') ?>" class="menu-link">
                                            <div data-i18n="Without menu">Assign Class Incharge</div>
                                        </a>
                                    </li>
                                    <!-- <li class="menu-item">
                                    <a href="<?php echo base_url('UserRights/rights') ?>" class="menu-link">
                                        <div data-i18n="Without navbar">Super Admin</div>
                                    </a>
                                </li> -->

                                </ul>
                            </li>

                            <li class="menu-item">
                                <a href="javascript:void(0);" class="menu-link menu-toggle">
                                    <i class="menu-icon tf-icons bx bx-layout"></i>
                                    <div data-i18n="Layouts">Subject</div>
                                </a>


                                <ul class="menu-sub">
                                    <li class="menu-item">
                                        <a href="<?php echo base_url('subject') ?>" class="menu-link">
                                            <div data-i18n="Without menu">Add Subject</div>
                                        </a>
                                    </li>
                                    <li class="menu-item">
                                    <a href="<?php echo base_url('coursementor') ?>" class="menu-link">
                                        <div data-i18n="Without navbar">Course Mentor</div>
                                    </a>
                                </li>

                                </ul>
                            </li>


                            <li class="menu-item">
                                <a href="javascript:void(0);" class="menu-link menu-toggle">
                                    <i class="menu-icon tf-icons bx bx-layout"></i>
                                    <div data-i18n="Layouts">Exam Schedule</div>
                                </a>


                                <ul class="menu-sub">
                                    <li class="menu-item">
                                        <a href="<?php echo base_url('exam_schedule') ?>" class="menu-link">
                                            <div data-i18n="Without menu">Exam Schedule</div>
                                        </a>
                                    </li>
                                    <!-- <li class="menu-item">
                                    <a href="<?php echo base_url('coursementor') ?>" class="menu-link">
                                        <div data-i18n="Without navbar">Course Montor</div>
                                    </a>
                                </li> -->

                                </ul>
                            </li>


                            <li class="menu-item">
                                <a href="javascript:void(0);" class="menu-link menu-toggle">
                                    <i class="menu-icon tf-icons bx bx-layout"></i>
                                    <div data-i18n="Layouts">Grading System</div>
                                </a>


                                <ul class="menu-sub">
                                    <li class="menu-item">
                                        <a href="<?php echo base_url('gradingsystem') ?>" class="menu-link">
                                            <div data-i18n="Without menu">Student Mark Entry</div>
                                        </a>
                                    </li>
                                    <li class="menu-item">
                                    <a href="<?php echo base_url('gradingsystem/report') ?>" class="menu-link">
                                        <div data-i18n="Without navbar">Student Marks Report</div>
                                    </a>
                                </li>
                                <li class="menu-item">
                                    <a href="<?php echo base_url('gradingsystem/overall_report') ?>" class="menu-link">
                                        <div data-i18n="Without navbar">Student Overall Marks </div>
                                    </a>
                                </li>

                                </ul>
                    </li>
                            <li class="menu-item">
                                <a href="javascript:void(0);" class="menu-link menu-toggle">
                                    <i class="menu-icon tf-icons bx bx-layout"></i>
                                    <div data-i18n="Layouts">Staff</div>
                                </a>
                                <ul class="menu-sub">
                                    <li class="menu-item">
                                        <a href="<?php echo base_url('staff') ?>" class="menu-link">
                                            <div data-i18n="Without menu">Add New Staff</div>
                                        </a>
                                    </li>
                                    <li class="menu-item">
                                        <a href="<?php echo base_url('Staff_Attendance') ?>" class="menu-link">
                                            <div data-i18n="Without navbar">Attendance</div>
                                        </a>
                                    </li>
                                    <li class="menu-item">
                                        <a href="<?php echo base_url('staff/privilege') ?>" class="menu-link">
                                            <div data-i18n="Without menu">Privilege</div>
                                        </a>
                                    </li>

                                </ul>
                            </li>


                            <!-- Front Pages -->
                            <li class="menu-item">
                                <a href="javascript:void(0);" class="menu-link menu-toggle">
                                    <i class="menu-icon tf-icons bx bx-layout"></i>
                                    <div data-i18n="Layouts">Student Module</div>
                                </a>


                                <ul class="menu-sub">
                                    <li class="menu-item">
                                        <a href="<?php echo base_url('Student') ?>" class="menu-link">
                                            <div data-i18n="Without menu">Add New Statudent</div>
                                        </a>
                                    </li>
                                    <li class="menu-item">
                                        <a href="<?php echo base_url('student_attendance') ?>" class="menu-link">
                                            <div data-i18n="Without navbar">Student Attendance</div>
                                        </a>
                                    </li>
                                    <li class="menu-item">
                                        <a href="<?php echo base_url('semester_attendance') ?>" class="menu-link">
                                            <div data-i18n="Without navbar">Semester Attendance</div>
                                        </a>
                                    </li>


                                </ul>

                                </li>

                               

                            <li class="menu-item">
                                <a href="javascript:void(0);" class="menu-link menu-toggle">
                                    <i class="menu-icon tf-icons bx bx-layout"></i>
                                    <div data-i18n="Layouts">SMS</div>
                                </a>


                                <ul class="menu-sub">
                                <li class="menu-item">
                                        <a href="<?php echo base_url('sms') ?>" class="menu-link">
                                            <div data-i18n="Without navbar">Student SMS</div>
                                        </a>
                                    </li>
                                    <!-- <li class="menu-item">
                                        <a href="<?php echo base_url('Staff_Attendance') ?>" class="menu-link">
                                            <div data-i18n="Without navbar">Staff Attendance</div>
                                        </a>
                                    </li> -->

                                </ul>
                            </li>


                            

                            <!-- Front Pages -->
                            <!-- <li class="menu-item ">
                                <a href="<?php echo base_url('') ?>" class="menu-link">
                                    <i class="menu-icon tf-icons bx bx-home-circle"></i>
                                    <div data-i18n="Dashboards"> Attendance</div>
                                    <div class="badge bg-danger rounded-pill ms-auto">5</div>
                                </a>
                            </li> -->

                          
                            

                        </ul>
                        <!-- </aside> -->
                         
                        <?php } else {  


                        $username = $this->session->userdata('userdata');
                        if (!empty($username) && isset($username['IsOnLogin']) && $username['IsOnLogin'] === TRUE) {
                            $usertype = $UserData['UserRole'];

                            // Fetching menus based on user rights
                            $Menus = $this->db->query("SELECT DISTINCT Menus FROM Web_User_Rights_Mst WHERE UserType = '$usertype' AND Adds = '1'");
                            $MenuRows = $Menus->result();

                            // print_r( $MenuRows );exit;

                            foreach ($MenuRows as $menuRow) {
                                $menuName = $menuRow->Menus;


                                // Fetching submenu items based on user rights and menu
                                $SubMenus = $this->db->query("SELECT DISTINCT SubMenus FROM Web_User_Rights_Mst WHERE UserType = '$usertype' AND Adds = '1' AND Menus = '$menuName'");
                                $SubMenuRows = $SubMenus->result();

                                // print_r($SubMenuRows);

                                // print_r( $SubMenuRows);

                                if ($menuName == 'Dashboards') { ?>

                                    <ul class="menu-inner py-1">
                                        <!-- Dashboards -->
                                        <li class="menu-item active open">
                                            <a href="<?php echo base_url('Home') ?>" class="menu-link">
                                                <i class="menu-icon tf-icons bx bx-home-circle"></i>
                                                <div data-i18n="Dashboards">Dashboards</div>
                                                <div class="badge bg-danger rounded-pill ms-auto">5</div>
                                            </a>
                                        </li>
                                    <?php

                                } else if ($menuName == 'TimeTable') {?>

                                    <li class="menu-item">
                                    <a href="javascript:void(0);" class="menu-link menu-toggle">
                                        <i class="menu-icon tf-icons bx bx-layout"></i>
                                        <div data-i18n="Layouts">Time Table</div>
                                    </a>
    
    
                                    <ul class="menu-sub">
                                        <li class="menu-item">
                                            <a href="<?php echo base_url('TimeTable') ?>" class="menu-link">
                                                <div data-i18n="Without menu">Assign Time Table</div>
                                            </a>
                                        </li>
                                        <li class="menu-item">
                                            <a href="<?php echo base_url('Department_Wise') ?>" class="menu-link">
                                                <div data-i18n="Without navbar">Department wise</div>
                                            </a>
                                        </li>
    
                                    </ul>
                                </li>
    
                                   
                                
                    <?php

                                }
                            }
                        }
                    }
                }

                    ?>
            </aside>


            <!-- / Menu -->
            <div class="layout-page">

                <script src="<?php echo base_url('/assets/vendor/libs/jquery/jquery.js'); ?>"></script>
                <script src="<?php echo base_url('/assets/vendor/libs/popper/popper.js'); ?>"></script>
                <script src="<?php echo base_url('/assets/vendor/js/bootstrap.js'); ?>"></script>
                <script src="<?php echo base_url('/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js'); ?>"></script>
                <script src="<?php echo base_url('/assets/vendor/js/menu.js') ?>"></script>

                <script src="<?php echo  base_url('/assets/js/extended-ui-perfect-scrollbar.js')?>"></script>

                <script src="<?php echo base_url('/assets/vendor/libs/apex-charts/apexcharts.js') ?>"></script>
                <script src="<?php echo base_url('/assets/js/main.js'); ?>"></script>
                <script src="<?php echo base_url('/assets/js/dashboards-analytics.js'); ?>"></script>
                <script async defer src="https://buttons.github.io/buttons.js"></script>





                <!-- DataTables JS -->
                <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
                <script src="https://cdn.datatables.net/1.11.4/js/jquery.dataTables.min.js"></script>