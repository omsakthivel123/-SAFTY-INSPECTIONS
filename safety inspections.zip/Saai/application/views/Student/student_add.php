<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- <style>
    /* Custom CSS for Multi-Stage Form */
    .container {
        margin-top: 50px;
    }

    .stage {
        margin-bottom: 20px;
    }

    .stage h4 {
        margin-bottom: 20px;
    }

    /* Style for form inputs */
    .form-group {
        margin-bottom: 20px;
    }

    /* Align buttons */
    .btn {
        margin-right: 10px;
    }

    /* Align submit button to the right */
    #final-stage .btn-success {
        float: right;
    }
</style> -->

<div class="content-wrapper">
    <!-- Content -->

    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Student/</span> Add Student</h4>

        <!-- Basic Layout & Basic with Icons -->
        <div class="row">
            <!-- Basic Layout -->
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-body">
                        <form id="multi-stage-form" method="POST" action="<?php echo base_url('Student/add_student') ?>">
                            <!-- Stage 1 -->
                            <div class="stage" id="stage1">
                                <h2 style="display: flex; justify-content: center; font-size: 23px;">Student Details</h2>

                                <div class="row">
                                    <div class="col-md-3 p-3">
                                        <label for="Inst_name_1" class="text-dark">Institution Name</label>
                                        <select name="Inst_name_1" class="form-control" id="Inst_name_1" required></select>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="Inst_codes" class="text-dark">Institution Code</label>
                                        <input type="text" name="Inst_codes" class="form-control" id="Inst_codes" readonly>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="department" class="text-dark">Department Name</label>
                                        <select name="department" class="form-control" id="Department_Name11"></select>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="Course_type" class="text-dark">Course Type</label>
                                        <select name="Course_type" class="form-control" id="Course_type"></select>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="Course_name" class="text-dark">Course Name</label>
                                        <select name="Course_name" class="form-control" id="Course_name"></select>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="Semester" class="text-dark">Semester</label>
                                        <select name="Semester" class="form-control" id="Semester"></select>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="Batch" class="text-dark">Batch</label>
                                        <select name="Batch" class="form-control" id="Batch"></select>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="Section" class="text-dark">Section</label>
                                        <select name="Section" class="form-control" id="Section"></select>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="Student_id" class="text-dark">Student ID</label>
                                        <input type="text" name="Student_id" id="Student_id" class="form-control">
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="Exam_reg_no" class="text-dark">Exam Reg No</label>
                                        <input type="text" name="Exam_reg_no" id="Exam_reg_no" class="form-control">
                                    </div>
                                </div>

                                <div class="row justify-content-end">
                                    <div class="col-auto">
                                        <button type="button" class="btn btn-secondary btn-sm next ">Next</button>
                                    </div>
                                </div>
                            </div>
                            <div class="stage" id="stage2">
                                <h2 style="display: flex; justify-content: center; font-size: 23px;">Student Details</h2>

                                <div class="row">
                                    <div class="col-md-3 p-3">
                                        <label for="Name">Name</label>
                                        <input type="text" name="Name" id="Name" class="form-control" value="<?php echo set_value('Name'); ?>">
                                        <?php echo form_error('Name', '<div class="error">', '</div>'); ?>
                                    </div>

                                    <div class="col-md-3 p-3">
                                        <label for="Initial">Initial</label>
                                        <input type="text" name="Initial" id="Initial" class="form-control">
                                        <?php echo form_error('Initial', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="DOB">Date of Birth</label>
                                        <input type="date" name="DOB" id="DOB" class="form-control">
                                        <?php echo form_error('DOB', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="PlaceOfBirth">Place of Birth</label>
                                        <input type="text" name="PlaceOfBirth" id="PlaceOfBirth" class="form-control">
                                        <?php echo form_error('PlaceOfBirth', '<div class="error">', '</div>'); ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3 p-3">
                                        <label for="MotherTongue">Mother Tongue</label>
                                        <input type="text" name="MotherTongue" id="MotherTongue" class="form-control">
                                        <?php echo form_error('MotherTongue', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="FatherName">Father's Name</label>
                                        <input type="text" name="FatherName" id="FatherName" class="form-control">
                                        <?php echo form_error('FatherName', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="FatherOccup">Father's Occupation</label>
                                        <input type="text" name="FatherOccup" id="FatherOccup" class="form-control">
                                        <?php echo form_error('FatherOccup', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="FatherIncome">Father's Income</label>
                                        <input type="text" name="FatherIncome" id="FatherIncome" class="form-control">
                                        <?php echo form_error('FatherIncome', '<div class="error">', '</div>'); ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3 p-3">
                                        <label for="BloodGroup">Blood Group</label>
                                        <input type="text" name="BloodGroup" id="BloodGroup" class="form-control">
                                        <?php echo form_error('BloodGroup', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="MotherName">Mother's Name</label>
                                        <input type="text" name="MotherName" id="MotherName" class="form-control" 1>
                                        <?php echo form_error('MotherName', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="MotherOccupation">Mother's Occupation</label>
                                        <input type="text" name="MotherOccupation" id="MotherOccupation" class="form-control">
                                        <?php echo form_error('MotherOccupation', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="MotherIncome">Mother's Income</label>
                                        <input type="text" name="MotherIncome" id="MotherIncome" class="form-control">
                                        <?php echo form_error('MotherIncome', '<div class="error">', '</div>'); ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3 p-3">
                                        <label for="AadharCardNo">Aadhar Card No</label>
                                        <input type="text" name="AadharCardNo" id="AadharCardNo" class="form-control" minlength="12" maxlength="12">
                                        <?php echo form_error('AadharCardNo', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="MobileNo">Mobile No</label>
                                        <input type="text" name="MobileNo" id="MobileNo" class="form-control" minlength="10" maxlength="10">
                                        <?php echo form_error('MobileNo', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="MobileNo2">Alternate Mobile No</label>
                                        <input type="text" name="MobileNo2" id="MobileNo2" class="form-control" minlength="10" maxlength="10">
                                        <?php echo form_error('MobileNo2', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="StudentMobileNumber">Student Mobile Number</label>
                                        <input type="text" name="StudentMobileNumber" id="StudentMobileNumber" class="form-control">
                                        <?php echo form_error('StudentMobileNumber', '<div class="error">', '</div>'); ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3 p-3">
                                        <label for="Emailid">Email ID</label>
                                        <input type="email" name="Emailid" id="Emailid" class="form-control">
                                        <?php echo form_error('Emailid', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="FirstLanguage">First Language</label>
                                        <input type="text" name="FirstLanguage" id="FirstLanguage" class="form-control">
                                        <?php echo form_error('FirstLanguage', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="Parents">Parents</label>
                                        <input type="text" name="Parents" id="Parents" class="form-control">
                                        <?php echo form_error('Parents', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="Religion">Religion</label>
                                        <input type="text" name="Religion" id="Religion" class="form-control">
                                        <?php echo form_error('Religion', '<div class="error">', '</div>'); ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3 p-3">
                                        <label for="Community">Community</label>
                                        <input type="text" name="Community" id="Community" class="form-control">
                                        <?php echo form_error('Community', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="Caste">Caste</label>
                                        <input type="text" name="Caste" id="Caste" class="form-control">
                                        <?php echo form_error('Caste', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="GuardianName">Guardian's Name</label>
                                        <input type="text" name="GuardianName" id="GuardianName" class="form-control">
                                        <?php echo form_error('GuardianName', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="ExtraCurricularActi">Extra-Curricular Activities</label>
                                        <input type="text" name="ExtraCurricularActi" id="ExtraCurricularActi" class="form-control">
                                        <?php echo form_error('ExtraCurricularActi', '<div class="error">', '</div>'); ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3 p-3">
                                        <label for="PhysicalDisability">Physical Disability</label>
                                        <input type="text" name="PhysicalDisability" id="PhysicalDisability" class="form-control">
                                        <?php echo form_error('PhysicalDisability', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="Volunteers">Volunteers</label>
                                        <input type="text" name="Volunteers" id="Volunteers" class="form-control" ">
                                <?php echo form_error('Volunteers', '<div class="error">', '</div>'); ?>
                            </div>
                            <div class=" col-md-3">
                                        <label for="Gender">Gender</label>
                                        <input type="text" name="Gender" id="Gender" class="form-control">
                                        <?php echo form_error('Gender', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="PerAddrPincode">Permanent Address Pincode</label>
                                        <input type="text" name="PerAddrPincode" id="PerAddrPincode" class="form-control">
                                        <?php echo form_error('PerAddrPincode', '<div class="error">', '</div>'); ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3 p-3">
                                        <label for="PerAddrPostOffice">Permanent Address Post Office</label>
                                        <input type="text" name="PerAddrPostOffice" id="PerAddrPostOffice" class="form-control">
                                        <?php echo form_error('PerAddrPostOffice', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="PerAddrDistrict">Permanent Address District</label>
                                        <input type="text" name="PerAddrDistrict" id="PerAddrDistrict" class="form-control">
                                        <?php echo form_error('PerAddrDistrict', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="PerAddrState">Permanent Address State</label>
                                        <input type="text" name="PerAddrState" id="PerAddrState" class="form-control">
                                        <?php echo form_error('PerAddrState', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="ComAddrPincode">Communication Address Pincode</label>
                                        <input type="text" name="ComAddrPincode" id="ComAddrPincode" class="form-control">
                                        <?php echo form_error('ComAddrPincode', '<div class="error">', '</div>'); ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3 p-3">
                                        <label for="ComAddrPostOffice">Communication Address Post Office</label>
                                        <input type="text" name="ComAddrPostOffice" id="ComAddrPostOffice" class="form-control">
                                        <?php echo form_error('ComAddrPostOffice', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="ComAddrDistrict">Communication Address District</label>
                                        <input type="text" name="ComAddrDistrict" id="ComAddrDistrict" class="form-control">
                                        <?php echo form_error('ComAddrDistrict', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="ComAddrState">Communication Address State</label>
                                        <input type="text" name="ComAddrState" id="ComAddrState" class="form-control">
                                        <?php echo form_error('ComAddrState', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="education-level">Education Level</label>
                                        <select class="form-control" name="CourseType" id="education-level">
                                            <option value="ug">UG</option>
                                            <option value="pg">PG</option>
                                        </select>
                                        <?php echo form_error('CourseType', '<div class="error">', '</div>'); ?>
                                    </div>
                                </div>
                                <div class="row p-1">
                                    <div class="col-md-6">
                                        <label for="PerAddr1">Permanent Address Line 1</label>
                                        <textarea class="form-control" name="PerAddr1" id="ComAddr1" rows="4"></textarea>
                                        <?php echo form_error('PerAddr1', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="PerAddr2">Permanent Address Line 2</label>
                                        <textarea class="form-control" name="PerAddr2" id="PerAddr2" rows="4"></textarea>
                                        <?php echo form_error('PerAddr2', '<div class="error">', '</div>'); ?>

                                    </div>
                                </div>
                                <div class="row p-1">
                                    <div class="col-md-6">
                                        <label for="ComAddr1">Communication Address Line 1</label>
                                        <textarea class="form-control" name="ComAddr1" id="ComAddr1" rows="4"></textarea>
                                        <?php echo form_error('ComAddr1', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="ComAddr2">Communication Address Line 2</label>
                                        <textarea class="form-control" name="ComAddr2" id="ComAddr2" rows="4"></textarea>
                                        <?php echo form_error('ComAddr2', '<div class="error">', '</div>'); ?>
                                    </div>
                                </div>
                                <div class="row justify-content-end">
                                    <div class="col-auto">
                                        <button type="button" class="btn btn-danger btn-sm previous ">Previous</button>
                                        <button type="button" class="btn btn-secondary btn-sm next ">Next</button>
                                    </div>
                                </div>
                            </div>


                            <!-- Stage 2 -->
                            <div class="stage" id="stage3">
                                <h2 style="display: flex; justify-content: center; font-size: 23px;">Education Details</h2>

                                <div class="row">
                                    <div class="col-md-6">
                                        <label for="SchoolName">School Name</label>
                                        <input type="text" name="SchoolName" id="SchoolName" class="form-control" value="<?php echo set_value('SchoolName'); ?>">
                                        <?php echo form_error('SchoolName', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="Subject1Name">Subject 1 Name</label>
                                        <input type="text" name="Subject1Name" id="Subject1Name" class="form-control" value="<?php echo set_value('Subject1Name'); ?>">
                                        <?php echo form_error('Subject1Name', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="Subject1Mark">Subject 1 Mark</label>
                                        <input type="number" name="Subject1Mark" id="Subject1Mark" class="form-control" value="<?php echo set_value('Subject1Mark'); ?>">
                                        <?php echo form_error('Subject1Mark', '<div class="error">', '</div>'); ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3 p-3">
                                        <label for="Subject2Name">Subject 2 Name</label>
                                        <input type="text" name="Subject2Name" id="Subject2Name" class="form-control" value="<?php echo set_value('Subject2Name'); ?>">
                                        <?php echo form_error('Subject2Name', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="Subject2Mark">Subject 2 Mark</label>
                                        <input type="number" name="Subject2Mark" id="Subject2Mark" class="form-control" value="<?php echo set_value('Subject2Mark'); ?>">
                                        <?php echo form_error('Subject2Mark', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="Subject3Name">Subject 3 Name</label>
                                        <input type="text" name="Subject3Name" id="Subject3Name" class="form-control" value="<?php echo set_value('Subject3Name'); ?>">
                                        <?php echo form_error('Subject3Name', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="Subject3Mark">Subject 3 Mark</label>
                                        <input type="number" name="Subject3Mark" id="Subject3Mark" class="form-control" value="<?php echo set_value('Subject3Mark'); ?>">
                                        <?php echo form_error('Subject3Mark', '<div class="error">', '</div>'); ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3 p-3">
                                        <label for="Subject4Name">Subject 4 Name</label>
                                        <input type="text" name="Subject4Name" id="Subject4Name" class="form-control" value="<?php echo set_value('Subject4Name'); ?>">
                                        <?php echo form_error('Subject4Name', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="Subject4Mark">Subject 4 Mark</label>
                                        <input type="number" name="Subject4Mark" id="Subject4Mark" class="form-control" value="<?php echo set_value('Subject4Mark'); ?>">
                                        <?php echo form_error('Subject4Mark', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="Subject5Name">Subject 5 Name</label>
                                        <input type="text" name="Subject5Name" id="Subject5Name" class="form-control" value="<?php echo set_value('Subject5Name'); ?>">
                                        <?php echo form_error('Subject5Name', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="Subject5Mark">Subject 5 Mark</label>
                                        <input type="number" name="Subject5Mark" id="Subject5Mark" class="form-control" value="<?php echo set_value('Subject5Mark'); ?>">
                                        <?php echo form_error('Subject5Mark', '<div class="error">', '</div>'); ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3 p-3">
                                        <label for="Subject6Name">Subject 6 Name</label>
                                        <input type="text" name="Subject6Name" id="Subject6Name" class="form-control" value="<?php echo set_value('Subject6Name'); ?>">
                                        <?php echo form_error('Subject6Name', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="Subject6Mark">Subject 6 Mark</label>
                                        <input type="number" name="Subject6Mark" id="Subject6Mark" class="form-control" value="<?php echo set_value('Subject6Mark'); ?>">
                                        <?php echo form_error('Subject6Mark', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="HSCMark">HSC Mark</label>
                                        <input type="number" name="HSCMark" id="HSCMark" class="form-control" value="<?php echo set_value('HSCMark'); ?>">
                                        <?php echo form_error('HSCMark', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="HSCMarkPer">HSC Mark Percentage</label>
                                        <input type="text" name="HSCMarkPer" id="HSCMarkPer" class="form-control" value="<?php echo set_value('HSCMarkPer'); ?>">
                                        <?php echo form_error('HSCMarkPer', '<div class="error">', '</div>'); ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3 p-3">
                                        <label for="MonthAndYearOfPass">Month and Year of Passing</label>
                                        <input type="text" name="MonthAndYearOfPass" id="MonthAndYearOfPass" class="form-control" value="<?php echo set_value('MonthAndYearOfPass'); ?>">
                                        <?php echo form_error('MonthAndYearOfPass', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="StudiedGroup">Studied Group</label>
                                        <input type="text" name="StudiedGroup" id="StudiedGroup" class="form-control" value="<?php echo set_value('StudiedGroup'); ?>">
                                        <?php echo form_error('StudiedGroup', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="HSCRollNo">HSC Roll No</label>
                                        <input type="text" name="HSCRollNo" id="HSCRollNo" class="form-control" value="<?php echo set_value('HSCRollNo'); ?>">
                                        <?php echo form_error('HSCRollNo', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="MediumofStudy">Medium of Study</label>
                                        <input type="text" name="MediumofStudy" id="MediumofStudy" class="form-control" value="<?php echo set_value('MediumofStudy'); ?>">
                                        <?php echo form_error('MediumofStudy', '<div class="error">', '</div>'); ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3 p-3">
                                        <label for="TotalMaxMark">Total Max Mark</label>
                                        <input type="number" name="TotalMaxMark" id="TotalMaxMark" class="form-control" value="<?php echo set_value('TotalMaxMark'); ?>">
                                        <?php echo form_error('TotalMaxMark', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="EMISNo">EMIS No</label>
                                        <input type="text" name="EMISNo" id="EMISNo" class="form-control" value="<?php echo set_value('EMISNo'); ?>">
                                        <?php echo form_error('EMISNo', '<div class="error">', '</div>'); ?>
                                    </div>
                                </div>
                                <div class="row justify-content-end">
                                    <div class="col-auto">
                                        <button type="button" class="btn btn-danger btn-sm previous ">Previous</button>
                                        <button type="button" class="btn btn-secondary btn-sm next ">Next</button>
                                    </div>
                                </div>
                            </div>

                            <!-- Stage 3 -->
                            <div class="stage" id="stage4">
                                <h2 style="display: flex; justify-content: center; font-size: 23px;">Document Details</h2>

                                <div class="row">
                                    <div class="col-md-3 p-3">
                                        <label for="AadharCard">Aadhar Card</label>
                                        <input type="text" name="AadharCard" id="AadharCard" class="form-control" value="<?php echo set_value('AadharCard'); ?>">
                                        <?php echo form_error('AadharCard', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="BankPassBook">Bank Pass Book</label>
                                        <input type="text" name="BankPassBook" id="BankPassBook" class="form-control" value="<?php echo set_value('BankPassBook'); ?>">
                                        <?php echo form_error('BankPassBook', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="CommunityCertif">Community Certificate</label>
                                        <input type="text" name="CommunityCertif" id="CommunityCertif" class="form-control" value="<?php echo set_value('CommunityCertif'); ?>">
                                        <?php echo form_error('CommunityCertif', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="TransferCertif">Transfer Certificate</label>
                                        <input type="text" name="TransferCertif" id="TransferCertif" class="form-control" value="<?php echo set_value('TransferCertif'); ?>">
                                        <?php echo form_error('TransferCertif', '<div class="error">', '</div>'); ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3 p-3">
                                        <label for="XthMarkSheet">Xth Mark Sheet</label>
                                        <input type="text" name="XthMarkSheet" id="XthMarkSheet" class="form-control" value="<?php echo set_value('XthMarkSheet'); ?>">
                                        <?php echo form_error('XthMarkSheet', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="XIthMarkSheet">XIth Mark Sheet</label>
                                        <input type="text" name="XIthMarkSheet" id="XIthMarkSheet" class="form-control" value="<?php echo set_value('XIthMarkSheet'); ?>">
                                        <?php echo form_error('XIthMarkSheet', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="XIIthMarkSheet">XIIth Mark Sheet</label>
                                        <input type="text" name="XIIthMarkSheet" id="XIIthMarkSheet" class="form-control" value="<?php echo set_value('XIIthMarkSheet'); ?>">
                                        <?php echo form_error('XIIthMarkSheet', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="ExaminationPassed">Examination Passed</label>
                                        <input type="text" name="ExaminationPassed" id="ExaminationPassed" class="form-control" value="<?php echo set_value('ExaminationPassed'); ?>">
                                        <?php echo form_error('Name', '<div class="error">', '</div>'); ?>
                                    </div>

                                </div>
                                <div class="row justify-content-end">
                                    <div class="col-auto">
                                        <button type="button" class="btn btn-danger btn-sm previous">Previous</button>
                                        <button type="button" class="btn btn-secondary btn-sm next ">Next</button>
                                    </div>
                                </div>
                            </div>

                            <!-- Stage 4 -->
                            <div class="stage" id="stage5">
                                <h2 style="display: flex; justify-content: center; font-size: 23px;">Bank Details</h2>

                                <div class="row">
                                    <div class="col-md-3 p-3">
                                        <label for="IFSCCode">IFSC Code</label>
                                        <input type="text" name="IFSCCode" id="IFSCCode" class="form-control">
                                        <!-- <?php echo form_error('IFSCCode', '<div class="error">', '</div>'); ?> -->
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="BankName">Bank Name</label>
                                        <input type="text" name="BankName" id="BankName" class="form-control">
                                        <?php echo form_error('BankName', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="BankAddress">Bank Address</label>
                                        <input type="text" name="BankAddress" id="BankAddress" class="form-control">
                                        <?php echo form_error('BankAddress', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="AccountNumber">Account Number</label>
                                        <input type="text" name="AccountNumber" id="AccountNumber" class="form-control">
                                        <?php echo form_error('AccountNumber', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 p-3">
                                        <label for="MICRCode">MICR Code</label>
                                        <input type="text" name="MICRCode" id="MICRCode" class="form-control">
                                        <?php echo form_error('MICRCode', '<div class="error">', '</div>'); ?>
                                    </div>
                                </div>
                                <div class="row justify-content-end">
                                    <div class="col-auto">
                                        <button type="button" class="btn btn-danger btn-sm previous">Previous</button>
                                        <button type="button" class="btn btn-secondary btn-sm next ">Next</button>
                                    </div>
                                </div>
                            </div>

                            <!-- Final Stage -->
                            <div class="stage" id="stage6">
                                <h2 style="display: flex; justify-content: center; font-size: 23px;">UG Details</h2>

                                <div class="row">
                                    <div class="col-md-3 final-info">
                                        <label for="StuDegr" class="label-final-info">Student Degree</label>
                                        <input type="text" class="form-control" name="StuDegr" id="StuDegr" required disabled>
                                        <?php echo form_error('StuDegr', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-6 final-info">
                                        <label for="StuDegType" class="label-final-info">Student Degree Type</label>
                                        <input type="text" name="StuDegType" id="StuDegType" class="form-control" required disabled>
                                        <?php echo form_error('StuDegType', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 final-info">
                                        <label for="YearofPassing" class="label-final-info">Year of Passing</label>
                                        <input type="text" name="YearofPassing" id="YearofPassing" class="form-control" required disabled>
                                        <?php echo form_error('YearofPassing', '<div class="error">', '</div>'); ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3 final-info">
                                        <label for="UniversityName" class="label-final-info">University Name</label>
                                        <input type="text" name="UniversityName" id="UniversityName" class="form-control" required disabled>
                                        <?php echo form_error('UniversityName', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-6 final-info">
                                        <label for="InstituionName" class="label-final-info">Institution Name</label>
                                        <input type="text" name="InstituionName" id="InstituionName" class="form-control" required disabled>
                                        <?php echo form_error('InstituionName', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 final-info">
                                        <label for="StudiedMode" class="label-final-info">Studied Mode</label>
                                        <input type="text" name="StudiedMode" id="StudiedMode" class="form-control" required disabled>
                                        <?php echo form_error('StudiedMode', '<div class="error">', '</div>'); ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3 final-info">
                                        <label for="PassPercent" class="label-final-info">Pass Percent</label>
                                        <input type="text" name="PassPercent" id="PassPercent" class="form-control" required disabled>
                                        <?php echo form_error('PassPercent', '<div class="error">', '</div>'); ?>
                                    </div>
                                    <div class="col-md-3 final-info">
                                        <label for="Specialization" class="label-final-info">Specialization</label>
                                        <input type="text" name="Specialization" id="Specialization" class="form-control" required disabled>
                                        <?php echo form_error('Specialization', '<div class="error">', '</div>'); ?>

                                    </div>
                                    <div class="col-md-3 final-info">
                                        <label for="DateOfAdmission" class="label-final-info">Date of Admission</label>
                                        <input type="date" name="DateOfAdmission" id="DateOfAdmission" class="form-control" required disabled>
                                        <?php echo form_error('DateOfAdmission', '<div class="error">', '</div>'); ?>

                                    </div>
                                    <div class="col-md-3 final-info">
                                        <label for="RollNo" class="label-final-info">Roll No</label>
                                        <input type="text" name="RollNo" id="RollNo" class="form-control" required disabled>
                                        <?php echo form_error('RollNoRollNo', '<div class="error">', '</div>'); ?>

                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3 final-info">
                                        <label for="DepName" class="label-final-info">Department Name</label>
                                        <input type="text" name="DepName" id="DepName" class="form-control" required disabled>
                                        <?php echo form_error('DepName', '<div class="error">', '</div>'); ?>

                                    </div>
                                    <div class="col-md-3 final-info">
                                        <label for="DepCode" class="label-final-info">Department Code</label>
                                        <input type="text" name="DepCode" id="DepCode" class="form-control" required disabled>
                                        <?php echo form_error('DepCode', '<div class="error">', '</div>'); ?>

                                    </div>
                                    <div class="col-md-3 final-info">
                                        <label for="CourseYear" class="label-final-info">Course Year</label>
                                        <input type="text" name="CourseYear" id="CourseYear" class="form-control" required disabled>
                                        <?php echo form_error('CourseYear', '<div class="error">', '</div>'); ?>

                                    </div>
                                    <div class="col-md-3 final-info">
                                        <label for="CourseNameSD" class="label-final-info">Course Name Short Duration</label>
                                        <input type="text" name="CourseNameSD" id="CourseNameSD" class="form-control" required disabled>
                                        <?php echo form_error('CourseNameSD', '<div class="error">', '</div>'); ?>

                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3 final-info">
                                        <label for="CourseNameBD" class="label-final-info">Course Name Long Duration</label>
                                        <input type="text" name="CourseNameBD" id="CourseNameBD" class="form-control" required disabled>
                                        <?php echo form_error('CourseNameBD', '<div class="error">', '</div>'); ?>

                                    </div>
                                    <div class="col-md-3 final-info">
                                        <label for="CourseCode" class="label-final-info">Course Code</label>
                                        <input type="text" name="CourseCode" id="CourseCode" class="form-control" required disabled>
                                        <?php echo form_error('CourseCode', '<div class="error">', '</div>'); ?>

                                    </div>
                                    <div class="col-md-3 final-info">
                                        <label for="Section" class="label-final-info">Section</label>
                                        <input type="text" name="Section" id="Section" class="form-control" required disabled>
                                        <?php echo form_error('Section', '<div class="error">', '</div>'); ?>

                                    </div>
                                    <div class="col-md-3 final-info">
                                        <label for="Batch" class="label-final-info">Batch</label>
                                        <input type="text" name="Batch" id="Batch" class="form-control" required disabled>
                                        <?php echo form_error('Batch', '<div class="error">', '</div>'); ?>

                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3 final-info">
                                        <label for="Semester" class="label-final-info">Semester</label>
                                        <input type="text" name="Semester" id="Semester" class="form-control" required disabled>
                                        <?php echo form_error('Semester', '<div class="error">', '</div>'); ?>

                                    </div>
                                    <div class="col-md-3 final-info">
                                        <label for="ExamRegNumber" class="label-final-info">Exam Registration Number</label>
                                        <input type="text" name="ExamRegNumber" id="ExamRegNumber" class="form-control" required disabled>
                                        <?php echo form_error('ExamRegNumber', '<div class="error">', '</div>'); ?>

                                    </div>
                                    <div class="col-md-3 final-info">
                                        <label for="BroSysStudyingStudied" class="label-final-info">Brother/Sister Studying/Studied</label>
                                        <input type="text" name="BroSysStudyingStudied" id="BroSysStudyingStudied" class="form-control" required disabled>
                                        <?php echo form_error('BroSysStudyingStudied', '<div class="error">', '</div>'); ?>

                                    </div>
                                    <div class="col-md-3 final-info">
                                        <label for="NameBroSys" class="label-final-info">Name of Brother/Sister</label>
                                        <input type="text" name="NameBroSys" id="NameBroSys" class="form-control" required disabled>
                                        <?php echo form_error('NameBroSys', '<div class="error">', '</div>'); ?>

                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3 final-info">
                                        <label for="ModeOFTransport" class="label-final-info">Mode of Transport</label>
                                        <input type="text" name="ModeOFTransport" id="ModeOFTransport" class="form-control" required disabled>
                                        <?php echo form_error('ModeOFTransport', '<div class="error">', '</div>'); ?>

                                    </div>
                                    <div class="col-md-3 final-info">
                                        <label for="BoardingPoint" class="label-final-info">Boarding Point</label>
                                        <input type="text" name="BoardingPoint" id="BoardingPoint" class="form-control" required disabled>
                                        <?php echo form_error('BoardingPoint', '<div class="error">', '</div>'); ?>

                                    </div>
                                    <div class="col-md-3 final-info">
                                        <label for="ImageFileName" class="label-final-info">Image File Name</label>
                                        <input type="text" name="ImageFileName" id="ImageFileName" class="form-control" required disabled>
                                        <?php echo form_error('ImageFileName', '<div class="error">', '</div>'); ?>

                                    </div>
                                    <div class="col-md-3 final-info">
                                        <label for="ImageContentType" class="label-final-info">Image Content Type</label>
                                        <input type="text" name="ImageContentType" id="ImageContentType" class="form-control" required disabled>
                                        <?php echo form_error('ImageContentType', '<div class="error">', '</div>'); ?>

                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3 final-info">
                                        <label for="ImageData" class="label-final-info">Image Data</label>
                                        <input type="text" name="ImageData" id="ImageData" class="form-control" required disabled>
                                        <?php echo form_error('ImageData', '<div class="error">', '</div>'); ?>

                                    </div>
                                    <div class="col-md-3 final-info">
                                        <label for="Hostel" class="label-final-info">Hostel</label>
                                        <input type="text" name="Hostel" id="Hostel" class="form-control" required disabled>
                                        <?php echo form_error('Hostel', '<div class="error">', '</div>'); ?>

                                    </div>
                                    <div class="col-md-3 final-info">
                                        <label for="ScholarShip" class="label-final-info">Scholarship</label>
                                        <input type="text" name="ScholarShip" id="ScholarShip" class="form-control" required disabled>
                                        <?php echo form_error('ScholarShip', '<div class="error">', '</div>'); ?>

                                    </div>
                                    <div class="col-md-3 final-info">
                                        <label for="ScholarShipType" class="label-final-info">Scholarship Type</label>
                                        <input type="text" name="ScholarShipType" id="ScholarShipType" class="form-control" required disabled>
                                        <?php echo form_error('ScholarShipType', '<div class="error">', '</div>'); ?>

                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3 final-info">
                                        <label for="CharityScholarship" class="label-final-info">Charity Scholarship</label>
                                        <input type="text" name="CharityScholarship" id="CharityScholarship" class="form-control" required disabled>
                                        <?php echo form_error('CharityScholarship', '<div class="error">', '</div>'); ?>

                                    </div>
                                    <div class="col-md-3 final-info">
                                        <label for="CharityAmount" class="label-final-info">Charity Amount</label>
                                        <input type="text" name="CharityAmount" id="CharityAmount" class="form-control" required disabled>
                                        <?php echo form_error('CharityAmount', '<div class="error">', '</div>'); ?>

                                    </div>
                                    <div class="col-md-3 final-info">
                                        <label for="ManagementScholarship" class="label-final-info">Management Scholarship</label>
                                        <input type="text" name="ManagementScholarship" id="ManagementScholarship" class="form-control" required disabled>
                                        <?php echo form_error('ManagementScholarship', '<div class="error">', '</div>'); ?>

                                    </div>
                                    <div class="col-md-3 final-info">
                                        <label for="Quota" class="label-final-info">Quota</label>
                                        <input type="text" name="Quota" id="Quota" class="form-control" required disabled>
                                        <?php echo form_error('Quota', '<div class="error">', '</div>'); ?>

                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3 final-info">
                                        <label for="Concession" class="label-final-info">Concession</label>
                                        <input type="text" name="Concession" id="Concession" class="form-control" required disabled>
                                        <?php echo form_error('Concession', '<div class="error">', '</div>'); ?>

                                    </div>
                                    <div class="col-md-3 final-info">
                                        <label for="Remark" class="label-final-info">Remark</label>
                                        <input type="text" name="Remark" id="Remark" class="form-control" required disabled>
                                        <?php echo form_error('Remark', '<div class="error">', '</div>'); ?>

                                    </div>
                                    <div class="col-md-3 final-info">
                                        <label for="Referredby" class="label-final-info">Referred by</label>
                                        <input type="text" name="Referredby" id="Referredby" class="form-control" required disabled>
                                        <?php echo form_error('Referredby', '<div class="error">', '</div>'); ?>

                                    </div>
                                    <div class="col-md-3 final-info">
                                        <label for="TCReceivedDate" class="label-final-info">TC Received Date</label>
                                        <input type="date" name="TCReceivedDate" id="TCReceivedDate" class="form-control" required disabled>
                                        <?php echo form_error('TCReceivedDate', '<div class="error">', '</div>'); ?>

                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3 final-info">
                                        <label for="DocEnclosed" class="label-final-info">Document Enclosed</label>
                                        <input type="text" name="DocEnclosed" id="DocEnclosed" class="form-control" required disabled>
                                        <?php echo form_error('DocEnclosed', '<div class="error">', '</div>'); ?>

                                    </div>
                                    <div class="col-md-3 final-info">
                                        <label for="DocNotEnclosed" class="label-final-info">Document Not Enclosed</label>
                                        <input type="text" name="DocNotEnclosed" id="DocNotEnclosed" class="form-control" required disabled>
                                        <?php echo form_error('DocNotEnclosed', '<div class="error">', '</div>'); ?>

                                    </div>
                                    <div class="col-md-3 final-info">
                                        <label for="InstitutCode" class="label-final-info">Institute Code</label>
                                        <input type="text" name="InstitutCode" id="InstitutCode" class="form-control" required disabled>
                                        <?php echo form_error('InstitutCode', '<div class="error">', '</div>'); ?>

                                    </div>
                                    <div class="col-md-3 final-info">
                                        <label for="Status" class="label-final-info">Status</label>
                                        <input type="text" name="Status" id="Status" class="form-control" required disabled>
                                        <?php echo form_error('Status', '<div class="error">', '</div>'); ?>

                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3 final-info">
                                        <label for="LastDate" class="label-final-info">Last Date</label>
                                        <input type="text" name="LastDate" id="LastDate" class="form-control" required disabled>
                                        <?php echo form_error('LastDate', '<div class="error">', '</div>'); ?>

                                    </div>
                                    <div class="col-md-3 final-info">
                                        <label for="Reasonforleaving" class="label-final-info">Reason for Leaving</label>
                                        <input type="text" name="Reasonforleaving" id="Reasonforleaving" class="form-control" required disabled>
                                        <?php echo form_error('Reasonforleaving', '<div class="error">', '</div>'); ?>

                                    </div>
                                </div>
                                <div class="row justify-content-end">
                                    <div class="col-auto">
                                        <button type="button" class="btn btn-danger btn-sm previous">Previous</button>
                                        <button type="button" class="btn btn-secondary btn-sm next">Next</button>
                                    </div>
                                </div>
                            </div>
                            <div class="stage" id="final-stage">
                                <h2 style="display: flex; justify-content: center; font-size: 23px;">Create Login Details</h2>

                                <div class="container">
                                    <div class="row justify-content-center mb-3">
                                        <div class="col-md-3 text-end">
                                            <label for="User_role">User Role :</label>
                                        </div>
                                        <div class="col-md-3">
                                            <input type="text" name="User_role" id="User_role" class="form-control" value="Student" readonly>
                                            <!-- <?php echo form_error('User_role', '<div class="error">', '</div>'); ?> -->
                                        </div>
                                    </div>

                                    <div class="row justify-content-center mb-3">
                                        <div class="col-md-3 text-end">
                                            <label for="Username">Username :</label>
                                        </div>
                                        <div class="col-md-3">
                                            <input type="email" name="Username" id="Username" class="form-control">
                                            <?php echo form_error('Username', '<div class="error">', '</div>'); ?>
                                        </div>
                                    </div>

                                    <div class="row justify-content-center mb-3">
                                        <div class="col-md-3 text-end">
                                            <label for="Password">Password :</label>
                                        </div>
                                        <div class="col-md-3">
                                            <input type="password" name="Password" id="Password" class="form-control">
                                            <?php echo form_error('Password', '<div class="error">', '</div>'); ?>
                                        </div>
                                    </div>

                                    <div class="row justify-content-center mb-3">
                                        <div class="col-md-3 text-end">
                                            <label for="Confirm_Password">Confirm Password :</label>
                                        </div>
                                        <div class="col-md-3">
                                            <input type="password" name="Confirm_Password" id="Confirm_Password" class="form-control">
                                            <?php echo form_error('Confirm_Password', '<div class="error">', '</div>'); ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="row justify-content-end">
                                    <div class="col-auto">
                                        <button type="button" class="btn btn-danger btn-sm previous">Previous</button>
                                        <button type="submit" class="btn btn-secondary btn-sm">Submit</button>
                                    </div>
                                </div>
                            </div>



                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>