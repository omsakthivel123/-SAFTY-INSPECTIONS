<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Student/</span>Student Department Wise Report</h4>
        
        <!-- Basic Layout & Basic with Icons -->
        <div class="row">
            <!-- Basic Layout -->
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-body">
                        <!-- Stage 1 -->
                        <div class="stage" id="stage1">
                            <h2 style="display: flex; justify-content: center; font-size: 23px;">Student Reports</h2>
                            
                            <div class="row">
                                <div class="col-md-3 p-3">
                                    <label for="Inst_name_1" class="text-dark">Institution Name</label>
                                    <select name="Inst_name_1" class="form-control" id="Inst_name_1" required></select>
                                </div>
                                <div class="col-md-3 p-3">
                                    <label for="Inst_codes" class="text-dark">Institution Code</label>
                                    <input type="text" name="Inst_codes" class="form-control" id="Inst_codes" readonly>
                                </div>
                                <div class="col-md-3 p-3">
                                    <label for="department" class="text-dark">Department Name</label>
                                    <select name="department" class="form-control" id="Department_Name11"></select>
                                </div>
                                <div class="col-md-3 p-3">
                                    <label for="Course_type" class="text-dark">Course Type</label>
                                    <select name="Course_type" class="form-control" id="Course_type"></select>
                                </div>
                            </div>
                            
                            <div class="row justify-content-end py-3" id="view-btn">
                                <div class="col-auto">
                                    <button type="button" class="btn btn-outline-danger btn-sm" id="get_Department_list2">View</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card mb-4" id="Class-view23">
                <div class="card-body">
                    <div class="row">
                        <div id="attendance-record">
                            <div id="table-container" style="overflow-x: auto;">
                                <div class="d-flex justify-content-end mb-3">
                                    <button id="download-button1" class="btn btn-danger">Download Report</button>
                                </div>
                                <table id="sheet" class="table table-striped">
                                    <thead style="background-color: #302c63; color: white;">
                                        <tr>
                                            <th class="text-white">S No</th>
                                            <th class="text-white">Student ID</th>
                                            <th class="text-white">Name</th>
                                            <th class="text-white">Department</th>
                                            <th class="text-white">Course Type</th>
                                            <th class="text-white">Semester</th>
                                            <th class="text-white">Batch</th>
                                            <th class="text-white">Section</th>
                                            <th class="text-white">Father's Name</th>
                                            <th class="text-white">Mother's Name</th>
                                            <th class="text-white">Institution Name</th>
                                            <th class="text-white">Institution Code</th>
                                            <th class="text-white">Course Name</th>
                                            <th class="text-white">Course Type</th>
                                            <th class="text-white">Exam Reg No</th>
                                            <th class="text-white">Initial</th>
                                            <th class="text-white">DOB</th>
                                            <th class="text-white">Place of Birth</th>
                                            <th class="text-white">Mother Tongue</th>
                                            <th class="text-white">Father's Occupation</th>
                                            <th class="text-white">Father's Income</th>
                                            <th class="text-white">Blood Group</th>
                                            <th class="text-white">Mother's Occupation</th>
                                            <th class="text-white">Mother's Income</th>
                                            <th class="text-white">Aadhar Card No</th>
                                            <th class="text-white">Mobile No</th>
                                            <th class="text-white">Alternate Mobile No</th>
                                            <th class="text-white">Student Mobile No</th>
                                            <th class="text-white">Email ID</th>
                                            <th class="text-white">First Language</th>
                                            <th class="text-white">Parents</th>
                                            <th class="text-white">Religion</th>
                                            <th class="text-white">Community</th>
                                            <th class="text-white">Caste</th>
                                            <th class="text-white">Guardian Name</th>
                                            <th class="text-white">Extra Curricular Activities</th>
                                            <th class="text-white">Physical Disability</th>
                                            <th class="text-white">Volunteers</th>
                                            <th class="text-white">Gender</th>
                                            <th class="text-white">Permanent Address Pincode</th>
                                            <th class="text-white">Permanent Address Post Office</th>
                                            <th class="text-white">Permanent Address District</th>
                                            <th class="text-white">Permanent Address State</th>
                                            <th class="text-white">Communication Address Pincode</th>
                                            <th class="text-white">Communication Address Post Office</th>
                                            <th class="text-white">Communication Address District</th>
                                            <th class="text-white">Communication Address State</th>
                                            <th class="text-white">Permanent Address 1</th>
                                            <th class="text-white">Permanent Address 2</th>
                                            <th class="text-white">Communication Address 1</th>
                                            <th class="text-white">Communication Address 2</th>
                                            <th class="text-white">School Name</th>
                                            <th class="text-white">Subject 1 Name</th>
                                            <th class="text-white">Subject 1 Mark</th>
                                            <th class="text-white">Subject 2 Name</th>
                                            <th class="text-white">Subject 2 Mark</th>
                                            <th class="text-white">Subject 3 Name</th>
                                            <th class="text-white">Subject 3 Mark</th>
                                            <th class="text-white">Subject 4 Name</th>
                                            <th class="text-white">Subject 4 Mark</th>
                                            <th class="text-white">Subject 5 Name</th>
                                            <th class="text-white">Subject 5 Mark</th>
                                            <th class="text-white">Subject 6 Name</th>
                                            <th class="text-white">Subject 6 Mark</th>
                                            <th class="text-white">HSC Mark</th>
                                            <th class="text-white">HSC Mark Percentage</th>
                                            <th class="text-white">Month and Year of Passing</th>
                                            <th class="text-white">Studied Group</th>
                                            <th class="text-white">HSC Roll No</th>
                                            <th class="text-white">Medium of Study</th>
                                            <th class="text-white">Total Max Mark</th>
                                            <th class="text-white">EMIS No</th>
                                            <th class="text-white">Aadhar Card</th>
                                            <th class="text-white">Bank Passbook</th>
                                            <th class="text-white">Community Certificate</th>
                                            <th class="text-white">Transfer Certificate</th>
                                            <th class="text-white">Xth Marksheet</th>
                                            <th class="text-white">XIth Marksheet</th>
                                            <th class="text-white">XIIth Marksheet</th>
                                            <th class="text-white">Examination Passed</th>
                                            <th class="text-white">IFSC Code</th>
                                            <th class="text-white">Bank Name</th>
                                            <th class="text-white">Bank Address</th>
                                            <th class="text-white">Account Number</th>
                                            <th class="text-white">MICR Code</th>
                                            <th class="text-white">Student Degree</th>
                                            <th class="text-white">Student Degree Type</th>
                                            <th class="text-white">Year of Passing</th>
                                            <th class="text-white">University Name</th>
                                            <th class="text-white">Institution Name</th>
                                            <th class="text-white">Studied Mode</th>
                                            <th class="text-white">Pass Percentage</th>
                                            <th class="text-white">Specialization</th>
                                            <th class="text-white">Date of Admission</th>
                                            <th class="text-white">Roll No</th>
                                            <th class="text-white">Department Name</th>
                                            <th class="text-white">Department Code</th>
                                            <th class="text-white">Course Year</th>
                                            <th class="text-white">Course Name (Short Description)</th>
                                            <th class="text-white">Course Name (Detailed Description)</th>
                                            <th class="text-white">Course Code</th>
                                            <th class="text-white">BroSys Studying/Studied</th>
                                            <th class="text-white">Name of BroSys</th>
                                            <th class="text-white">Mode of Transport</th>
                                            <th class="text-white">Boarding Point</th>
                                            <th class="text-white">Image File Name</th>
                                            <th class="text-white">Image Content Type</th>
                                            <th class="text-white">Image Data</th>
                                            <th class="text-white">Hostel</th>
                                            <th class="text-white">Scholarship</th>
                                            <th class="text-white">Scholarship Type</th>
                                            <th class="text-white">Charity Scholarship</th>
                                            <th class="text-white">Charity Amount</th>
                                            <th class="text-white">Management Scholarship</th>
                                            <th class="text-white">Quota</th>
                                            <th class="text-white">Concession</th>
                                            <th class="text-white">Remark</th>
                                            <th class="text-white">Referred by</th>
                                            <th class="text-white">TC Received Date</th>
                                            <th class="text-white">Document Enclosed</th>
                                            <th class="text-white">Document Not Enclosed</th>
                                            <th class="text-white">Institution Code</th>
                                            <th class="text-white">Status</th>
                                            <th class="text-white">Last Date</th>
                                            <th class="text-white">Reason for Leaving</th>
                                        </tr>
                                    </thead>
                                    <tbody id="Class_stud12"></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<form action="<?php echo base_url('Downloader/Student_department_wise')?>" method="post" style="display: none;" id="download-form2">
    <input type="text" name="Inst_name_1" id="data1">
    <input type="text" name="Inst_codes" id="data2">
    <input type="text" name="department" id="data3">
    <input type="text" name="Course_type" id="data4">
</form>


<script>
    $(document).ready(function(){
        $('#get_Department_list2').click(function(){
        var institutionName = $('#Inst_name_1').val();
        var Inst_codes = $('#Inst_codes').val();
        var departmentName = $('#Department_Name11').val();
        var Course_type = $('#Course_type').val();
     
        $('#data1').val(institutionName);
            $('#data2').val(Inst_codes);
            $('#data3').val(departmentName);
            $('#data4').val(Course_type);
    
            $('#form_data').submit();
        });

        $('#download-button1').click(function() {
            var institutionName = $('#Inst_name_1').val();
        var Inst_codes = $('#Inst_codes').val();
        var departmentName = $('#Department_Name11').val();
        var Course_type = $('#Course_type').val();
            $('#data1').val(institutionName);
            $('#data2').val(Inst_codes);
            $('#data3').val(departmentName);
            $('#data4').val(Course_type);
            $('#download-form2').submit();
        });
    });
</script>

