<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Student/</span>Student List Class</h4>

        <!-- Basic Layout & Basic with Icons -->
        <div class="row">
            <!-- Basic Layout -->
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-12">
                                <!-- Material tab card start -->
                                <div class="card">
                                    <div class="card-block">
                                        <form action="<?php echo base_url('') ?>" method="POST">
                                            <div class="row py-3">
                                            <div class="col-md-3">
                                                <label for="InstutionName" class="text-dark"> Instution</label>
                                                <select name="InstutionName" class="form-control" id="InstutionName" required></select>
                                            </div>
                                            <div class="col-md-3">
                                                <label for="Course_type" class="text-dark">Course Type</label>
                                                <select name="Course_type" class="form-control" id="Course_type" required></select>
                                            </div>
                                            <div class="col-md-3">
                                                <label for="DepartmentName" class="text-dark">Department</label>
                                                <select name="DepartmentName" class="form-control" id="DepartmentName" required> </select>
                                            </div>
                                            <div class="col-md-3">
                                                <label for="Batch" class="text-dark">Batch</label>
                                                <select name="Batch" class="form-control" id="Batch" required> </select>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-3">
                                                <label for="Course_name" class="text-dark">Course Name</label>
                                                <select name="Course_name" class="form-control" id="Course_name" required> </select>
                                            </div>
                                            <div class="col-md-3">
                                                <label for="Section" class="text-dark">Section</label>
                                                <select name="Section" class="form-control" id="Section" required> </select>
                                            </div>
                                            </div>

                                            <div class="row justify-content-end py-3">
                                                <div class="col-auto">
                                                    <button type="button" class="btn btn-outline-warning btn-sm" id="class_wise_student_list">view</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>

                                    <!-- Row start -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <div class="card mb-4" id="class_wise_students">
                <div class="card-body">
                    <div class="row">
                        <div id="course_mentor">
                            <div id="table-container" style="overflow-x: auto;">
                                <table id="class_wise_student" class="table table-striped">
                                    <thead style="background-color: #302c63; color: white;">
                                        <tr>
                                            <th style="color: white;">S.No</th>
                                            <th style="color: white;">Department</th>
                                            <th style="color: white;">Student Id</th>
                                            <th style="color: white;">Student Name</th>
                                            <th style="color: white;">Semester</th>
                                            <td style="color: white;">Mobile</td>
                                            <td style="color: white;">Email Id</td>
                                            <td style="color: white;">Action</td>

                                        </tr>
                                    </thead>
                                    <tbody id="">



                                    </tbody>
                                </table>

                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <div class="modal fade bd-example-modal-lg" id="student_view_modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-xl"> <!-- Increased the modal size -->
                    <div class="modal-content">
                        <div class="modal-header " style="background-color: #302c63">
                            <h5 class="modal-title" id="exampleModalLongTitle" style="color: white; text-align: center;">View User</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close" id="close_pop" style="color: white;">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="container">
                                <div class="row">
                                    <!-- First Section -->
                                    <div class="col-md-4">
                                        <div class="row p-1">
                                            <label for="view_student_id" class="col-sm-4 control-label">Student Id<sup>*</sup></label>
                                            <div class="col-sm-8">
                                                <input type="text" placeholder="" name="view_student_id" id="view_student_id" class="form-control">
                                            </div>
                                        </div>
                                        <div class="row p-1">
                                            <label for="view_Student_name" class="col-sm-4 control-label">Student Name<sup>*</sup></label>
                                            <div class="col-sm-8">
                                                <input type="text" placeholder="" name="view_Student_name" id="view_Student_name" class="form-control">
                                            </div>
                                        </div>
                                        <div class="row p-1">
                                            <label for="view_batch" class="col-sm-4 control-label">Batch<sup>*</sup></label>
                                            <div class="col-sm-8">
                                                <input type="text" placeholder="" name="view_batch" id="view_batch" class="form-control">
                                            </div>
                                        </div>
                                        <div class="row p-1">
                                            <label for="view_semester" class="col-sm-4 control-label">Semester <sup>*</sup></label>
                                            <div class="col-sm-8">
                                                <input type="text" placeholder="" name="view_semester" id="view_semester" class="form-control">
                                            </div>
                                        </div>
                                        <div class="row p-1">
                                            <label for="view_course" class="col-sm-4 control-label">Course Name<sup>*</sup></label>
                                            <div class="col-sm-8">
                                                <input type="text" placeholder="" name="view_course" id="view_course" class="form-control">
                                            </div>
                                        </div>
                                        <div class="row p-1">
                                            <label for="view_coursetypet" class="col-sm-4 control-label">Course Type<sup>*</sup></label>
                                            <div class="col-sm-8">
                                                <input type="text" placeholder="" name="view_coursetypet" id="view_coursetypet" class="form-control">
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Second Section -->
                                    <div class="col-md-4">
                                        <div class="row p-1">
                                            <label for="view_dob" class="col-sm-4 control-label">DOB<sup>*</sup></label>
                                            <div class="col-sm-8">
                                                <input type="text" placeholder="" name="view_dob" id="view_dob" class="form-control">
                                            </div>
                                        </div>
                                        <div class="row p-1">
                                            <label for="view_aadhar" class="col-sm-4 control-label">Aadhar No<sup>*</sup></label>
                                            <div class="col-sm-8">
                                                <input type="text" placeholder="" name="view_aadhar" id="view_aadhar" class="form-control">
                                            </div>
                                        </div>
                                        <div class="row p-1">
                                            <label for="view_blood_group" class="col-sm-4 control-label">Blood Group<sup>*</sup></label>
                                            <div class="col-sm-8">
                                                <input type="text" placeholder="" name="view_blood_group" id="view_blood_group" class="form-control">
                                            </div>
                                        </div>
                                        <div class="row p-1">
                                            <label for="view_department" class="col-sm-4 control-label">Department<sup>*</sup></label>
                                            <div class="col-sm-8">
                                                <input type="text" placeholder="" name="view_department" id="view_department" class="form-control">
                                            </div>
                                        </div>
                                        <div class="row p-1">
                                            <label for="view_address" class="col-sm-4 control-label">Address<sup>*</sup></label>
                                            <div class="col-sm-8">
                                                <input type="text" placeholder="" name="view_address" id="view_address" class="form-control">
                                            </div>
                                        </div>
                                        <div class="row p-1">
                                            <label for="view_Mobile" class="col-sm-4 control-label">Mobile<sup>*</sup></label>
                                            <div class="col-sm-8">
                                                <input type="text" placeholder="" name="view_Mobile" id="view_Mobile" class="form-control">
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Image Section -->
                                    <div class="col-md-4">
                                        <div class="row p-1 d-flex justify-content-center align-items-center" style="height: 100%;">
                                            <img src="" alt="Staff Image" id="view_image" height="250px" width="100px" class="img">
                                        </div>
                                    </div>


                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <!---edit pop model End--->
        </div>
    </div>
</div>