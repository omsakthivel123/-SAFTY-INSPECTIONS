<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Satff Module/</span>Staff Attendance Report</h4>

        <!-- Basic Layout & Basic with Icons -->

        <div class="row">

            <!-- Basic Layout -->
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-body">

                        <div class="row">
                            <div class="col-sm-12">
                                <!-- Material tab card start -->
                                <div class="card">
                                    <div class="card-block">
                                        <div class="row justify-content-end py-3">
                                            <div class="col-auto">
                                                <a href="<?php echo base_url('Staff_Attendance/entry') ?>" class="btn  btn-outline-secondary btn-sm ">Attendance</a>
                                            </div>
                                        </div>
                                        <div class="row py-3">

                                            <div class="col-md-3">
                                                <label for="InstutionName" class="text-dark"> Instution</label>
                                                <select name="InstutionName" class="form-control" id="InstutionName" required></select>
                                            </div>
                                            <div class="col-md-3">
                                                <label for="Department_attendance" class="text-dark">Department</label>
                                                <select name="Department_attendance" class="form-control" id="Department_attendance"> </select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('DepartmentName'); ?></span>

                                            </div>
                                            <div class="col-md-3">
                                                <label for="Staff_Type" class="text-dark">Staff Tpe</label>
                                                <select name="Staff_Type" class="form-control" id="Staff_Type">
                                                    <option value="Select Staff Type">Select Staff Type</option>
                                                    <option value="Teaching">Teaching</option>
                                                    <option value="Non_Teaching">Non Teaching</option>
                                                </select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('Staff_Type'); ?></span>


                                            </div>

                                            <div class="col-md-3">
                                                <label for="select_date" class="text-dark">Select Date</label>
                                                <input type="date" name="select_date" class="form-control" id="select_date">
                                                <span class="input-group" style="color:red;"><?php echo form_error('DepartmentName'); ?></span>

                                            </div>
                                        </div>
                                        <!-- Row start -->

                                        <div class="row justify-content-end py-3">
                                            <div class="col-auto">
                                                <button class="btn  btn-outline-info btn-sm " id="get_satff_list">View</button>
                                            </div>
                                        </div>





                                        <!-- Row start -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div>
                    <div>
                       




                        <!-- row complete for box   -->

                    </div>
                </div>
            </div>
            <div class="card mb-4" id="">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="custom-box bg-success" style="height: 80px; display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center;">
                                        <h5 id="box-details" style="margin-bottom: 1px; color: white;">Total Present</h5>
                                        <h6 id="present" style="display: block; color:white"></h6>
                                        </div>
                                    </div>

                                    <div class="col-md-3">
                                        <div class="custom-box bg-danger" style="height: 80px; display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center;">
                                            <h5 id="box-details"  style="margin-bottom: 1px; color: white;">Total Absent</h5>
                                            <h6 id="absent" style="display: block; color:white"></h6>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="custom-box bg-info" style="height: 80px; display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center;">
                                            <h5 id="box-details"  style="margin-bottom: 1px; color: white;">Total Permission</h5>
                                            <h6 id="permission" style="display: block; color:white"></h6>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="custom-box bg-warning" style="height: 80px; display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center;">
                                            <h5 id="box-details"  style="margin-bottom: 1px; color: white;">Total OD</h5>
                                            <h6 id="od" style="display: block; color:white"></h6>
                                        </div>
                                    </div>



                                </div>
                            </div>
                        </div>
                        <!-- row complete for box   -->

        </div>
