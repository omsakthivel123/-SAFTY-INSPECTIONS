<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Staff/</span>Staff Attendance</h4>

        <!-- Basic Layout & Basic with Icons -->
        <div class="row">
            <!-- Basic Layout -->
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-12">
                                <!-- Material tab card start -->
                                <div class="card">
                                    <div class="card-block">
                                        <form action="<?php echo base_url('') ?>" method="POST">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label for="InstutionName" class="text-dark">Instution Name</label>
                                                    <select name="InstutionName" class="form-control" id="InstutionName" required> </select>

                                                </div>

                                                <div class="col-md-4">
                                                    <label for="Department_attendance" class="text-dark">Department</label>
                                                    <select name="Department_attendance" class="form-control" id="Department_attendance" required> </select>
                                                    <input type="hidden" name='InstutionCode' id="InstutionCode">
                                                    <input type="hidden" name='Instution_Name' id="Instution_Name">
                                                    <input type="hidden" name='DepartmentCode' id="DepartmentCode">
                                                </div>
                                                <div class="col-md-4">
                                                <label for="Staff_Type" class="text-dark">Staff Tpe</label>
                                                <select name="Staff_Type" class="form-control" id="Staff_Type">
                                                    <option value="Select Staff Type">Select Staff Type</option>
                                                    <option value="Teaching">Teaching</option>
                                                    <option value="Non_Teaching">Non Teaching</option>
                                                </select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('Staff_Type'); ?></span>

                                            </div>
                                        
                                            </div>
                                        </form>
                                    </div>

                                    <!-- Row start -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card mb-4">
                    <div class="card-body" id="table-attendance">
                        <!-- Table Container Row Start -->
                        <div class="row">
                            
                            <div class="col-sm-12">
                                <!-- Material tab card start -->
                                <div class="card">
                                    <div class="card-block">
                                        <form id="myForm">
                                            <h2 style="display: flex; justify-content: center; font-size: 23px;">Attendance Sheet</h2>

                                            <div class="table-responsive">
                                                <table id="add_incharge" class="table table-sm table-bordered small-table">
                                                    <thead>

                                                    </thead>
                                                    <tbody id="attendance">

                                                    </tbody>

                                                </table>
                                            </div>


                                           
                                            <div class="row justify-content-end">
                                                <div class="col-auto">
                                                    <button type="button" id="update_addendance" class="btn btn-success btn-sm ">Update</button>
                                                </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Table Container Row End -->
                        <script>
                            // Function to handle flash messages with SweetAlert
                            function handleFlashMessages() {
                                <?php if ($this->session->flashdata('success')) : ?>
                                    Swal.fire({
                                        icon: 'success',
                                        title: 'Success!',
                                        text: '<?php echo $this->session->flashdata('success'); ?>',
                                    });
                                <?php elseif ($this->session->flashdata('error')) : ?>
                                    Swal.fire({
                                        icon: 'error',
                                        title: 'Error!',
                                        text: '<?php echo $this->session->flashdata('error'); ?>',
                                    });
                                <?php endif; ?>
                            }

                            // Call the function when the page loads
                            window.onload = function() {
                                handleFlashMessages();
                            };
                        </script>
                         <style>
        .option-green { color: green; }
        .option-red { color: red; }
        .option-orange { color: orange; }
        .option-indigo { color: indigo; }
        .option-secondary { color: grey; }
    </style>

                    </div>
                </div>
            </div>
        </div>
    </div>

</div>