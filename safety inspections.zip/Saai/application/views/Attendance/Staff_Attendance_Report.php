<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Staff/</span>Absent Attendance Report</h4>

        <!-- Basic Layout & Basic with Icons -->
      
        <div class="row">

            <!-- Basic Layout -->
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-body">

                        <div class="row">
                            <div class="col-sm-12">
                                <!-- Material tab card start -->
                                <div class="card">
                                    <div class="card-block">
                                    <h2 style="display: flex; justify-content: center; font-size: 23px;">Absent Reports</h2>
                                        <div class="row py-3">

                                            <div class="col-md-3 p-3">
                                                <label for="Institute_name" class="text-dark">Institute Name</label>
                                                <select name="Institute_name" class="form-control" id="Institute_name" required>
                                                    <option value="">Select</option>
                                                </select>
                                            </div>
                                            <div class="col-md-3 p-3">
                                                <label for="Department" class="text-dark">Department</label>
                                                <select name="Department" class="form-control" id="Department_type1" required></select>
                                            </div>
                                            <div class="col-md-3 p-3">
                                                <label for="Staff_type" class="text-dark">Staff Type</label>
                                                <select name="Staff_type" class="form-control" id="Staff_type" required>
                                                    <option value="">Select</option>
                                                    <option value="Teaching">Teaching</option>
                                                    <option value="Non_Teaching">Non Teaching</option>
                                                </select>
                                            </div>
                                            <div class="col-md-3  p-3 ">
                                                <label for="date" class="text-dark">Date </label>
                                                <input type="date" id="date_1" name="date" class="form-control" required>
                                            </div>
                                        </div>
                                        <div class="row justify-content-end py-3" id="view-btn">
                                            <div class="col-auto">
                                                <button type="button" class="btn btn-outline-danger btn-sm" id="get_aten_list1">View</button>
                                            </div>
                                          
                                        </div>
                                    </div>

                                    <!-- Row start -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
<div>
                <!-- row complete for box   -->

                <div class="card mb-4" id="Staff-view1">
                    <div class="card-body">
                        <div class="row">
                            <div id="attendance-record">
                                <div id="table-container" style="overflow-x: auto;">
                                <div class="d-flex justify-content-end mb-3">
                        <button onclick="downloadCSV()" class="btn btn-danger">Download Report</button>
                    </div>
                                    <table id="sheet" class="table table-striped">
                                        <thead style="background-color: #302c63; color: white;">
                                            <tr>
                                                <th  class="text-white">S No</th>
                                                <th  class="text-white">Staff ID</th>
                                                <th  class="text-white">Staff Name</th>
                                                <th  class="text-white">Department Name</th>
                                                <th  class="text-white">Staff Type</th>
                                                <th  class="text-white">DAY_1</th>
                                                <th  class="text-white">DAY_2</th>
                                                <th  class="text-white">DAY_3</th>
                                                <th  class="text-white">DAY_4</th>
                                                <th  class="text-white">DAY_5</th>
                                                <th  class="text-white">DAY_6</th>
                                                <th  class="text-white">DAY_7</th>
                                                <th  class="text-white">DAY_8</th>
                                                <th  class="text-white">DAY_9</th>
                                                <th  class="text-white">DAY_10</th>
                                                <th  class="text-white">DAY_11</th>
                                                <th  class="text-white">DAY_12</th>
                                                <th  class="text-white">DAY_13</th>
                                                <th  class="text-white">DAY_14</th>
                                                <th  class="text-white">DAY_15</th>
                                                <th  class="text-white">DAY_16</th>
                                                <th  class="text-white">DAY_17</th>
                                                <th  class="text-white">DAY_18</th>
                                                <th  class="text-white">DAY_19</th>
                                                <th  class="text-white">DAY_20</th>
                                                <th  class="text-white">DAY_21</th>
                                                <th  class="text-white">DAY_22</th>
                                                <th  class="text-white">DAY_23</th>
                                                <th  class="text-white">DAY_24</th>
                                                <th  class="text-white">DAY_25</th>
                                                <th  class="text-white">DAY_26</th>
                                                <th  class="text-white">DAY_27</th>
                                                <th  class="text-white">DAY_28</th>
                                                <th  class="text-white">DAY_29</th>
                                                <th  class="text-white">DAY_30</th>
                                                <th  class="text-white">DAY_31</th>
                                                <th  class="text-white">Total Present</th>
                                                <th  class="text-white">Total Absent</th>
                                            
                                            </tr>
                                        </thead>
                                        <tbody id="Atten_stud1">

                                        </tbody>
                                    </table>

                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                

                <!-- row complete for box   -->

            </div>
        </div>
    </div>

</div>
<script>
    function downloadCSV() {
        var csv = [];
        var rows = document.querySelectorAll("#sheet tr");

        for (var i = 0; i < rows.length; i++) {
            var row = [],
                cols = rows[i].querySelectorAll("td, th");

            for (var j = 0; j < cols.length; j++) {
                row.push(cols[j].innerText);
            }

            csv.push(row.join(","));
        }

        // Create a CSV Blob
        var csvFile = new Blob([csv.join("\n")], {
            type: "text/csv"
        });

        // Create a download link
        var downloadLink = document.createElement("a");
        downloadLink.download = "Staff_Report.csv";
        downloadLink.href = window.URL.createObjectURL(csvFile);
        downloadLink.style.display = "none";

        // Append the link to the DOM
        document.body.appendChild(downloadLink);

        // Trigger the download
        downloadLink.click();
    }
</script>
