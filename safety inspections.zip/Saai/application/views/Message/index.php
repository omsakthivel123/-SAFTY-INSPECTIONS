<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Information Module/</span>Absentees Report</h4>


        <div class="row">

            <!-- Basic Layout -->
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-body">

                        <div class="row">
                            <div class="col-sm-12">
                                <!-- Material tab card start -->
                                <div class="card">
                                    <div class="card-block">
                                        <div class="row py-3">

                                            <div class="col-md-3">
                                                <label for="InstutionName" class="text-dark"> Instution</label>
                                                <select name="InstutionName" class="form-control" id="InstutionName" required></select>
                                            </div>
                                            <div class="col-md-3">
                                                <label for="Course_type" class="text-dark">Course Type</label>
                                                <select name="Course_type" class="form-control" id="Course_type" required></select>
                                            </div>
                                            <div class="col-md-3">
                                                <label for="DepartmentName" class="text-dark">Department</label>
                                                <select name="DepartmentName" class="form-control" id="DepartmentName" required> </select>
                                            </div>
                                            <div class="col-md-3">
                                                <label for="Date" class="text-dark">Date</label>
                                                <input type="date" class="form-control" id="Date">
                                            </div>

                                        </div>

                                        <div class="row justify-content-end py-3" id="view-btn">
                                            <div class="col-auto">
                                                <button type="button" class="btn btn-outline-danger btn-sm" id="absentees_report">View</button>
                                            </div>
                                        </div>



                                    </div>

                                    <!-- Row start -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div>

                    <!-- row complete for box   -->

                    <div class="card mb-4" id="absent_reports">
                        <div class="card-body">
                            <div class="row">
                                <div id="attendance-record">
                                    <div id="table-container" style="overflow-x: auto;">
                                        <div class="row justify-content-start py-3" id="view-btn">
                                            <div class="col-auto">
                                                <button type="button" class="btn btn-outline-warning btn-sm" id="selected_all">Select All</button>
                                            </div>
                                        </div>
                                        <table id="student_absentees" class="table table-striped">
                                            <thead style="background-color: #302c63; ">
                                                <tr>
                                                    <th style="color: white;"></th>
                                                    <th style="color: white;">S.No</th>
                                                    <th style="color: white;"> Exam Reg No</th>
                                                    <th style="color: white;">Name</th>
                                                    <th style="color: white;">Gender</th>
                                                    <th style="color: white;">Mobile Number</th>
                                                    <th style="color: white;">Course Name</th>
                                                    <th style="color: white;">Semester</th>
                                                    <th style="color: white;">Status</th>
                                                    <th style="color: white;">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>

                                            </tbody>
                                        </table>

                                        <div class="row justify-content-end py-3" id="view-btn">
                                            <div class="col-auto">
                                                <button type="button" class="btn btn-outline-success btn-sm" id="update_message">Update</button>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                    <script>
                        // Function to handle flash messages with SweetAlert
                        function handleFlashMessages() {
                            <?php if ($this->session->flashdata('success')) : ?>
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Success!',
                                    text: '<?php echo $this->session->flashdata('success'); ?>',
                                });
                            <?php elseif ($this->session->flashdata('category_error')) : ?>
                                // Display SweetAlert with the flashdata message
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Oops...',
                                    text: '<?php echo $this->session->flashdata("category_error"); ?>'
                                });
                            <?php endif; ?>
                        }

                        // Call the function when the page loads
                        window.onload = function() {
                            handleFlashMessages();
                        };
                    </script>


                    <!-- row complete for box   -->

                </div>
            </div>
        </div>

    </div>