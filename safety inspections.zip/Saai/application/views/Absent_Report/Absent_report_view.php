<div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Report/</span>Absent Attendance Report</h4>
        <div class="row">
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="card">
                                    <div class="card-block">
                                        <div class="row">
                                            <div id="form-wizard21">
                                                <form id="attenans_mst" method="post" action="<?php echo base_url('Absent_Report/get_reports'); ?>">
                                                    <div class="step" id="step-1">
                                                        <h2 style="display: flex; justify-content: center; font-size: 23px;">Absent Reports</h2>
                                                        <div class="row">
                                                            <div class="col-md-6 p-3">
                                                                <label for="Institute_name" class="text-dark">Institute Name</label>
                                                                <select name="Institute_name" class="form-control" id="Institute_name" required>
                                                                    <option value="">Select</option>
                                                                    <!-- Add your institute options here -->
                                                                </select>
                                                            </div>
                                                            <div class="col-md-6  p-3 ">
                                                                <label for="date" class="text-dark">Date </label>
                                                                <input type="date" id="date1" name="date" class="form-control" required>
                                                            </div>
                                                        </div>
                                                        <div class="row" style="margin-top: 20px;">
                                                            <div class="row justify-content-end">
                                                                <div class="col-auto">
                                                                    <button type="submit" class="btn btn-outline-danger btn-sm submit">View</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="content-wrapper mt-1">
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-block">
                                        <div id="table-container" style="overflow-x: auto;">
                                            <div class="d-flex justify-content-end mb-3">
                                                <button onclick="downloadCSV()" class="btn btn-danger">Download Report</button>
                                            </div>
                                            <table id="sheet" class="table table-striped">
                                                <thead style="background-color: #302c63; color: white;">

                                                    <tr>
                                                        <th  class="text-white">Institution Name</th>
                                                        <th  class="text-white">Department Name</th>
                                                        <th  class="text-white">Course Name</th>
                                                        <th  class="text-white">Total Student</th>
                                                        <th  class="text-white">Total Present</th>
                                                        <th  class="text-white">Total Absent</th>
                                                        <th  class="text-white">OD</th>
                                                        <th  class="text-white">Permission</th>
                                                        <th  class="text-white">Late</th>
                                                        <th  class="text-white">Attendance Date</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php if (isset($reports) && !empty($reports)) : ?>
                                                        <?php foreach ($reports as $report) : ?>
                                                            <tr>
                                                                <td><?php echo $report->InstitutionName; ?></td>
                                                                <td><?php echo $report->DepartmentName; ?></td>
                                                                <td><?php echo $report->CourseName; ?></td>
                                                                <td><?php echo $report->TotalCount; ?></td>
                                                                <td><?php echo $report->PresentCount; ?></td>
                                                                <td><?php echo $report->TotalAbsent; ?></td>

                                                                <td><?php echo $report->OD; ?></td>
                                                                <td><?php echo $report->PermissionCount; ?></td>
                                                                <td><?php echo $report->LateCount; ?></td>
                                                                <td><?php echo $report->Date; ?></td>
                                                            </tr>
                                                        <?php endforeach; ?>
                                                    <?php else : ?>
                                                        <tr>
                                                            <td colspan="9">No data available</td>
                                                        </tr>
                                                    <?php endif; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<script>
    function downloadCSV() {
        var csv = [];
        var rows = document.querySelectorAll("#sheet tr");

        for (var i = 0; i < rows.length; i++) {
            var row = [],
                cols = rows[i].querySelectorAll("td, th");

            for (var j = 0; j < cols.length; j++) {
                row.push(cols[j].innerText);
            }

            csv.push(row.join(","));
        }

        // Create a CSV Blob
        var csvFile = new Blob([csv.join("\n")], {
            type: "text/csv"
        });

        // Create a download link
        var downloadLink = document.createElement("a");
        downloadLink.download = "Student_Report.csv";
        downloadLink.href = window.URL.createObjectURL(csvFile);
        downloadLink.style.display = "none";

        // Append the link to the DOM
        document.body.appendChild(downloadLink);

        // Trigger the download
        downloadLink.click();
    }
</script>