<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Student Module/</span>Attendance Report</h4>

        <!-- Basic Layout & Basic with Icons -->
        <div class="row justify-content-end py-3">
            <div class="col-auto">
                <a href="<?php echo base_url('student_attendance/update') ?>" class="btn  btn-outline-info btn-sm ">Update Attendance</a>
            </div>
        </div>
        <div class="row">

            <!-- Basic Layout -->
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-body">

                        <div class="row">
                            <div class="col-sm-12">
                                <!-- Material tab card start -->
                                <div class="card">
                                    <div class="card-block">
                                        <div class="row py-3">

                                            <div class="col-md-3">
                                                <label for="InstutionName" class="text-dark"> Instution</label>
                                                <select name="InstutionName" class="form-control" id="InstutionName" required></select>
                                            </div>
                                            <div class="col-md-3">
                                                <label for="Course_type" class="text-dark">Course Type</label>
                                                <select name="Course_type" class="form-control" id="Course_type" required></select>
                                            </div>
                                            <div class="col-md-3">
                                                <label for="DepartmentName" class="text-dark">Department</label>
                                                <select name="DepartmentName" class="form-control" id="DepartmentName" required> </select>
                                            </div>
                                            <div class="col-md-3">
                                                <label for="Batch" class="text-dark">Batch</label>
                                                <select name="Batch" class="form-control" id="Batch" required> </select>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-3">
                                                <label for="Course_name" class="text-dark">Course Name</label>
                                                <select name="Course_name" class="form-control" id="Course_name" required> </select>
                                            </div>
                                            <div class="col-md-3">
                                                <label for="Section" class="text-dark">Section</label>
                                                <select name="Section" class="form-control" id="Section" required> </select>
                                            </div>
                                            <div class="col-md-3">
                                                <label for="date" class="text-dark">Date</label>
                                                <input type="date" class="form-control" id="date_1">
                                            </div>
                                        </div>
                                        <div class="row justify-content-end py-3" id="view-btn">
                                            <div class="col-auto">
                                                <button type="button" class="btn btn-outline-danger btn-sm" id="get_aten_list">View</button>
                                            </div>
                                        </div>



                                    </div>

                                    <!-- Row start -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
<div>
                <div class="card mb-4" id="status-view">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-3">
                                <div class="custom-box bg-success" style="height: 80px; display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center;">
                                    <h5 id="box-details" style="margin-bottom: 1; color: white">Total Present</h5>
                                    <h6 id="present" style="display: block; color:white"></h6>
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="custom-box bg-danger" style="height: 80px; display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center;">
                                    <h5 id="box-details" style="margin-bottom: 1;  color: white">Total Absent</h5>
                                    <h6 id="absent" style="display: block; color:white"></h6>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="custom-box bg-info" style="height: 80px; display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center;">
                                    <h5 id="box-details" style="margin-bottom: 1;  color: white">Total Permission</h5>
                                    <h6 id="permission" style="display: block; color:white"></h6>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="custom-box bg-warning" style="height: 80px; display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center;">
                                    <h5 id="box-details" style="margin-bottom: 1;  color: white">Tota OD</h5>
                                    <h6 id="od" style="display: block; color:white"></h6>
                                </div>
                            </div>
                           
                         

                        </div>
                    </div>
                </div>
                <!-- row complete for box   -->

                <div class="card mb-4" id="table-view">
                    <div class="card-body">
                        <div class="row">
                            <div id="attendance-record">
                                <div id="table-container" style="overflow-x: auto;">
                                    <table id="sheet" class="table table-striped">
                                        <thead style="background-color: #302c63; color: white;">
                                            <tr>
                                                <th class="text-white" >S.No</th>
                                                <th class="text-white" >Student ID</th>
                                                <th class="text-white" > Exam Reg No</th>
                                                <th class="text-white" >Semester</th>
                                                <th class="text-white" >Name</th>
                                                <th class="text-white" >DAY_1</th>
                                                <th class="text-white" >DAY_2</th>
                                                <th class="text-white" >DAY_3</th>
                                                <th class="text-white" >DAY_4</th>
                                                <th class="text-white" >DAY_5</th>
                                                <th class="text-white" >DAY_6</th>
                                                <th class="text-white" >DAY_7</th>
                                                <th class="text-white" >DAY_8</th>
                                                <th class="text-white" >DAY_9</th>
                                                <th class="text-white" >DAY_10</th>
                                                <th class="text-white" >DAY_11</th>
                                                <th class="text-white" >DAY_12</th>
                                                <th class="text-white" >DAY_13</th>
                                                <th class="text-white" >DAY_14</th>
                                                <th class="text-white" >DAY_15</th>
                                                <th class="text-white" >DAY_16</th>
                                                <th class="text-white" >DAY_17</th>
                                                <th class="text-white" >DAY_18</th>
                                                <th class="text-white" >DAY_19</th>
                                                <th class="text-white" >DAY_20</th>
                                                <th class="text-white" >DAY_21</th>
                                                <th class="text-white" >DAY_22</th>
                                                <th class="text-white" >DAY_23</th>
                                                <th class="text-white" >DAY_24</th>
                                                <th class="text-white" >DAY_25</th>
                                                <th class="text-white" >DAY_26</th>
                                                <th class="text-white" >DAY_27</th>
                                                <th class="text-white" >DAY_28</th>
                                                <th class="text-white" >DAY_29</th>
                                                <th class="text-white" >DAY_30</th>
                                                <th class="text-white" >DAY_31</th>
                                                <th class="text-white" >Total Present</th>
                                                <th class="text-white" >Total Absent</th>
                                                <th class="text-white" >Percentage</th>
                                                <th class="text-white" >Created By</th>
                                            </tr>
                                        </thead>
                                        <tbody id="Atten_stud">

                                        </tbody>
                                    </table>

                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                

                <!-- row complete for box   -->

            </div>
        </div>
    </div>

</div>