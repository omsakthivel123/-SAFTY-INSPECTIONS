<style>
    .checkbox-row {
        display: flex;
        gap: 10px;
    }

    .checkbox-row label {
        display: flex;
        align-items: center;
    }
</style>

<div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Sub Staff/</span>Assign Time Table</h4>

        <div class="row">
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="card">
                                    <div class="card-block">
                                        <div class="row">
                                            <div id="form-wizard">
                                                <form id="wizard-form3">
                                                    <div class="step" id="step-1">
                                                        <h2 style="display: flex; justify-content: center; font-size: 23px;">Time Table</h2>
                                                        <div class="row">

                                                            <label for="Institute_name" class="text-dark" style="display: none;">Institute Name</label>
                                                            <input type="hidden" name="Institute_name2" id="Institution_name2" value="<?php echo $institution; ?>">

                                                            <input type="hidden" name="department_name2" id="Department_name0012" value="<?php echo $dep; ?>">

                                                            <div class="col-md-3 p-3">
                                                                <label for="Course_type" class="text-dark">Course Type</label>
                                                                <select name="Course_type01" class="form-control " id="Course_type01"></select>
                                                            </div>
                                                            <div class="col-md-3 p-3 ">
                                                                <label for="CourseCode01" class="text-dark">Course Code</label>
                                                                <select name="CourseCode01" class="form-control " id="CourseCode01"></select>
                                                            </div>
                                                            <div class="col-md-3 p-3 ">
                                                                <label for="Batch2" class="text-dark">Batch</label>
                                                                <select name="Batch2" class="form-control" id="Batch01"></select>
                                                            </div>
                                                            <div class="col-md-3 p-3 ">
                                                                <label for="Semester" class="text-dark">Semester</label>
                                                                <select name="Semester" class="form-control" id="Semester"></select>
                                                            </div>
                                                            
                                                            <div class="col-md-3 p-3 ">
                                                                <label for="Department" class="text-dark">Select Section</label>
                                                                <select name="Section23" class="form-control" id="Section01">
                                                                </select>
                                                            </div>
                                                            <div class="col-md-3 p-3 ">
                                                                <label for="Staff_id" class="text-dark">Staff Id</label>
                                                                <select name="Staff_id" class="form-control" id="Staff_id" ></select>
                                                            </div>
                                                            <div class="col-md-3 p-3 ">
                                                                <label for="Staff_Name1" class="text-dark">Staff Name</label>
                                                                <input type="text" name="Staff_Name1" class="form-control" id="Staff_Name" >
                                                            </div>

                                                            <div class="col-md-3 p-3 ">
                                                                <label for="Subject_Name" class="text-dark">Subject </label>
                                                                <select  name="Subject_Name" class="form-control" id="Subject_Name"></select>
                                                            </div>
                                                            <div class="col-md-3 p-3 ">
                                                                <label for="date" class="text-dark">Date </label>
                                                                <input type="date" id="date1" name="date" class="form-control">
                                                            </div>
                                                            <div class="col-md-3 p-3 ">
                                                                <label for="Dayss" class="text-dark">Days</label>
                                                                <select name="Dayss" class="form-control" id="Days">
                                                                    <option value="">Select</option>
                                                                    <option value="1">1 - Monday</option>
                                                                    <option value="2">2 - Tuesday</option>
                                                                    <option value="3">3 - Wednesday</option>
                                                                    <option value="4">4 - Thursday</option>
                                                                    <option value="5">5 - Friday</option>
                                                                    <option value="6">6 - Saturday</option>
                                                                </select>
                                                            </div>

                                                            <div class="col-md-3 p-3 ">
                                                                <label for="Department" class="text-dark">Select Departments</label>
                                                                <select name="Department_name21" class="form-control" id="Department_name21">
                                                                    <option value="">Select Departments</option>
                                                                </select>
                                                            </div>
                                                            <div class="col-md-3 p-3 ">
                                                                <label for="New_Staff_Id" class="text-dark">Sub Staff Id</label>
                                                                <select name="New_Staff_Id" class="form-control " id="New_Staff_Id" required>
                                                                </select>
                                                            </div>
                                                            <div class="col-md-3 p-3 ">
                                                                <label for="HourSelect" class="text-dark">Select Hours</label>
                                                                <select id="HourSelect" name="selectedHours[]" class="form-control">
                                                                    <option value="">Select Hour</option>
                                                                    <option value="1">1 Hours</option>
                                                                    <option value="2">2 Hours</option>
                                                                    <option value="3">3 Hours</option>
                                                                    <option value="4">4 Hours</option>
                                                                    <option value="5">5 Hours</option>
                                                                    <option value="6">6 Hours</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row justify-content-end">
                                                        <div class="col-auto">
                                                            <button type="submit" class="btn btn-success btn-sm submit">Add Substitution</button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-block">
                                        <div id="table-container" style="overflow-x: auto;">
                                            <table id="sheet" class="table table-striped">
                                                <thead style="background-color: #302c63; color: white;">
                                                    <tr>
                                                        <th  class="text-white">Department</th>
                                                        <th  class="text-white">Course Type</th>
                                                        <th  class="text-white">Batch</th>
                                                        <th  class="text-white">Course Code</th>
                                                        <th  class="text-white">Class Section</th>
                                                        <th  class="text-white">Subjects</th>
                                                        <th  class="text-white">Abs Staff Name</th>
                                                        <th  class="text-white">Staff Name</th>
                                                        <th  class="text-white">Date</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php if (!empty($substitution_data)) : ?>
                                                        <?php foreach ($substitution_data as $row) : ?>
                                                            <tr>

                                                                <td><?php echo $row->Department; ?></td>
                                                                <td><?php echo $row->Course_type; ?></td>
                                                                <td><?php echo $row->Batch; ?></td>
                                                                <td><?php echo $row->CourseCode; ?></td>
                                                                <td><?php echo $row->Class_Section; ?></td>
                                                                <td><?php echo $row->Subjects; ?></td>
                                                                <td><?php echo $row->leave_staff_name; ?></td>
                                                                <td><?php echo $row->Assign_Staff_Id; ?></td>
                                                                <td><?php echo $row->Date; ?></td>





                                                            </tr>
                                                        <?php endforeach; ?>
                                                    <?php else : ?>
                                                        <tr>
                                                            <td colspan="11">No data found</td>
                                                        </tr>
                                                    <?php endif; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>