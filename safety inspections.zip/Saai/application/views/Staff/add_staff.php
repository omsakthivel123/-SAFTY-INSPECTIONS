<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Add Staff/</span>New Staff</h4>

        <!-- Basic Layout & Basic with Icons -->
        <div class="row">
            <!-- Basic Layout -->
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-body">
                    <form action="<?php echo base_url('Staff/add_Staff') ?>" method="POST" enctype="multipart/form-data">

                        <div class="row">
                            <div class="col-sm-12">
                                <!-- Material tab card start -->
                                <div class="card">
                                    <div class="card-block">

                                        <div class="row">
                                            <div id="form-wizard">
                                                    <!-- Step 1 -->

                                                    <div class="step" id="step-1">
                                                        <h2 style="display: flex; justify-content: center; font-size: 23px;">Job Details</h2>
                                                        <div class="row py-2">

                                                            <div class="col-md-4">
                                                                <label for="Inst_name_1" class="text-dark">Instution Name</label>
                                                                <select name="Inst_name_1" class="form-control" id="Inst_name_1" >
                                                                </select>

                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="Inst_codes" class="text-dark">Instution Code</label>
                                                                <input type="text" name="Inst_codes" class="form-control" id="Inst_codes" >


                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="Staff_Type" class="text-dark">Staff Type</label>
                                                                <select name="Staff_Type" class="form-control" id="Staff_Type" value="<?php echo set_value('Staff_Type'); ?>">
                                                                    <option value="Select">Select Staff Type</option>
                                                                    <option value="Teaching">Teaching</option>
                                                                    <option value="Non-Teaching">Non-Teaching</option>
                                                                </select>

                                                                <span class="input-group" style="color:red;"><?php echo form_error('Staff_Type'); ?></span>
                                                            </div>
                                                        </div>
                                                        <div class="row py-2">
                                                       

            
                                                                <div class="col-md-4">
                                                                    <label for="Staff_Department_Name" class="text-dark">Department Name</label>
                                                                    <select name="Staff_Department_Name" class="form-control" id="Staff_Department_Name"> </select>
                                                                </div>
                                                                <div class="col-md-4">
                                                                    <label for="Staff_id" class="text-dark">Staff Id</label>
                                                                    <input type="text" id="Staff_id" name="Staff_id" class="form-control">

                                                                </div>
                                                                <div class="col-md-4">
                                                                    <label for="Positions" class="text-dark">Faculty Positions</label>
                                                                    <select name="Positions" class="form-control" id="Positions">
                                                                        <option value="Select">Select Position</option>
                                                                        <option value="Professor">Professor</option>
                                                                        <option value="Associate Professor">Associate Professor</option>
                                                                        <option value="Assistant Professor">Assistant Professor</option>
                                                                        <option value="Lecturer">Lecturer</option>
                                                                        <option value="Adjunct Professor">Adjunct Professor</option>
                                                                    </select>
                                                                </div>
                                                            </div>

                                                            <div class="row justify-content-end">
                                                                <div class="col-auto">
                                                                    <button type="button" class="btn btn-secondary btn-sm next">Next</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                   
                                                    <div class="step" id="step-2">
                                                        <h2 style="display: flex; justify-content: center; font-size: 23px;">Personal Details</h2>

                                                        <!-- row END -->
                                                        <div class="row  py-2">
                                                            <div class="col-md-4">
                                                                <label for="Titile" class="text-dark">Title</label>
                                                                <input type="text" id="Title" name="Title" class="form-control">
                                                                <span class="input-group" style="color:red;"><?php echo form_error('Titile'); ?></span>

                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="gender" class="text-dark">Gender</label>
                                                                <select name="gender" class="form-control" id="gender">
                                                                    <option value="select">Select</option>
                                                                    <option value="Male">Male</option>
                                                                    <option value="Female">Female</option>
                                                                    <option value="Others">Others</option>
                                                                </select>
                                                                <span class="input-group" style="color:red;"><?php echo form_error('gender'); ?></span>

                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="Initial" class="text-dark">Initial</label>
                                                                <input type="text" id="Initial" name="Initial" class="form-control">
                                                                <span class="input-group" style="color:red;"><?php echo form_error('Initial'); ?></span>

                                                            </div>

                                                        </div>
                                                        <!-- row END -->
                                                        <div class="row  py-2">
                                                            <div class="col-md-4">
                                                                <label for="Name" class="text-dark">Name</label>
                                                                <input type="text" id="Name" name="Name" class="form-control">
                                                                <span class="input-group" style="color:red;"><?php echo form_error('Name'); ?></span>

                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="dob" class="text-dark">DOB</label>
                                                                <input type="date" id="dob" name="dob" class="form-control">
                                                                <span class="input-group" style="color:red;"><?php echo form_error('dob'); ?></span>

                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="bgroup" class="text-dark">Blood Group</label>
                                                                <select name="bgroup" class="form-control" id="bgroup">
                                                                    <option value="select">Select</option>
                                                                    <option value="A+">A Positive (A+)</option>
                                                                    <option value="A-">A Negative (A-)</option>
                                                                    <option value="B+">B Positive (B+)</option>
                                                                    <option value="B-">B Negative (B-)</option>
                                                                    <option value="AB+">AB Positive (AB+)</option>
                                                                    <option value="AB-">AB Negative (AB-)</option>
                                                                    <option value="O+">O Positive (O+)</option>
                                                                    <option value="O-">O Negative (O-)</option>
                                                                </select>
                                                                <span class="input-group" style="color:red;"><?php echo form_error('bgroup'); ?></span>

                                                            </div>

                                                        </div>
                                                        <!-- row END -->
                                                        <div class="row  py-2">
                                                            <div class="col-md-4">
                                                                <label for="pob" class="text-dark">Place Of Birth</label>
                                                                <input type="text" id="pob" name="pob" class="form-control">
                                                                <span class="input-group" style="color:red;"><?php echo form_error('pob'); ?></span>

                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="Marital_Status" class="text-dark">Marital Status</label>
                                                                <select name="Marital_Status" class="form-control" id="Marital_Status">
                                                                    <option value="select">Select</option>
                                                                    <option value="Single">Single</option>
                                                                    <option value="Married">Married</option>
                                                                    <option value="Divorced">Divorced</option>
                                                                    <option value="Widowed">Widowed</option>
                                                                    <option value="Separated">Separated</option>
                                                                </select>
                                                                <span class="input-group" style="color:red;"><?php echo form_error('Marital_Status'); ?></span>

                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="Religion" class="text-dark">Religion</label>
                                                                <input type="text" id="Religion" name="Religion" class="form-control">
                                                                <span class="input-group" style="color:red;"><?php echo form_error('Religion'); ?></span>

                                                            </div>

                                                        </div>
                                                        <!-- row END -->
                                                        <div class="row  py-2">
                                                            <div class="col-md-4">
                                                                <label for="Physical_Disability" class="text-dark">Physical Disability</label>
                                                                <select name="Physical_Disability" class="form-control" id="Physical_Disability">
                                                                    <option value="select">Select</option>
                                                                    <option value="None">None</option>
                                                                    <option value="Mobility impairment">Mobility Impairment</option>
                                                                    <option value="Visual impairment">Visual Impairment</option>
                                                                    <option value="Hearing impairment">Hearing Impairment</option>
                                                                    <option value="Speech impairment">Speech Impairment</option>
                                                                    <option value="Others">Others</option>
                                                                </select>
                                                                <span class="input-group" style="color:red;"><?php echo form_error('Staff_Type'); ?></span>

                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="Community" class="text-dark">Community</label>
                                                                <select name="Community" class="form-control" id="Community">
                                                                    <option value="select">Select</option>
                                                                    <option value="General">General</option>
                                                                    <option value="BC">Backward Classes (BC)</option>
                                                                    <option value="MBC">Most Backward Classes (MBC)</option>
                                                                    <option value="SC">Scheduled Castes (SC)</option>
                                                                    <option value="ST">Scheduled Tribes (ST)</option>
                                                                    <option value="FC">Forward Classes (FC)</option>
                                                                    <!-- Add more options for specific communities in Tamil Nadu as needed -->
                                                                </select>
                                                                <span class="input-group" style="color:red;"><?php echo form_error('Community'); ?></span>

                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="Caste" class="text-dark">Caste</label>
                                                                <input type="text" id="Caste" name="Caste" class="form-control">
                                                                <span class="input-group" style="color:red;"><?php echo form_error('Caste'); ?></span>

                                                            </div>

                                                        </div>
                                                        <!-- row END -->
                                                        <div class="row  py-2">
                                                            <div class="col-md-4">
                                                                <label for="Mobile" class="text-dark">Mobile</label>
                                                                <input type="text" id="Mobile" name="Mobile" class="form-control" minlength="10" maxlength="10">
                                                                <span class="input-group" style="color:red;"><?php echo form_error('Mobile'); ?></span>

                                                            </div>

                                                            <div class="col-md-4">
                                                                <label for="Email" class="text-dark">Email Id</label>
                                                                <input type="email" id="Email" name="Email" class="form-control">
                                                                <span class="input-group" style="color:red;"><?php echo form_error('Email'); ?></span>

                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="Aadhar_Number" class="text-dark">Aadhar Number</label>
                                                                <input type="text" id="Aadhar_Number" name="Aadhar_Number" pattern="[0-9]{12}" title="Please enter exactly 12 digits." class="form-control" minlength="12" maxlength="12">
                                                                <span class="input-group" style="color:red;"><?php echo form_error('Aadhar_Number'); ?></span>

                                                            </div>
                                                        </div>
                                                        <div class="row py-2">
                                                            <div class="col-md-4">
                                                                <label for="Mother_Tongue" class="text-dark">Mother Tongue</label>
                                                                <select name="Mother_Tongue" class="form-control" id="Mother_Tongue">
                                                                    <option value="select">Select</option>
                                                                    <option value="Tamil">Tamil</option>
                                                                    <option value="English">English</option>
                                                                </select>
                                                                <span class="input-group" style="color:red;"><?php echo form_error('Mother_Tongue'); ?></span>

                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="Language" class="text-dark">Language</label>
                                                                <select name="Language" class="form-control" id="Language">
                                                                    <option value="select">Select</option>
                                                                    <option value="Tamil">Tamil</option>
                                                                    <option value="English">English</option>
                                                                </select>
                                                                <span class="input-group" style="color:red;"><?php echo form_error('Language'); ?></span>

                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="Profile" class="text-dark">Profile Picture</label>
                                                                <input type="file" name="image" class="form-control" id="Profile">
                                                                <span class="input-group" style="color:red;"><?php echo form_error('Profile'); ?></span>

                                                            </div>
                                                        </div>
                                                        <div class="row justify-content-end">
                                                            <div class="col-auto">
                                                                <button type="button" class="btn btn-danger btn-sm prev">Previous</button>
                                                                <button type="button" class="btn btn-secondary btn-sm next">Next</button>
                                                            </div>

                                                        </div>
                                                    </div>
                                                    <!-- Step 2 -->
                                                    <div class="step" id="step-3">
                                                        <h2 style="display: flex; justify-content: center; font-size: 23px;">Bank Details</h2>
                                                        <div class="row  py-2">
                                                            <div class="col-md-4">
                                                                <label for="IFSC" class="text-dark">IFSC</label>
                                                                <input type="text" id="IFSC" name="IFSC" class="form-control">
                                                                <span class="input-group" style="color:red;"><?php echo form_error('IFSC'); ?></span>

                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="Bank_name" class="text-dark">Bank Name</label>
                                                                <input type="text" id="Bank_name" name="Bank_name" class="form-control">
                                                                <span class="input-group" style="color:red;"><?php echo form_error('Bank_name'); ?></span>

                                                            </div>

                                                            <div class="col-md-4">
                                                                <label for="Bank_address" class="text-dark">Bank Address</label>
                                                                <input type="text" id="Bank_address" name="Bank_address" class="form-control">
                                                                <span class="input-group" style="color:red;"><?php echo form_error('Bank_address'); ?></span>

                                                            </div>
                                                        </div>
                                                        <div class="row py-2">
                                                            <div class="col-md-4">
                                                                <label for="MICR_No" class="text-dark">MICR No</label>
                                                                <input type="text" id="MICR_No" name="MICR_No" class="form-control">
                                                                <span class="input-group" style="color:red;"><?php echo form_error('MICR_No'); ?></span>

                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="Account_No" class="text-dark">Account No</label>
                                                                <input type="text" id="Account_No" name="Account_No" class="form-control">
                                                                <span class="input-group" style="color:red;"><?php echo form_error('Account_No'); ?></span>

                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="PAN_Card" class="text-dark">PAN Card No</label>
                                                                <input type="text" id="PAN_Card" name="PAN_Card" class="form-control">
                                                                <span class="input-group" style="color:red;"><?php echo form_error('PAN_Card'); ?></span>

                                                            </div>
                                                        </div>

                                                        <div class="row justify-content-end">
                                                            <div class="col-auto">
                                                                <button type="button" class="btn btn-danger btn-sm prev">Previous</button>
                                                                <button type="button" class="btn btn-secondary btn-sm next">Next</button>

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- Step 3 -->
                                                    <div class="step" id="step-4">
                                                        <h2 style="display: flex; justify-content: center; font-size: 23px;">Permanet Address</h2>
                                                        <div class="row  py-2">
                                                            <div class="col-md-4">
                                                                <label for="Address" class="text-dark">Address 1</label>
                                                                <input type="text" id="Address" name="Address" class="form-control">
                                                                <span class="input-group" style="color:red;"><?php echo form_error('Address'); ?></span>

                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="Address1" class="text-dark">Address 2</label>
                                                                <input type="text" id="Address1" name="Address1" class="form-control">
                                                                <span class="input-group" style="color:red;"><?php echo form_error('Address1'); ?></span>

                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="postalcode" class="text-dark">Postal Code</label>
                                                                <input type="text" id="postalcode" name="postalcode" class="form-control">
                                                                <span class="input-group" style="color:red;"><?php echo form_error('postalcode'); ?></span>

                                                            </div>
                                                        </div>
                                                        <div class="row  py-2">
                                                            <div class="col-md-4">
                                                                <label for="Postofficename" class="text-dark">Post office Name</label>
                                                                <input type="text" id="Postofficename" name="Postofficename" class="form-control">
                                                                <span class="input-group" style="color:red;"><?php echo form_error('Postofficename'); ?></span>

                                                            </div>

                                                            <div class="col-md-4">
                                                                <label for="District" class="text-dark">District</label>
                                                                <select id="District" name="District" class="form-control">
                                                                    <option value="">Select District</option>
                                                                    <option value="Ariyalur">Ariyalur</option>
                                                                    <option value="Chengalpattu">Chengalpattu</option>
                                                                    <option value="Chennai">Chennai</option>
                                                                    <option value="Coimbatore">Coimbatore</option>
                                                                    <option value="Cuddalore">Cuddalore</option>
                                                                    <option value="Dharmapuri">Dharmapuri</option>
                                                                    <option value="Dindigul">Dindigul</option>
                                                                    <option value="Erode">Erode</option>
                                                                    <option value="Kallakurichi">Kallakurichi</option>
                                                                    <option value="Kancheepuram">Kancheepuram</option>
                                                                    <option value="Kanyakumari">Kanyakumari</option>
                                                                    <option value="Karur">Karur</option>
                                                                    <option value="Krishnagiri">Krishnagiri</option>
                                                                    <option value="Madurai">Madurai</option>
                                                                    <option value="Nagapattinam">Nagapattinam</option>
                                                                    <option value="Namakkal">Namakkal</option>
                                                                    <option value="Nilgiris">Nilgiris</option>
                                                                    <option value="Perambalur">Perambalur</option>
                                                                    <option value="Pudukkottai">Pudukkottai</option>
                                                                    <option value="Ramanathapuram">Ramanathapuram</option>
                                                                    <option value="Salem">Salem</option>
                                                                    <option value="Sivaganga">Sivaganga</option>
                                                                    <option value="Tenkasi">Tenkasi</option>
                                                                    <option value="Thanjavur">Thanjavur</option>
                                                                    <option value="Theni">Theni</option>
                                                                    <option value="Thoothukudi">Thoothukudi</option>
                                                                    <option value="Tiruchirappalli">Tiruchirappalli</option>
                                                                    <option value="Tirunelveli">Tirunelveli</option>
                                                                    <option value="Tirupathur">Tirupathur</option>
                                                                    <option value="Tiruppur">Tiruppur</option>
                                                                    <option value="Tiruvallur">Tiruvallur</option>
                                                                    <option value="Tiruvannamalai">Tiruvannamalai</option>
                                                                    <option value="Tiruvarur">Tiruvarur</option>
                                                                    <option value="Vellore">Vellore</option>
                                                                    <option value="Viluppuram">Viluppuram</option>
                                                                    <option value="Virudhunagar">Virudhunagar</option>
                                                                </select>
                                                                <span class="input-group" style="color:red;"><?php echo form_error('District'); ?></span>

                                                            </div>

                                                        </div>


                                                        <div class="row justify-content-end">
                                                            <div class="col-auto">
                                                                <button type="button" class="btn btn-danger btn-sm prev">Previous</button>
                                                                <button type="button" class="btn btn-secondary btn-sm next">Next</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- Step 4 -->
                                                    <div class="step" id="step-5">
                                                        <h2 style="display: flex; justify-content: center; font-size: 23px;">Education Details</h2>
                                                        <div class="row  py-2">
                                                            <div class="col-md-4">
                                                                <label for="Course_Type" class="text-dark">Course Type</label>
                                                                <select name="Course_Type" class="form-control" id="Course_Type">
                                                                    <option value="select">Select</option>
                                                                    <option value="UG">UG</option>
                                                                    <option value="PG">PG</option>
                                                                </select>
                                                                <span class="input-group" style="color:red;"><?php echo form_error('Course_Type'); ?></span>

                                                            </div>
                                                            <div class="col-md-4" id="ug">
                                                                <label for="UGDegree" class="text-dark">Degree</label>
                                                                <input type="text" id="UGDegree" name="UGDegree" class="form-control">
                                                                <span class="input-group" style="color:red;"><?php echo form_error('UGDegree'); ?></span>

                                                            </div>

                                                            <div class="col-md-4">
                                                                <label for="Passingyear" class="text-dark">Passing Year</label>
                                                                <select name="Passingyear" id="Passingyear" class="form-control">
                                                                    <option value="">Select Year</option> <!-- Added default option -->
                                                                    <?php
                                                                    $current_year = date("Y");
                                                                    $start_year = 1950;

                                                                    for ($year = $current_year; $year >= $start_year; $year--) {
                                                                        echo '<option value="' . $year . '">' . $year . '</option>';
                                                                    }
                                                                    ?>
                                                                </select>
                                                                <span class="input-group" style="color:red;"><?php echo form_error('Passingyear'); ?></span>

                                                            </div>

                                                        </div>
                                                        <div class="row  py-2">
                                                            <div class="col-md-4">
                                                                <label for="University_Name" class="text-dark">University Name</label>
                                                                <input type="text" id="University_Name" name="University_Name" class="form-control">
                                                                <span class="input-group" style="color:red;"><?php echo form_error('University_Name'); ?></span>

                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="Instiute" class="text-dark">Instiute</label>
                                                                <input type="text" id="Instiute" name="Instiute" class="form-control">
                                                                <span class="input-group" style="color:red;"><?php echo form_error('Instiute'); ?></span>

                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="Mode" class="text-dark">Mode</label>
                                                                <select name="CourseMode_Type" class="form-control" id="CourseMode_Type">
                                                                    <option value="select">Select</option>
                                                                    <option value="Regular">Regular</option>
                                                                    <option value="Distance Education">Distance Education</option>
                                                                </select>
                                                                <span class="input-group" style="color:red;"><?php echo form_error('Mode'); ?></span>

                                                            </div>

                                                        </div>
                                                        <div class="row  py-2">
                                                            <div class="col-md-4">
                                                                <label for="Percentace" class="text-dark">Percentace</label>
                                                                <input type="text" id="Percentace" name="Percentace" class="form-control">
                                                                <span class="input-group" style="color:red;"><?php echo form_error('Percentace'); ?></span>

                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="Specializations" class="text-dark">Specializations</label>
                                                                <input type="text" id="	Specializations" name="	Specializations" class="form-control">
                                                                <span class="input-group" style="color:red;"><?php echo form_error('Specializations'); ?></span>

                                                            </div>

                                                            <div class="col-md-4">
                                                                <button type="button" class="btn btn-outline-primary btn-sm" id="add">Add More</button>

                                                            </div>
                                                        </div>
                                                        <br>
                                                        <div class="add_more" id="add_more">

                                                        </div>
                                                        <div class="row justify-content-end">
                                                            <div class="col-auto">
                                                                <button type="button" class="btn btn-danger btn-sm prev">Previous</button>
                                                                <button type="submit" class="btn btn-success btn-sm ">Submit</button>
                                                            </div>
                                                        </div>


                                                    </div>
                                               
                                            </div>
                                            </form


                                        </div>
                                    </div>
                                </div>
                                <!-- Row start -->
                            </div>
                            <script>
                                // Function to handle flash messages with SweetAlert
                                function handleFlashMessages() {
                                    <?php if ($this->session->flashdata('success')) : ?>
                                        Swal.fire({
                                            icon: 'success',
                                            title: 'Success!',
                                            text: '<?php echo $this->session->flashdata('success'); ?>',
                                            showConfirmButton: true,
                                            onClose: () => {
                                                // Redirect or do something after closing
                                            }
                                        }).then((result) => {
                                            if (result.isConfirmed) {
                                                // Close the SweetAlert dialog
                                                Swal.close();
                                            }
                                        });
                                    <?php elseif ($this->session->flashdata('error')) : ?>
                                        Swal.fire({
                                            icon: 'error',
                                            title: 'Error!',
                                            text: '<?php echo $this->session->flashdata('error'); ?>',
                                            showConfirmButton: true,
                                            onClose: () => {
                                                // Redirect or do something after closing
                                            }
                                        }).then((result) => {
                                            if (result.isConfirmed) {
                                                // Close the SweetAlert dialog
                                                Swal.close();
                                            }
                                        });
                                    <?php endif; ?>
                                }

                                // Call the function when the page loads
                                window.onload = function() {
                                    handleFlashMessages();
                                };
                            </script>



                        </div>

                        <!-- Row start -->
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
<!-- Table Container Row End
            </div>
            </div> -->

<style>
    .step {
        display: none;
    }

    .step.active {
        display: block;
    }

    button {
        margin-top: 20px;
    }
</style>