<div class="content-wrapper">
    <!-- Content -->

    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Staff/</span>Staff Details Report</h4>

        <!-- Basic Layout & Basic with Icons -->
        <div class="row">
            <!-- Basic Layout -->
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-body">
                        <!-- Stage 1 -->
                        <div class="stage" id="stage1">
                            <h2 style="display: flex; justify-content: center; font-size: 23px;">Staff Reports</h2>

                            <div class="row">
                                <div class="col-md-4 p-3">
                                    <label for="Inst_name_1" class="text-dark">Institution Name</label>
                                    <select name="Inst_name_1" class="form-control" id="Inst_name_1" required></select>
                                </div>
                                <div class="col-md-4 p-3">
                                    <label for="Inst_codes" class="text-dark">Institution Code</label>
                                    <input type="text" name="Inst_codes" class="form-control" id="Inst_codes" readonly>
                                </div>
                                <div class="col-md-4 p-3">
                                    <label for="department" class="text-dark">Department Name</label>
                                    <select name="department" class="form-control" id="Department_Name11"></select>
                                </div>
                             </div>

                            <div class="row justify-content-end py-3" id="view-btn">
                                <div class="col-auto">
                                    <button type="button" class="btn btn-outline-danger btn-sm" id="Staff_details">View</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card mb-4" id="Staff-view2">
                <div class="card-body">
                    <div class="row">
                        <div id="attendance-record">
                            <div id="table-container" style="overflow-x: auto;">
                                <div class="d-flex justify-content-end mb-3">
                                    <button id="download-buttonStaff" class="btn btn-danger">Download Report</button>
                                </div>
                                <table id="sheet" class="table table-striped">
                                    <thead style="background-color: #302c63; color: white;">
                                        <tr>
                                            <th class="text-white">S.No</th>
                                            <th class="text-white">Institution Code</th>
                                            <th class="text-white">Institution Name</th>
                                            <th class="text-white">Staff Type</th>
                                            <th class="text-white">Staff ID</th>
                                            <th class="text-white">Title</th>
                                            <th class="text-white">Gender</th>
                                            <th class="text-white">Initial</th>
                                            <th class="text-white">Name</th>
                                            <th class="text-white">DOB</th>
                                            <th class="text-white">Blood Group</th>
                                            <th class="text-white">Place Of Birth</th>
                                            <th class="text-white">Marital Status</th>
                                            <th class="text-white">Religion</th>
                                            <th class="text-white">Physical Disability</th>
                                            <th class="text-white">Community</th>
                                            <th class="text-white">Caste</th>
                                            <th class="text-white">Mobile</th>
                                            <th class="text-white">Email</th>
                                            <th class="text-white">Aadhar Number</th>
                                            <th class="text-white">Mother Tongue</th>
                                            <th class="text-white">Language</th>
                                            <th class="text-white">IFSC</th>
                                            <th class="text-white">Bank Name</th>
                                            <th class="text-white">Bank Address</th>
                                            <th class="text-white">MICR No</th>
                                            <th class="text-white">Account No</th>
                                            <th class="text-white">PAN Card</th>
                                            <th class="text-white">Address</th>
                                            <th class="text-white">Address 1</th>
                                            <th class="text-white">Postal Code</th>
                                            <th class="text-white">Post Office Name</th>
                                            <th class="text-white">District</th>
                                            <th class="text-white">Department Name</th>
                                            <th class="text-white">Course Type</th>
                                            <th class="text-white">Degree</th>
                                            <th class="text-white">Passing Year</th>
                                            <th class="text-white">University Name</th>
                                            <th class="text-white">Institute</th>
                                            <th class="text-white">Course Mode Type</th>
                                            <th class="text-white">Percentage</th>
                                            <th class="text-white">Specialization</th>
                                            <th class="text-white">Course Type 1</th>
                                            <th class="text-white">Degree 1</th>
                                            <th class="text-white">Passing Year 1</th>
                                            <th class="text-white">University Name 1</th>
                                            <th class="text-white">Institute 1</th>
                                            <th class="text-white">Course Mode Type 1</th>
                                            <th class="text-white">Percentage 1</th>
                                            <th class="text-white">Specialization 1</th>
                                            <th class="text-white">Course Type 2</th>
                                            <th class="text-white">Degree 2</th>
                                            <th class="text-white">Passing Year 2</th>
                                            <th class="text-white">University Name 2</th>
                                            <th class="text-white">Institute 2</th>
                                            <th class="text-white">Course Mode Type 2</th>
                                            <th class="text-white">Percentage 2</th>
                                            <th class="text-white">Specialization 2</th>
                                            <th class="text-white">Course Type 3</th>
                                            <th class="text-white">Degree 3</th>
                                            <th class="text-white">Passing Year 3</th>
                                            <th class="text-white">University Name 3</th>
                                            <th class="text-white">Institute 3</th>
                                            <th class="text-white">Course Mode Type 3</th>
                                            <th class="text-white">Percentage 3</th>
                                            <th class="text-white">Specialization 3</th>
                                            <th class="text-white">Course Type 4</th>
                                            <th class="text-white">Degree 4</th>
                                            <th class="text-white">Passing Year 4</th>
                                            <th class="text-white">University Name 4</th>
                                            <th class="text-white">Institute 4</th>
                                            <th class="text-white">Course Mode Type 4</th>
                                            <th class="text-white">Percentage 4</th>
                                            <th class="text-white">Specialization 4</th>
                                            <th class="text-white">Course Type 5</th>
                                            <th class="text-white">Degree 5</th>
                                            <th class="text-white">Passing Year 5</th>
                                            <th class="text-white">University Name 5</th>
                                            <th class="text-white">Institute 5</th>
                                            <th class="text-white">Course Mode Type 5</th>
                                            <th class="text-white">Percentage 5</th>
                                            <th class="text-white">Specialization 5</th>
                                            <th class="text-white">Course Type 6</th>
                                            <th class="text-white">Degree 6</th>
                                            <th class="text-white">Passing Year 6</th>
                                            <th class="text-white">University Name 6</th>
                                            <th class="text-white">Institute 6</th>
                                            <th class="text-white">Course Mode Type 6</th>
                                            <th class="text-white">Percentage 6</th>
                                            <th class="text-white">Specialization 6</th>
                                        </tr>
                                    </thead>
                                    <tbody id="Staff_detail1"></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<form action="<?php echo base_url('Downloader/Staff_Details') ?>" method="post" style="display: none;" id="Staff-download-form">
    <input type="text" name="Inst_name_1" id="data1">
    <input type="text" name="Inst_codes" id="data2">
    <input type="text" name="department" id="data3">
</form>


<script>
    $(document).ready(function() {
        $('#Staff_details').click(function() {
            var institutionName = $('#Inst_name_1').val();
            var Inst_codes = $('#Inst_codes').val();
            var departmentName = $('#Department_Name11').val();
            $('#data1').val(institutionName);
            $('#data2').val(Inst_codes);
            $('#data3').val(departmentName);
            $('#form_data').submit();
        });

        $('#download-buttonStaff').click(function() {
            var institutionName = $('#Inst_name_1').val();
            var Inst_codes = $('#Inst_codes').val();
            var departmentName = $('#Department_Name11').val();
            $('#data1').val(institutionName);
            $('#data2').val(Inst_codes);
            $('#data3').val(departmentName);
            $('#Staff-download-form').submit();
        });
    });
</script>



