<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Faculty Management/</span>Edit Faculty Profile</h4>
        <form  method="POST" enctype="multipart/form-data">
            <div class="row">
                <!-- First Card -->
                <div class="col-xxl-6">
                    <div class="card mb-4">
                        <div class="card-body">

                            <!-- <div class="col-md-6 d-flex flex-column align-items-center">
                    <h5 style="text-align: center;">Faculty Profile Image</h5> -->
                            <div class="row">
                                <label for="Title" class="col-md-12 control-label d-flex justify-content-center text-black">Faculty Profile Image</label>
                            </div>

                            <div class="row justify-content-center">
                                <div class="col-md-6">
                                    <div class="position-relative mb-3 d-flex justify-content-center">
                                        <img src="<?php echo base_url('uploads/Staff_Profile/' . $staff->Profile); ?>" value="<?php echo $staff->Profile ?>"  id="current_image" alt="Staff Image" name="image" class="img-thumbnail">
                                        <input type="hidden" name="image_name" value="<?php echo $staff->Profile; ?>">
                                        <div class="overlay-icon">
                                            <label for="upload_image" class="btn btn-link btn-change-image">
                                                <i class="fas fa-camera"></i>
                                            </label>
                                            <input type="file" id="upload_image" name="image" value="<?php $staff->Profile;?>" style="display: none;">
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div class="row p-3">
                                <label for="Title" class="col-sm-4 control-label">Faculty Title<sup>*</sup></label>
                                <div class="col-sm-7">
                                    <input type="text" id="title" name="Title" class="form-control" value="<?php echo $staff->Title; ?>">
                                    <span class="input-group" style="color:red;"><?php echo form_error('Title'); ?></span>

                                </div>
                            </div>
                            <div class="row p-3">
                                <label for="Initial" class="col-sm-4 control-label">Faculty Initial<sup>*</sup></label>
                                <div class="col-sm-7">
                                    <input type="text" id="initial" name="Initial" class="form-control" value="<?php echo $staff->Initial; ?>">
                                    <span class="input-group" style="color:red;"><?php echo form_error('Initial'); ?></span>

                                </div>
                            </div>
                            <div class="row p-3">
                                <label for="Name" class="col-sm-4 control-label">Faculty Name<sup>*</sup></label>
                                <div class="col-sm-7">
                                    <input type="text" id="name" name="Name" class="form-control" value="<?php echo $staff->Name; ?>">
                                    <span class="input-group" style="color:red;"><?php echo form_error('Name'); ?></span>

                                </div>
                            </div>
                            <div class="row p-3">
                                <label for="FacultyId" class="col-sm-4 control-label">Faculty Id<sup>*</sup></label>
                                <div class="col-sm-7">
                                    <input type="text" id="faculty_id" name="FacultyId" class="form-control" value="<?php echo $staff->Staff_id; ?>">
                                    <span class="input-group" style="color:red;"><?php echo form_error('FacultyId'); ?></span>

                                </div>
                            </div>
                            <div class="row p-3">
                                <label for="FacultyType" class="col-sm-4 control-label">Faculty Type<sup>*</sup></label>
                                <div class="col-sm-7">
                                    <input type="text" id="faculty_type" name="FacultyType" class="form-control" value="<?php echo $staff->Staff_Type; ?>">
                                    <span class="input-group" style="color:red;"><?php echo form_error('FacultyType'); ?></span>

                                </div>
                            </div>
                            <div class="row p-3">
                                <label for="FacultyPosition" class="col-sm-4 control-label">Faculty Position <sup>*</sup></label>
                                <div class="col-sm-7">
                                    <input type="text" id="faculty_position" name="FacultyPosition" class="form-control" value="<?php echo $staff->Position; ?>">
                                    <span class="input-group" style="color:red;"><?php echo form_error('FacultyPosition'); ?></span>

                                </div>
                            </div>
                            <div class="row p-3">
                                <label for="Institution" class="col-sm-4 control-label">Institution<sup>*</sup></label>
                                <div class="col-sm-7">
                                    <input type="text" id="institution" name="Institution" class="form-control" value="<?php echo $staff->InstutionName; ?>">
                                    <span class="input-group" style="color:red;"><?php echo form_error('Institution'); ?></span>

                                </div>
                            </div>
                            <div class="row p-3">
                                <label for="Department" class="col-sm-4 control-label">Department<sup>*</sup></label>
                                <div class="col-sm-7">
                                    <input type="text" id="department" name="Department" class="form-control" value="<?php echo $staff->Department_Name; ?>">
                                    <span class="input-group" style="color:red;"><?php echo form_error('Department'); ?></span>

                                </div>
                            </div>
                            <div class="row p-3">
                                <label for="BloodGroup" class="col-sm-4 control-label">Blood Group<sup>*</sup></label>
                                <div class="col-sm-7">
                                    <input type="text" id="blood_group" name="BloodGroup" class="form-control" value="<?php echo $staff->Blood_Group; ?>">
                                    <span class="input-group" style="color:red;"><?php echo form_error('BloodGroup'); ?></span>

                                </div>
                            </div>
                            <div class="row p-3">
                                <label for="Mobile" class="col-sm-4 control-label">Mobile<sup>*</sup></label>
                                <div class="col-sm-7">
                                    <input type="text" id="mobile" name="Mobile" class="form-control" value="<?php echo $staff->Mobile; ?>">
                                    <span class="input-group" style="color:red;"><?php echo form_error('Mobile'); ?></span>

                                </div>
                            </div>
                            <div class="row p-3">
                                <label for="Email" class="col-sm-4 control-label">Email<sup>*</sup></label>
                                <div class="col-sm-7">
                                    <input type="email" id="email" name="Email" class="form-control" value="<?php echo $staff->Email; ?>">
                                    <span class="input-group" style="color:red;"><?php echo form_error('Email'); ?></span>

                                </div>
                            </div>
                            <div class="row p-3">
                                <label for="Community" class="col-sm-4 control-label">Community<sup>*</sup></label>
                                <div class="col-sm-7">
                                    <input type="text" id="community" name="Community" class="form-control" value="<?php echo $staff->Community; ?>">
                                    <span class="input-group" style="color:red;"><?php echo form_error('Community'); ?></span>

                                </div>
                            </div>
                            
                           
                        </div>
                    </div>
                </div>

                <!-- Second Card -->
                <div class="col-xxl-6">
                    <div class="card mb-4">
                        <div class="card-body">
                            
                        
                            <div class="row p-3">
                                <label for="Religion" class="col-sm-4 control-label">Religion<sup>*</sup></label>
                                <div class="col-sm-7">
                                    <input type="text" id="Religion" name="Religion" class="form-control" value="<?php echo $staff->Religion; ?>">
                                    <span class="input-group" style="color:red;"><?php echo form_error('Religion'); ?></span>

                                </div>
                            </div>
                            <div class="row p-3">
                                <label for="AadharNumber" class="col-sm-4 control-label">Aadhar Number<sup>*</sup></label>
                                <div class="col-sm-7">
                                    <input type="text" id="AadharNumber" name="AadharNumber" class="form-control" value="<?php echo $staff->Aadhar_Number; ?>" maxlength="16">
                                    <span class="input-group" style="color:red;"><?php echo form_error('AadharNumber'); ?></span>

                                </div>
                            </div>
                            <div class="row p-3">
                                <label for="pancard" class="col-sm-4 control-label">PAN Card No<sup>*</sup></label>
                                <div class="col-sm-7">
                                    <input type="text" id="pancard" name="pancard" class="form-control" value="<?php echo $staff->PAN_Card; ?>">
                                    <span class="input-group" style="color:red;"><?php echo form_error('pancard'); ?></span>

                                </div>
                            </div>
                            <div class="row p-3">
                                <label for="Address" class="col-sm-4 control-label">Address<sup>*</sup></label>
                                <div class="col-sm-7">
                                    <input type="text" id="address" name="Address" class="form-control" value="<?php echo $staff->Address; ?>">
                                    <span class="input-group" style="color:red;"><?php echo form_error('Address'); ?></span>

                                </div>
                            </div>
                            <div class="row p-3">
                                <label for="District" class="col-sm-4 control-label">District<sup>*</sup></label>
                                <div class="col-sm-7">
                                    <input type="text" id="district" name="District" class="form-control" value="<?php echo $staff->District; ?>">
                                    <span class="input-group" style="color:red;"><?php echo form_error('District'); ?></span>

                                </div>
                            </div>
                            <div class="row p-3">
                                <label for="Taluk" class="col-sm-4 control-label">Taluk<sup>*</sup></label>
                                <div class="col-sm-7">
                                    <input type="text" id="taluk" name="Taluk" class="form-control" value="<?php echo $staff->Course_Type; ?>">
                                    <span class="input-group" style="color:red;"><?php echo form_error('Taluk'); ?></span>

                                </div>
                            </div>
                            <div class="row p-3">
                                <label for="City" class="col-sm-4 control-label">City <sup>*</sup></label>
                                <div class="col-sm-7">
                                    <input type="text" id="city" name="City" class="form-control" value="<?php echo $staff->Post_Office_Name; ?>">
                                    <span class="input-group" style="color:red;"><?php echo form_error('City'); ?></span>

                                </div>
                            </div>
                            <div class="row p-3">
                                <label for="Pincode" class="col-sm-4 control-label">Pincode<sup>*</sup></label>
                                <div class="col-sm-7">
                                    <input type="text" id="pincode" name="Pincode" class="form-control" value="<?php echo $staff->postal_Code; ?>">
                                    <span class="input-group" style="color:red;"><?php echo form_error('Pincode'); ?></span>

                                </div>
                            </div>
                            <div class="row p-3">
                                <label for="BankName" class="col-sm-4 control-label">Bank Name<sup>*</sup></label>
                                <div class="col-sm-7">
                                    <input type="text" id="bank_name" name="BankName" class="form-control" value="<?php echo $staff->Bank_name; ?>">
                                    <span class="input-group" style="color:red;"><?php echo form_error('BankName'); ?></span>

                                </div>
                            </div>
                            <div class="row p-3">
                                <label for="AccountNumber" class="col-sm-4 control-label">Account Number<sup>*</sup></label>
                                <div class="col-sm-7">
                                    <input type="text" id="account_no" name="AccountNumber" class="form-control" value="<?php echo $staff->Account_No; ?>">
                                    <span class="input-group" style="color:red;"><?php echo form_error('AccountNumber'); ?></span>

                                </div>
                            </div>
                            <div class="row p-3">
                                <label for="IFSC" class="col-sm-4 control-label">IFSC<sup>*</sup></label>
                                <div class="col-sm-7">
                                    <input type="text" id="ifsc" name="IFSC" class="form-control" value="<?php echo $staff->IFSC; ?>">
                                    <span class="input-group" style="color:red;"><?php echo form_error('IFSC'); ?></span>

                                </div>
                            </div>
                            <div class="row p-3">
                                <label for="MICRNo" class="col-sm-4 control-label">MICR No<sup>*</sup></label>
                                <div class="col-sm-7">
                                    <input type="text" id="micr_no" name="MICRNo" class="form-control" value="<?php echo $staff->MICR_No; ?>">
                                    <span class="input-group" style="color:red;"><?php echo form_error('MICRNo'); ?></span>

                                </div>
                            </div>
                            <div class="row p-3">
                                <label for="Branch" class="col-sm-4 control-label">Branch<sup>*</sup></label>
                                <div class="col-sm-7">
                                    <input type="text" id="branch" name="Branch" class="form-control" value="<?php echo $staff->Branch; ?>">
                                    <span class="input-group" style="color:red;"><?php echo form_error('Branch'); ?></span>

                                </div>
                            </div>
                            <div class="row p-3">
                                <label for="Bank_Address" class="col-sm-4 control-label">Bank Address<sup>*</sup></label>
                                <div class="col-sm-7">
                                    <input type="text" id="Bank_Address" name="Bank_Address" class="form-control" value="<?php echo $staff->Bank_address; ?>">
                                    <span class="input-group" style="color:red;"><?php echo form_error('Bank_Address'); ?></span>

                                </div>
                            </div>
                            <div class="row p-3">
                                <div class="col-md-12 d-flex justify-content-end">
                                    <!-- <a href="<?php echo base_url('Staff/edit'); ?>" class="btn btn-outline-danger btn-sm mr-2">Back</a> -->
                                    <button type="submit" class="btn btn-outline-success btn-sm">Update</button>
                                </div>
                            </div>

                          


                        </div>
                    </div>
                </div>
                <!-- Second Card End -->

                
                <style>
                    .position-relative {
                        justify-content: center;
                        width: 200px;
                        /* Adjust size as needed */
                        height: 200px;
                        /* Adjust size as needed */
                        margin: 0 auto;
                        /* Center the image and overlay icon */
                        border: 4px solid black;
                        border-radius: 100px;
                    }

                    .img-thumbnail {
                        width: 100%;
                        height: 100%;
                        object-fit: cover;
                        /* Ensure the image fills the rounded container */
                        border-radius: 50%;
                        /* Makes the image rounded */
                    }

                    .overlay-icon {
                        position: absolute;
                        top: 0;
                        left: 0;
                        right: 0;
                        bottom: 0;
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        background-color: rgba(255, 255, 255, 0.8);
                        /* Adjust opacity as needed */
                        opacity: 0;
                        /* Initially hidden */
                        transition: opacity 0.3s ease;
                        border-radius: 50%;
                        /* Makes the overlay icon circular */
                    }

                    .position-relative:hover .overlay-icon {
                        opacity: 1;
                        /* Show overlay on hover */
                    }

                    .btn-change-image {
                        color: #007bff;
                        /* Change icon color as needed */
                        font-size: 1.5rem;
                        text-decoration: none;
                        /* Remove underline */
                    }
                </style>


            </div>
        <!-- row end -->
        </form>
    </div>
    <!-- container-p-y end -->
</div>
<!-- content-wrapper end -->
<script>
    <?php if ($this->session->flashdata('success')) : ?>
        Swal.fire({
            icon: 'success',
            title: 'Success!',
            text: '<?php echo $this->session->flashdata('success'); ?>',
        });
    <?php endif; ?>

    <?php if ($this->session->flashdata('error')) : ?>
        Swal.fire({
            icon: 'error',
            title: 'Error!',
            text: '<?php echo $this->session->flashdata('error'); ?>',
        });
    <?php endif; ?>
</script>
</div>
</div>
</div>