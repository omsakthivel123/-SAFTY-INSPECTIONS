<div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="modal-header" style="background-color: #302c63;  display: flex; justify-content: center; ">
                        <h2 style="color: white;font-size: 28px;">Personal Details</h2>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="card">
                                    <div class="card-block">
                                        <div class="row">
                                            <div id="form-wizard21">
                                                <div class="step" id="step-2">
                                                    <!-- row END -->
                                                    <div class="row  py-2">
                                                        <div class="col-md-3">
                                                            <label class="text-dark" for="Titile" class="text-dark">Title</label>
                                                            <input type="text" id="Title" name="Title" class="form-control" value="<?php echo $get[0]->Title; ?>" readonly>
                                                            <span class="input-group" style="color:red;"><?php echo form_error('Titile'); ?></span>

                                                        </div>
                                                        <div class="col-md-3">
                                                            <label class="text-dark" for="gender" class="text-dark">Gender</label>
                                                            <input type="text" id="gender" name="gender" class="form-control" value="<?php echo $get[0]->Gender; ?>" readonly>
                                                            <span class="input-group" style="color:red;"><?php echo form_error('gender'); ?></span>

                                                        </div>
                                                        <div class="col-md-3">
                                                            <label class="text-dark" for="Initial" class="text-dark">Initial</label>
                                                            <input type="text" id="Initial" name="Initial" class="form-control" value="<?php echo $get[0]->Initial; ?>" readonly>
                                                            <span class="input-group" style="color:red;"><?php echo form_error('Initial'); ?></span>

                                                        </div>


                                                        <div class="col-md-3">
                                                            <label class="text-dark" for="Name" class="text-dark">Name</label>
                                                            <input type="text" id="Name" name="Name" class="form-control" value="<?php echo $get[0]->Name; ?>" readonly>
                                                            <span class="input-group" style="color:red;"><?php echo form_error('Name'); ?></span>

                                                        </div>
                                                    </div>
                                                    <!-- row END -->
                                                    <div class="row  py-2">
                                                        <div class="col-md-3">
                                                            <label class="text-dark" for="dob" class="text-dark">DOB</label>
                                                            <input type="text" id="dob" name="dob" class="form-control" value="<?php echo $get[0]->DOB; ?>" readonly>
                                                            <span class="input-group" style="color:red;"><?php echo form_error('dob'); ?></span>

                                                        </div>
                                                        <div class="col-md-3">
                                                            <label class="text-dark" for="bgroup" class="text-dark">Blood Group</label>
                                                            <input type="text" name="bgroup" class="form-control" value="<?php echo $get[0]->Blood_Group; ?>" readonly id="bgroup">
                                                            <span class="input-group" style="color:red;"><?php echo form_error('bgroup'); ?></span>

                                                        </div>


                                                        <div class="col-md-3">
                                                            <label class="text-dark" for="pob" class="text-dark">Place Of Birth</label>
                                                            <input type="text" id="pob" name="pob" class="form-control" value="<?php echo $get[0]->Place_Of_Birth; ?>" readonly>
                                                            <span class="input-group" style="color:red;"><?php echo form_error('pob'); ?></span>

                                                        </div>
                                                        <div class="col-md-3">
                                                            <label class="text-dark" for="Marital_Status" class="text-dark">Marital Status</label>
                                                            <input type="text" name="Marital_Status" class="form-control" value="<?php echo $get[0]->Marital_Status; ?>" readonly id="Marital_Status">
                                                            <span class="input-group" style="color:red;"><?php echo form_error('Marital_Status'); ?></span>

                                                        </div>
                                                    </div>
                                                    <!-- row END -->
                                                    <div class="row  py-2">
                                                        <div class="col-md-3">
                                                            <label class="text-dark" for="Religion" class="text-dark">Religion</label>
                                                            <input type="text" id="Religion" name="Religion" class="form-control" value="<?php echo $get[0]->Religion; ?>" readonly>
                                                            <span class="input-group" style="color:red;"><?php echo form_error('Religion'); ?></span>

                                                        </div>

                                                        <div class="col-md-3">
                                                            <label class="text-dark" for="Physical_Disability" class="text-dark">Physical Disability</label>
                                                            <input type="text" name="Physical_Disability" class="form-control" value="<?php echo $get[0]->Staff_Type; ?>" readonly id="Physical_Disability">
                                                            <span class="input-group" style="color:red;"><?php echo form_error('Staff_Type'); ?></span>

                                                        </div>
                                                        <div class="col-md-3">
                                                            <label class="text-dark" for="Community" class="text-dark">Community</label>
                                                            <input type="text" name="Community" class="form-control" value="<?php echo $get[0]->Community; ?>" readonly id="Community">
                                                            <span class="input-group" style="color:red;"><?php echo form_error('Community'); ?></span>

                                                        </div>

                                                        <div class="col-md-3">
                                                            <label class="text-dark" for="Caste" class="text-dark">Caste</label>
                                                            <input type="text" id="Caste" name="Caste" class="form-control" value="<?php echo $get[0]->Caste; ?>" readonly>
                                                            <span class="input-group" style="color:red;"><?php echo form_error('Caste'); ?></span>

                                                        </div>


                                                        <!-- row END -->
                                                        <div class="row  py-2">
                                                            <div class="col-md-3">
                                                                <label class="text-dark" for="Mobile" class="text-dark">Mobile</label>
                                                                <input type="text" id="Mobile" name="Mobile" class="form-control" value="<?php echo $get[0]->Mobile; ?>" readonly minlength="10" maxlength="10">
                                                                <span class="input-group" style="color:red;"><?php echo form_error('Mobile'); ?></span>

                                                            </div>

                                                            <div class="col-md-3">
                                                                <label class="text-dark" for="Email" class="text-dark">Email Id</label>
                                                                <input type="email" id="Email" name="Email" class="form-control" value="<?php echo $get[0]->Email; ?>" readonly>
                                                                <span class="input-group" style="color:red;"><?php echo form_error('Email'); ?></span>

                                                            </div>
                                                            <div class="col-md-3">
                                                                <label class="text-dark" for="Aadhar_Number" class="text-dark">Aadhar Number</label>
                                                                <input type="text" id="Aadhar_Number" name="Aadhar_Number" pattern="[0-9]{12}" title="Please enter exactly 12 digits." class="form-control" value="<?php echo $get[0]->Aadhar_Number; ?>" readonly minlength="12" maxlength="12">
                                                                <span class="input-group" style="color:red;"><?php echo form_error('Aadhar_Number'); ?></span>

                                                            </div>

                                                            <div class="col-md-3">
                                                                <label class="text-dark" for="Mother_Tongue" class="text-dark">Mother Tongue</label>
                                                                <input type="text" name="Mother_Tongue" class="form-control" value="<?php echo $get[0]->Mother_Tongue; ?>" readonly id="Mother_Tongue">
                                                                <span class="input-group" style="color:red;"><?php echo form_error('Mother_Tongue'); ?></span>

                                                            </div>
                                                        </div>
                                                        <div class="row py-2">
                                                            <div class="col-md-3">
                                                                <label class="text-dark" for="Language" class="text-dark">Language</label>
                                                                <input type="text" name="Language" class="form-control" value="<?php echo $get[0]->Language; ?>" readonly id="Language">
                                                                <span class="input-group" style="color:red;"><?php echo form_error('Language'); ?></span>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    </div>
                    </div>
                    <hr>
                    <br>
                    <div class="col-xxl">
                        <div class="card mb-4">
                            <div class="modal-header" style="background-color: #302c63;  display: flex; justify-content: center;  ">
                                <h2 style="color: white;  font-size: 28px;">Education Details</h2>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="card">
                                            <div class="card-block">
                                                <div class="row">
                                                    <div id="form-wizard21">
                                                        <div class="step" id="step-1">
                                                            <div class="row  py-2">
                                                                <div class="col-md-3">
                                                                    <label for="Course_Type" class="text-dark">Course Type</label>
                                                                    <input type="text" name="Course_Type" class="form-control" value="<?php echo $get[0]->Course_Type; ?>" readonly id="Course_Type">
                                                                    <span class="input-group" style="color:red;"><?php echo form_error('Course_Type'); ?></span>

                                                                </div>
                                                                <div class="col-md-3" id="ug">
                                                                    <label for="UGDegree" class="text-dark">Degree</label>
                                                                    <input type="text" id="UGDegree" name="UGDegree" class="form-control" value="<?php echo $get[0]->Degree; ?>" readonly>
                                                                    <span class="input-group" style="color:red;"><?php echo form_error('UGDegree'); ?></span>
                                                                </div>
                                                                <div class="col-md-3">
                                                                    <label for="Passingyear" class="text-dark">Passing Year</label>
                                                                    <input type="text" name="Passingyear" id="Passingyear" class="form-control" value="<?php echo $get[0]->Passing_Year; ?>" readonly>
                                                                    <span class="input-group" style="color:red;"><?php echo form_error('Passingyear'); ?></span>
                                                                </div>

                                                                <div class="col-md-3">
                                                                    <label for="University_Name" class="text-dark">University Name</label>
                                                                    <input type="text" id="University_Name" name="University_Name" class="form-control" value="<?php echo $get[0]->University_Name; ?>" readonly>
                                                                    <span class="input-group" style="color:red;"><?php echo form_error('University_Name'); ?></span>

                                                                </div>
                                                            </div>
                                                            <div class="row  py-2">
                                                                <div class="col-md-3">
                                                                    <label for="Instiute" class="text-dark">Instiute</label>
                                                                    <input type="text" id="Instiute" name="Instiute" class="form-control" value="<?php echo $get[0]->Instiute; ?>" readonly>
                                                                    <span class="input-group" style="color:red;"><?php echo form_error('Instiute'); ?></span>

                                                                </div>
                                                                <div class="col-md-3">
                                                                    <label for="Mode" class="text-dark">Mode</label>
                                                                    <input type="text" name="CourseMode_Type" class="form-control" value="<?php echo $get[0]->CourseMode_Type; ?>" readonly id="CourseMode_Type">
                                                                    <span class="input-group" style="color:red;"><?php echo form_error('Mode'); ?></span>
                                                                </div>

                                                                <div class="col-md-3">
                                                                    <label for="Percentace" class="text-dark">Percentace</label>
                                                                    <input type="text" id="Percentace" name="Percentace" class="form-control" value="<?php echo $get[0]->Percentace; ?>" readonly>
                                                                    <span class="input-group" style="color:red;"><?php echo form_error('Percentace'); ?></span>

                                                                </div>
                                                                <div class="col-md-3">
                                                                    <label for="Specializations" class="text-dark">Specializations</label>
                                                                    <input type="text" id="	Specializations" name="	Specializations" class="form-control" value="<?php echo $get[0]->Specialization; ?>" readonly>
                                                                    <span class="input-group" style="color:red;"><?php echo form_error('Specializations'); ?></span>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <br>
                    <div class="col-xxl">
                        <div class="card mb-4">
                            <div class="modal-header" style="background-color: #302c63; display: flex; justify-content: center;">
                                <h2 style="color: white;  font-size: 28px;">Bank Details</h2>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="card">
                                            <div class="card-block">
                                                <div class="row">
                                                    <div id="form-wizard21">
                                                        <div class="step" id="step-1">
                                                        <div class="row  py-2">
                                                            <div class="col-md-3">
                                                                <label for="IFSC" class="text-dark">IFSC</label>
                                                                <input type="text" id="IFSC" name="IFSC" class="form-control" value="<?php echo $get[0]->IFSC; ?>" readonly>
                                                                <span class="input-group" style="color:red;"><?php echo form_error('IFSC'); ?></span>

                                                            </div>
                                                            <div class="col-md-3">
                                                                <label for="Bank_name" class="text-dark">Bank Name</label>
                                                                <input type="text" id="Bank_name" name="Bank_name" class="form-control" value="<?php echo $get[0]->Bank_name; ?>" readonly>
                                                                <span class="input-group" style="color:red;"><?php echo form_error('Bank_name'); ?></span>

                                                            </div>
                                                      
                                                            <div class="col-md-3">
                                                                <label for="Bank_address" class="text-dark">Bank Address</label>
                                                                <input type="text" id="Bank_address" name="Bank_address" class="form-control" value="<?php echo $get[0]->Bank_address; ?>" readonly>
                                                                <span class="input-group" style="color:red;"><?php echo form_error('Bank_address'); ?></span>

                                                            </div>
                                                            
                                                            <div class="col-md-3">
                                                                <label for="MICR_No" class="text-dark">MICR No</label>
                                                                <input type="text" id="MICR_No" name="MICR_No" class="form-control" value="<?php echo $get[0]->MICR_No; ?>" readonly>
                                                                <span class="input-group" style="color:red;"><?php echo form_error('MICR_No'); ?></span>

                                                            </div>
                                                            </div>
                                                            <div class="row py-2">
                                                            <div class="col-md-3">
                                                                <label for="Account_No" class="text-dark">Account No</label>
                                                                <input type="text" id="Account_No" name="Account_No" class="form-control" value="<?php echo $get[0]->Account_No; ?>" readonly>
                                                                <span class="input-group" style="color:red;"><?php echo form_error('Account_No'); ?></span>

                                                            </div>
                                                            <div class="col-md-3">
                                                                <label for="PAN_Card" class="text-dark">PAN Card No</label>
                                                                <input type="text" id="PAN_Card" name="PAN_Card" class="form-control" value="<?php echo $get[0]->PAN_Card; ?>" readonly>
                                                                <span class="input-group" style="color:red;"><?php echo form_error('PAN_Card'); ?></span>

                                                            </div>
                                                        </div>
                                                    </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <hr>
                    <br>
                    <div class="col-xxl">
                        <div class="card mb-4">
                            <div class="modal-header" style="background-color: #302c63; display: flex; justify-content: center;">
                                <h2 style="color: white; font-size: 28px;">Permanet Address Details</h2>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="card">
                                            <div class="card-block">
                                                <div class="row">
                                                    <div id="form-wizard21">
                                                        <div class="step" id="step-1">
                                                        <div class="row  py-2">
                                                            <div class="col-md-6">
                                                                <label for="Address" class="text-dark">Address 1</label>
                                                                <input type="text" class="form-control" value="<?php echo $get[0]->Address; ?>" readonly name="Address" id="Address" rows="2">
                                                                <span class="input-group" style="color:red;"><?php echo form_error('Address'); ?></span>

                                                            </div>
                                                            <div class="col-md-6">
                                                                <label for="Address1" class="text-dark">Address 2</label>
                                                                <input type="text" class="form-control" value="<?php echo $get[0]->Address_1; ?>" readonly name="Address1" id="Address1" rows="2">
                                                                <span class="input-group" style="color:red;"><?php echo form_error('Address1'); ?></span>

                                                            </div>
                                                            <div class="col-md-3">
                                                                <label for="postalcode" class="text-dark">Postal Code</label>
                                                                <input type="text" id="postalcode" name="postalcode" class="form-control" value="<?php echo $get[0]->postal_Code; ?>" readonly>
                                                                <span class="input-group" style="color:red;"><?php echo form_error('postalcode'); ?></span>

                                                            </div>
                                                      
                                                            <div class="col-md-3">
                                                                <label for="Postofficename" class="text-dark">Post office Name</label>
                                                                <input type="text" id="Postofficename" name="Postofficename" class="form-control" value="<?php echo $get[0]->Post_Office_Name; ?>" readonly>
                                                                <span class="input-group" style="color:red;"><?php echo form_error('Postofficename'); ?></span>

                                                            </div>
                                                            <div class="col-md-3">
                                                                <label for="District" class="text-dark">District</label>
                                                                <input type="text"  id="District" name="District" class="form-control" value="<?php echo $get[0]->District; ?>" readonly>
                                                                <span class="input-group" style="color:red;"><?php echo form_error('District'); ?></span>

                                                            </div>

                                                        </div>

                                                    </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                </div>
            </div>
        </div>