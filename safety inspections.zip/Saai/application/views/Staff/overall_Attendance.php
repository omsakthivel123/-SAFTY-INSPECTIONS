<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Staff/</span>Staff Attendance</h4>

        <!-- Basic Layout & Basic with Icons -->
        <div class="row">
            <!-- Basic Layout -->
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-12">
                                <!-- Material tab card start -->
                                <div class="card">
                                    <div class="card-block">
                                        <form action="<?php echo base_url('') ?>" method="POST">
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <label for="InstutionName" class="text-dark">Instution Name</label>
                                                    <select name="InstutionName" class="form-control" id="InstutionName" required> </select>

                                                </div>

                                                <!-- <div class="col-md-3">
                                                    <label for="Department_attendance" class="text-dark">Department</label>
                                                    <select name="Department_attendance" class="form-control" id="Department_attendance" required> </select>
                                                    <input type="hidden" name='InstutionCode' id="InstutionCode">
                                                    <input type="hidden" name='Instution_Name' id="Instution_Name">
                                                    <input type="hidden" name='DepartmentCode' id="DepartmentCode">
                                                </div> -->
                                                <div class="col-md-3">
                                                    <label for="Staff_Types" class="text-dark">Staff Type</label>
                                                    <select name="Staff_Types" class="form-control" id="Staff_Types">
                                                        <option value="Select Staff Type">Select Staff Type</option>
                                                        <option value="Teaching">Teaching</option>
                                                        <option value="Non_Teaching">Non Teaching</option>
                                                    </select>
                                                    <span class="input-group" style="color:red;"><?php echo form_error('Staff_Type'); ?></span>

                                                </div>
                                                <div class="col-md-3">
                                                    <label for="FinYear" class="text-dark">Passing Year</label>
                                                    <select name="FinYear" id="FinYear" class="form-control">
                                                        <?php
                                                        $current_year = date("Y");
                                                        $start_year = 1950;

                                                        for ($year = $current_year; $year >= $start_year; $year--) {
                                                            echo '<option value="' . $year . '">' . $year . '</option>';
                                                        }
                                                        ?>
                                                    </select>
                                                    <span class="input-group" style="color:red;"><?php echo form_error('Passingyear'); ?></span>

                                                </div>
                                                <div class="col-md-3">
                                                    <label for="Staff_Type" class="text-dark">Month</label>

                                                    <select class="form-control" id="Month" name="month">
                                                        <option value="">Select Month</option>
                                                        <?php
                                                        $months = array(
                                                            'January', 'February', 'March', 'April',
                                                            'May', 'June', 'July', 'August',
                                                            'September', 'October', 'November', 'December'
                                                        );

                                                        foreach ($months as $month) {
                                                            echo '<option value="' . $month . '"';
                                                            echo set_select('month', $month);
                                                            echo '>' . $month . '</option>';
                                                        }
                                                        ?>
                                                    </select>
                                                    <?php echo form_error('month', '<span class="text-danger">', '</span>'); ?>
                                                </div>

                                            </div>
                                            <div class="row justify-content-end py-3">
                                                <div class="col-auto">
                                                    <button type="button" class="btn btn-outline-warning btn-sm" id="get_month_details">view</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>

                                    <!-- Row start -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card mb-4">
                    <div class="card-body" id="">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="card">
                                    <div class="card-block">
                                        <div class="table-responsive">
                                            <table id="" class="table">
                                                <thead style="background-color: #302c63;">
                                                    <tr>
                                                        <th style="color: white;" >S.No.</th>
                                                        <th style="color: white;">Staff ID</th>
                                                        <th style="color: white;">Name</th>
                                                        <th style="color: white;">Department</th>
                                                        <th style="color: white;" >Staff Type</th>
                                                        <th style="color: white;" >Total Permission</th>
                                                        <th style="color: white;" >Total OD</th>
                                                        <th style="color: white;" >Total Late</th>
                                                        <th style="color: white;" >Total Present</th>
                                                        <th style="color: white;" >Total Absent</th>
                                                        <th style="color: white;" >Day 1</th>
                                                        <th style="color: white;" >Day 2</th>
                                                        <th style="color: white;" >Day 3</th>
                                                        <th style="color: white;" >Day 4</th>
                                                        <th style="color: white;" >Day 5</th>
                                                        <th style="color: white;" >Day 6</th>
                                                        <th style="color: white;" >Day 7</th>
                                                        <th style="color: white;" >Day 8</th>
                                                        <th style="color: white;" >Day 9</th>
                                                        <th style="color: white;" >Day 10</th>
                                                        <th style="color: white;" >Day 11</th>
                                                        <th style="color: white;" >Day 12</th>
                                                        <th style="color: white;" >Day 13</th>
                                                        <th style="color: white;" >Day 14</th>
                                                        <th style="color: white;" >Day 15</th>
                                                        <th style="color: white;" >Day 16</th>
                                                        <th style="color: white;" >Day 17</th>
                                                        <th style="color: white;" >Day 18</th>
                                                        <th style="color: white;" >Day 19</th>
                                                        <th style="color: white;" >Day 20</th>
                                                        <th style="color: white;" >Day 21</th>
                                                        <th style="color: white;" >Day 22</th>
                                                        <th style="color: white;" >Day 23</th>
                                                        <th style="color: white;" >Day 24</th>
                                                        <th style="color: white;" >Day 25</th>
                                                        <th style="color: white;" >Day 26</th>
                                                        <th style="color: white;" >Day 27</th>
                                                        <th style="color: white;" >Day 28</th>
                                                        <th style="color: white;" >Day 29</th>
                                                        <th style="color: white;" >Day 30</th>
                                                        <th style="color: white;" >Day 31</th>
                                                    </tr>

                                                </thead>
                                                <tbody id="month_attendance">

                                                </tbody>
                                            </table>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>