<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Staff/</span>Monthly Attendance</h4>

        <!-- Basic Layout & Basic with Icons -->
        <div class="row">
            <!-- Basic Layout -->
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-12">
                                <!-- Material tab card start -->
                                <div class="card">
                                    <div class="card-block">
                                        <form action="<?php echo base_url('') ?>" method="POST">
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <label for="FinYear" class="text-dark">Year</label>
                                                    <input type="hidden" name="Staff_id" id="Staff_id" value="<?php echo $profile['Id']; ?>">

                                                    <select name="FinYear" id="FinYear" class="form-control">
                                                        <?php
                                                        $current_year = date("Y");
                                                        $start_year = 1950;

                                                        for ($year = $current_year; $year >= $start_year; $year--) {
                                                            echo '<option value="' . $year . '">' . $year . '</option>';
                                                        }
                                                        ?>
                                                    </select>
                                                    <span class="input-group" style="color:red;"><?php echo form_error('Passingyear'); ?></span>

                                                </div>
                                                <div class="col-md-3">
                                                    <label for="Month" class="text-dark">Month</label>

                                                    <select class="form-control" id="Month" name="month">
                                                        <option value="">Select Month</option>
                                                        <?php
                                                        $months = array(
                                                            'January', 'February', 'March', 'April',
                                                            'May', 'June', 'July', 'August',
                                                            'September', 'October', 'November', 'December'
                                                        );

                                                        foreach ($months as $month) {
                                                            echo '<option value="' . $month . '"';
                                                            echo set_select('month', $month);
                                                            echo '>' . $month . '</option>';
                                                        }
                                                        ?>
                                                    </select>
                                                    <?php echo form_error('month', '<span class="text-danger">', '</span>'); ?>
                                                </div>

                                            </div>
                                            <div class="row justify-content-end py-3">
                                                <div class="col-auto">
                                                    <button type="button" class="btn btn-outline-warning btn-sm" id="month_attendance">view</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>

                                    <!-- Row start -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
<style>
                                                .box{
                                                    height: 100px;
                                                    background-color: #ffffff;
                                                    border: 1px solid #dddddd;
                                                    border-radius: 4px;
                                                    text-align: center;
                                                    padding: 10px;
                                                    margin-bottom: 10px;
                                                    /* Add box shadow */
                                                    box-shadow: 5px 5px 10px rgba(0, 0, 0, 0.1); /* 5px offset in both x and y directions */
                                                }
                                                .box1{
                                                    width: 250px;
                                                    background-color: #ffffff;
                                                    border: 1px solid #dddddd;
                                                    border-radius: 4px;
                                                    text-align: center;
                                                    padding: 10px;
                                                    margin-bottom: 10px;
                                                }




    

                                            </style>
                <div class="card mb-4">
                    <div class="card-body" id="calendarBody">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="card">
                                    <div class="card-block">
                                        <div class="table-responsive">
                                            <table class="table table-bordered" style="width: 50px; height: 50px;">
                                                <thead>
                                                    <tr>
                                                        <th colspan="7" class="text-center" >
                                                            <H3 id="Month_Year" style="font-weight: bold; "></H3>
                                                        </th>
                                                        <th colspan="1" class="text-center">
                                                            <h3 style="font-weight: bold;">Month Details</h3>
                                                        </th>
                                                    </tr>
                                                    <tr class="text-center" style="background-color: #302c63; color: white;">

                                                        <th style="background-color: #302c63; color: white;">Mon</th>
                                                        <th style="background-color: #302c63; color: white;">Tue</th>
                                                        <th style="background-color: #302c63; color: white;">Wed</th>
                                                        <th style="background-color: #302c63; color: white;">Thu</th>
                                                        <th style="background-color: #302c63; color: white;">Fri</th>
                                                        <th style="background-color: #302c63; color: white;">Sat</th>
                                                        <th style="background-color: #302c63; color: white;">Sun</th>
                                                        <th style="background-color: #302c63; color: white;" id="Month_details"></th> <!-- Empty header for the new column -->
                                                    </tr>
                                                </thead>
                                                <tbody id="calendarBody">
                                                    <tr >
                                                        <!-- July 1st (Sunday) to July 7th (Saturday) -->
                                                        <td>  <div class="box" id="DAY_1" style="width: 80px; height: 80px"></div></td>
                                                        <td>  <div class="box" id="DAY_2" style="width: 80px; height: 80px"></div></td>
                                                        <td> <div class="box" id="DAY_3" style="width: 80px; height: 80px"></div></td>
                                                        <td> <div class="box" id="DAY_4" style="width: 80px; height: 80px"></div></td>
                                                        <td ><div class="box" id="DAY_5" style="width: 80px; height: 80px"></div></td>
                                                        <td ><div class="box" id="DAY_6" style="width: 80px; height: 80px"></div></td>
                                                        <td ><div class="box" id="DAY_7" style="width: 80px; height: 80px"></div></td>
                                                        <td rowspan="5">
                                                            <!-- Leave details input for the entire month -->
                                                            <div class="container">
                                                                <div class="row">
                                                                    <div class="col-md-6">
                                                                        <div class="box1"><h5>Total Present</h5>
                                                                            <h5 style="margin-top: 10px;" id="Present" >0</h5>
                                                                        </div>
                                                                        
                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <div class="col-md-6">
                                                                        <div class="box1">
                                                                        <h5>Total Absent</h5>
                                                                         <h5 style="margin-top: 10px;" id="Absent" >0</h5>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <div class="col-md-6">
                                                                        <div class="box1">
                                                                            <h5>Total W/O</h5>
                                                                             <h5 style="margin-top: 10px;" id="Weekoff" >0</h5>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <div class="col-md-6">
                                                                        <div class="box1">
                                                                            <h5>Toatl Permission</h5>
                                                                                <h5 style="margin-top: 10px;" id="Permission" >Hrs</h5>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                               
                                                                </div>
                                                            <!-- </di   v> -->
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td> <div class="box" id="DAY_8" style="width: 80px; height: 80px"></div></td>
                                                        <td> <div class="box" id="DAY_9" style="width: 80px; height: 80px"></div></td>
                                                        <td ><div class="box" id="DAY_10" style="width: 80px; height: 80px"></div></td>
                                                        <td ><div class="box" id="DAY_11" style="width: 80px; height: 80px"></div></td>
                                                        <td ><div class="box" id="DAY_12" style="width: 80px; height: 80px"></div></td>
                                                        <td ><div class="box" id="DAY_13" style="width: 80px; height: 80px"></div></td>
                                                        <td ><div class="box" id="DAY_14" style="width: 80px; height: 80px"></div></td>
                                                    </tr>
                                                    <tr>
                                                        <td ><div class="box" id="DAY_15" style="width: 80px; height: 80px"></div></td>
                                                        <td ><div class="box" id="DAY_16" style="width: 80px; height: 80px"></div></td>
                                                        <td ><div class="box" id="DAY_17" style="width: 80px; height: 80px"></div></td>
                                                        <td ><div class="box" id="DAY_18" style="width: 80px; height: 80px"></div></td>
                                                        <td ><div class="box" id="DAY_19" style="width: 80px; height: 80px"></div></td>
                                                        <td ><div class="box" id="DAY_20" style="width: 80px; height: 80px"></div></td>
                                                        <td ><div class="box" id="DAY_21" style="width: 80px; height: 80px"></div></td>
                                                    </tr>
                                                    <tr>
                                                        <td ><div class="box" id="DAY_22" style="width: 80px; height: 80px"></div></td>
                                                        <td ><div class="box" id="DAY_23" style="width: 80px; height: 80px"></div></td>
                                                        <td ><div class="box" id="DAY_24" style="width: 80px; height: 80px"></div></td>
                                                        <td ><div class="box" id="DAY_25" style="width: 80px; height: 80px"></div></td>
                                                        <td ><div class="box" id="DAY_26" style="width: 80px; height: 80px"></div></td>
                                                        <td ><div class="box" id="DAY_27" style="width: 80px; height: 80px"></div></td>
                                                        <td ><div class="box" id="DAY_28" style="width: 80px; height: 80px"></div></td>
                                                    </tr>
                                                    <tr>
                                                        <td ><div class="box" id="DAY_29" style="width: 80px; height: 80px"></div></td>
                                                        <td ><div class="box" id="DAY_30" style="width: 80px; height: 80px"></div></td>
                                                        <td ><div class="box" id="DAY_31" style="width: 80px; height: 80px"></div></td>
                                                    </tr>
                                                </tbody>

                                            </table>

                                            


                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

    </div>