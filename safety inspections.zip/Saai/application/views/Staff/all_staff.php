<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Staff/</span>Staff List</h4>

        <!-- Basic Layout & Basic with Icons -->
        <div class="row">
            <!-- Basic Layout -->
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-12">
                                <!-- Material tab card start -->
                                <div class="card">
                                    <div class="card-block">
                                        <form action="<?php echo base_url('') ?>" method="POST">
                                            <div class="row py-3">
                                                <div class="col-md-3">
                                                    <label for="InstutionName" class="text-dark">Instution</label>
                                                    <select name="InstutionName" class="form-control" id="InstutionName" required> </select>

                                                </div>
                                                <div class="col-md-3">
                                                    <label for="Staff_Type" class="text-dark">Staff Type</label>
                                                    <select name="Staff_Type" class="form-control" id="Staff_Type">
                                                        <option value="Select">Select Staff Type</option>
                                                        <option value="Teaching">Teaching</option>
                                                        <option value="Non-Teaching">Non-Teaching</option>
                                                    </select>

                                                    <span class="input-group" style="color:red;"><?php echo form_error('Staff_Type'); ?></span>
                                                </div>


                                            </div>

                                            <div class="row justify-content-end py-3">
                                                <div class="col-auto">
                                                    <button type="button" class="btn btn-outline-warning btn-sm" id="get_staff_list">view</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>

                                    <!-- Row start -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <div class="card mb-4" id="Staff_list">
                <div class="card-body">
                    <div class="row">
                        <div id="course_mentor">
                            <div id="table-container" style="overflow-x: auto;">
                                <table id="Staff_list" class="table table-striped">
                                    <thead style="background-color: #302c63; color: white;">
                                        <tr>
                                            <th style="color: white;">S.No</th>
                                            <th style="color: white;">Department</th>
                                            <th style="color: white;">Staff Id</th>
                                            <th style="color: white;">Staff Name</th>
                                            <th style="color: white;">Staff Type</th>
                                            <th style="color: white;">Position</th>
                                            <td style="color: white;">Mobile</td>
                                            <td style="color: white;">Action</td>

                                        </tr>
                                    </thead>
                                    <tbody id="Staff_list_rows">



                                    </tbody>
                                </table>

                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <div class="modal fade bd-example-modal-lg" id="staff_view_modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-xl"> <!-- Increased the modal size -->
                    <div class="modal-content">
                        <div class="modal-header bg-info">
                            <h5 class="modal-title" id="exampleModalLongTitle" style="color: white; text-align: center;">View User</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close" id="close_pop">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="container">
                                <div class="row">
                                    <!-- First Section -->
                                    <div class="col-md-4">
                                        <div class="row p-1">
                                            <label for="view_staff_id" class="col-sm-4 control-label">Staff Id<sup>*</sup></label>
                                            <div class="col-sm-8">
                                                <input type="text" placeholder="" name="view_staff_id" id="view_staff_id" class="form-control">
                                            </div>
                                        </div>
                                        <div class="row p-1">
                                            <label for="Staff_name" class="col-sm-4 control-label">Staff Name<sup>*</sup></label>
                                            <div class="col-sm-8">
                                                <input type="text" placeholder="" name="view_name" id="view_name" class="form-control">
                                            </div>
                                        </div>
                                        <div class="row p-1">
                                            <label for="view_staff_type" class="col-sm-4 control-label">Staff Type<sup>*</sup></label>
                                            <div class="col-sm-8">
                                                <input type="text" placeholder="" name="view_staff_type" id="view_staff_type" class="form-control">
                                            </div>
                                        </div>
                                        <div class="row p-1">
                                            <label for="view_position" class="col-sm-4 control-label">Position<sup>*</sup></label>
                                            <div class="col-sm-8">
                                                <input type="text" placeholder="" name="view_position" id="view_position" class="form-control">
                                            </div>
                                        </div>
                                        <div class="row p-1">
                                            <label for="view_mobile" class="col-sm-4 control-label">Mobile<sup>*</sup></label>
                                            <div class="col-sm-8">
                                                <input type="text" placeholder="" name="view_mobile" id="view_mobile" class="form-control">
                                            </div>
                                        </div>
                                        <div class="row p-1">
                                            <label for="view_email" class="col-sm-4 control-label">Email<sup>*</sup></label>
                                            <div class="col-sm-8">
                                                <input type="text" placeholder="" name="view_email" id="view_email" class="form-control">
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Second Section -->
                                    <div class="col-md-4">
                                        <div class="row p-1">
                                            <label for="view_DOB" class="col-sm-4 control-label">DOB<sup>*</sup></label>
                                            <div class="col-sm-8">
                                                <input type="text" placeholder="" name="view_DOB" id="view_DOB" class="form-control">
                                            </div>
                                        </div>
                                        <div class="row p-1">
                                            <label for="Aadhar_Number" class="col-sm-4 control-label">Aadhar No<sup>*</sup></label>
                                            <div class="col-sm-8">
                                                <input type="text" placeholder="" name="Aadhar_Number" id="Aadhar_Number" class="form-control">
                                            </div>
                                        </div>
                                        <div class="row p-1">
                                            <label for="view_Blood_Group" class="col-sm-4 control-label">Blood Group<sup>*</sup></label>
                                            <div class="col-sm-8">
                                                <input type="text" placeholder="" name="view_Blood_Group" id="view_Blood_Group" class="form-control">
                                            </div>
                                        </div>
                                        <div class="row p-1">
                                            <label for="view_department" class="col-sm-4 control-label">Department<sup>*</sup></label>
                                            <div class="col-sm-8">
                                                <input type="text" placeholder="" name="view_department" id="view_department" class="form-control">
                                            </div>
                                        </div>
                                        <div class="row p-1">
                                            <label for="view_address" class="col-sm-4 control-label">Address<sup>*</sup></label>
                                            <div class="col-sm-8">
                                                <input type="text" placeholder="" name="view_address" id="view_address" class="form-control">
                                            </div>
                                        </div>
                                        <div class="row p-1">
                                            <label for="view_Marital_Status" class="col-sm-4 control-label">Marital Status<sup>*</sup></label>
                                            <div class="col-sm-8">
                                                <input type="text" placeholder="" name="view_Marital_Status" id="view_Marital_Status" class="form-control">
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Image Section -->
                                    <div class="col-md-4">
                                        <div class="row p-1 d-flex justify-content-center align-items-center" style="height: 100%;">
                                            <img src="" alt="Staff Image" id="view_image" height="250px" width="100px" class="img">
                                        </div>
                                    </div>


                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <!---edit pop model End--->
        </div>
    </div>
</div>