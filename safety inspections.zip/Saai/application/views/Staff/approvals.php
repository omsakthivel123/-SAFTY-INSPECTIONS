<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Staff/</span>Approvals</h4>

        <!-- Basic Layout & Basic with Icons -->
        <div class="row">
            <!-- Basic Layout -->
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-12">
                                <!-- Material tab card start -->
                                <div class="card">
                                    <div class="card-block">
                                        <form action="<?php echo base_url('') ?>" method="POST">
                                            <div class="row py-3">
                                                <div class="col-md-3">
                                                    <label for="InstutionName" class="text-dark">Instution Name</label>
                                                    <select name="InstutionName" class="form-control" id="InstutionName" required> </select>

                                                </div>

                                                <div class="col-md-3">
                                                    <label for="Department_attendance" class="text-dark">Department</label>
                                                    <select name="Department_attendance" class="form-control" id="Department_attendance" required> </select>

                                                </div>
                                                <div class="col-md-3">
                                                    <label for="Staff_Type" class="text-dark">Staff Type</label>
                                                    <select name="Staff_Type" class="form-control" id="Staff_Type">
                                                        <option value="Select">Select Staff Type</option>
                                                        <option value="Teaching">Teaching</option>
                                                        <option value="Non-Teaching">Non-Teaching</option>
                                                    </select>

                                                    <span class="input-group" style="color:red;"><?php echo form_error('Staff_Type'); ?></span>
                                                </div>

                                                <div class="col-md-3">
                                                    <label for="Staff_Type" class="text-dark">Month</label>

                                                    <select class="form-control" id="Month" name="month">
                                                        <option value="">Select Month</option>
                                                        <?php
                                                        $months = array(
                                                            'January', 'February', 'March', 'April',
                                                            'May', 'June', 'July', 'August',
                                                            'September', 'October', 'November', 'December'
                                                        );

                                                        foreach ($months as $month) {
                                                            echo '<option value="' . $month . '"';
                                                            echo set_select('month', $month);
                                                            echo '>' . $month . '</option>';
                                                        }
                                                        ?>
                                                    </select>
                                                    <?php echo form_error('month', '<span class="text-danger">', '</span>'); ?>
                                                </div>

                                            </div>

                                            <div class="row justify-content-end py-3">
                                                <div class="col-auto">
                                                    <button type="button" class="btn btn-outline-warning btn-sm" id="get_request">view</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>

                                    <!-- Row start -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- <style>
                        .approval-status {
        padding: 5px 10px; /* Adjust padding as needed */
        font-weight: bold; /* Make text bold */
        text-align: center; /* Center align text */
    }

    .not-approved {
        background-color: red; /* Red background for not approved */
        color: white; /* White text color */
    }

    .approved {
        background-color: green; /* Green background for approved */
        color: white; /* White text color */
    }

</style>
 -->

            </div>

            <div class="card mb-4" id="approval_staff">
                <div class="card-body">
                    <div class="row">
                        <div id="course_mentor">
                            <div id="table-container" style="overflow-x: auto;">
                                <table id="Staff_Approvals" class="table table-striped">
                                    <thead style="background-color: #302c63; color: white;">
                                        <tr>
                                            <th style="color: white;">S.No</th>
                                            <th style="color: white;">Instution Name</th>
                                            <th style="color: white;">Department</th>
                                            <th style="color: white;">Staff Type</th>
                                            <th style="color: white;">Staff Id</th>
                                            <th style="color: white;">Staff Name</th>
                                            <th style="color: white;">Leave Type</th>
                                            <th style="color: white;">Discription</th>
                                            <td style="color: white;">Month</td>
                                            <td style="color: white;">Apply_date</td>
                                            <td style="color: white;">PermissionDate</td>
                                            <th style="color: white;">From Date</th>
                                            <th style="color: white;">To Date</th>
                                            <th style="color: white;">From Time</th>
                                            <th style="color: white;">To Time</th>
                                            <th style="color: white;">Approval_Status</th>
                                            <th style="color: white;">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody id="approval_rows">



                                    </tbody>
                                </table>

                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>