<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Exam Module/</span>Exam Schedule</h4>
       
        <div class="row">

            <!-- Basic Layout -->
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-body">

                        <div class="row">
                            <div class="col-sm-12">
                                <!-- Material tab card start -->
                                <div class="card">
                                    <div class="card-block">

                                        <div class="row py-3">

                                            <div class="col-md-3">
                                                <label for="InstutionName" class="text-dark"> Instution</label>
                                                <select name="InstutionName" class="form-control" id="InstutionName"></select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('InstutionName'); ?></span>

                                            </div>
                                            <div class="col-md-3">
                                                <label for="Course_type" class="text-dark">Course Type</label>
                                                <select name="Course_type" class="form-control" id="Course_type"></select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('Course_type'); ?></span>

                                            </div>
                                            <div class="col-md-3">
                                                <label for="DepartmentName" class="text-dark">Department</label>
                                                <select name="DepartmentName" class="form-control" id="DepartmentName"> </select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('DepartmentName'); ?></span>

                                            </div>
                                            <div class="col-md-3">
                                                <label for="Course_name" class="text-dark">Course Name</label>
                                                <select name="Course_name" class="form-control" id="Course_name"> </select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('Course_name'); ?></span>

                                            </div>


                                        </div>
                                        <div class="row">

                                            <div class="col-md-3">
                                                <label for="Batch" class="text-dark">Batch</label>
                                                <select name="Batch" class="form-control" id="Batch"> </select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('Batch'); ?></span>

                                            </div>

                                            <div class="col-md-3">
                                                <label for="ExamCategory" class="text-dark">Exam Category</label>
                                                <select name="ExamCategory" class="form-control" id="ExamCategory"> 
                                                    <option value="">Select Exam Category</option>
                                                    <option value="Internal I">Internal I</option>
                                                    <option value="Internal II">Internal II</option>
                                                    <option value="Internal III">Internal III</option>
                                                    <option value="Model"> Model</option>
                                                </select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('ExamCategory'); ?></span>

                                            </div>

                                            <div class="col-md-3">
                                                <label for="Semesters" class="text-dark">Semester</label>
                                                <select name="Semesters" class="form-control" id="Semesters"> </select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('Semesters'); ?></span>

                                            </div>                                       
                                        </div>
                                    </div>
                                </div>
                                <!-- Row start -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div>


                <!-- row complete for box   -->

                <div class="card mb-4" id="exam-coordinating">
                    <div class="card-body">
                        <div class="row">
                            <div id="Exam-panner">
                                <div id="table-container" style="overflow-x: auto;">
                                    <table id="exam-planning" class="table table-resposive">
                                        <thead style="background-color: #302c63; color: white;">
                                            <tr>
                                                <th style="color: white;">S.No</th>
                                                <th style="color: white;">Subject Name</th>
                                                <th style="color: white;">Exam Date</th>
                                                <th style="color: white;">Session</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>

                                        </tbody>
                                    </table>

                                </div>
                                <div class="row justify-content-end py-3" id="view-btn">
                                        <div class="col-auto">
                                            <button type="button" class="btn btn-outline-info btn-sm" id="update_exam_sechedule">Update</button>
                                        </div>
                                    </div>
                            </div>

                            


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>