<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Subject Module/</span>Add Subject</h4>


        <div class="row">

            <!-- Basic Layout -->
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-body">

                        <div class="row">
                            <div class="col-sm-12">
                                <!-- Material tab card start -->
                                <div class="card">
                                    <div class="card-block">
                                        <form action="<?php echo base_url('Subject/update') ?>" method="POST">

                                            <div class="row py-3">

                                                <div class="col-md-3">
                                                    <label for="InstutionName" class="text-dark"> Instution</label>
                                                    <select name="InstutionName" class="form-control" id="InstutionName"></select>
                                                    <span class="input-group" style="color:red;"><?php echo form_error('InstutionName'); ?></span>

                                                </div>
                                                <div class="col-md-3">
                                                    <label for="Course_type" class="text-dark">Course Type</label>
                                                    <select name="Course_type" class="form-control" id="Course_type"></select>
                                                    <span class="input-group" style="color:red;"><?php echo form_error('Course_type'); ?></span>

                                                </div>
                                                <div class="col-md-3">
                                                    <label for="DepartmentName" class="text-dark">Department</label>
                                                    <select name="DepartmentName" class="form-control" id="DepartmentName"> </select>
                                                    <span class="input-group" style="color:red;"><?php echo form_error('DepartmentName'); ?></span>

                                                </div>
                                                <div class="col-md-3">
                                                    <label for="Course_name" class="text-dark">Course Name</label>
                                                    <select name="Course_name" class="form-control" id="Course_name"> </select>
                                                    <span class="input-group" style="color:red;"><?php echo form_error('Course_name'); ?></span>

                                                </div>


                                            </div>
                                            <div class="row">

                                                <div class="col-md-3">
                                                    <label for="Batch" class="text-dark">Batch</label>
                                                    <select name="Batch" class="form-control" id="Batch"> </select>
                                                    <span class="input-group" style="color:red;"><?php echo form_error('Batch'); ?></span>

                                                </div>

                                                <div class="col-md-3">
                                                    <label for="Semesters" class="text-dark">Semester</label>
                                                    <select name="Semesters" class="form-control" id="Semesters"> </select>
                                                    <span class="input-group" style="color:red;"><?php echo form_error('Semesters'); ?></span>

                                                </div>
                                                <div class="col-md-3">
                                                    <label for="Subject_code" class="text-dark">Subject Code</label>
                                                    <select name="Subject_code" class="form-control" id="Subject_code"> </select>
                                                    <span class="input-group" style="color:red;"><?php echo form_error('Subject_code'); ?></span>

                                                </div>
                                                <div class="col-md-3">
                                                    <label for="Subject_name" class="text-dark">Subject Name</label>
                                                    <select name="Subject_name" class="form-control" id="Subject_name"> </select>
                                                    <span class="input-group" style="color:red;"><?php echo form_error('Subject_name'); ?></span>

                                                </div>
                                            </div>
                                            <div class="row py-3">

                                                <div class="col-md-3">
                                                    <label for="Category" class="text-dark">Category</label>
                                                    <select name="Category" class="form-control" id="Category">
                                                        <option value="">Select Category </option>
                                                        <option value="Soft Skills">Soft Skills</option>
                                                        <option value="Core">Core</option>
                                                    </select>
                                                    <span class="input-group" style="color:red;"><?php echo form_error('Category'); ?></span>

                                                </div>
                                                <div class="col-md-3">
                                                    <label for="Credits" class="text-dark">Credits</label>
                                                    <select name="Credits" class="form-control" id="Credits">
                                                        <option value="">Select Credits</option>
                                                        <option value="01">01</option>
                                                        <option value="02">02</option>
                                                        <option value="03">03</option>
                                                        <option value="04">04</option>
                                                        <option value="05">05</option>
                                                        <option value="06">06</option>
                                                        <option value="07">07</option>
                                                        <option value="08">08</option>
                                                        <option value="09">09</option>
                                                        <option value="10">10</option>
                                                    </select>
                                                    <span class="input-group" style="color:red;"><?php echo form_error('Credits'); ?></span>

                                                </div>

                                                <div class="col-md-3">
                                                    <label for="Qualifying_Grade" class="text-dark">Qualifying Grade</label>
                                                    <select name="Qualifying_Grade" class="form-control" id="Qualifying_Grade">
                                                        <option value="">Select a grade</option>
                                                        <option value="10">10</option>
                                                        <option value="20">20</option>
                                                        <option value="30">30</option>
                                                        <option value="40">40</option>
                                                        <option value="50">50</option>
                                                        <option value="60">60</option>
                                                        <option value="70">70</option>
                                                        <option value="80">80</option>
                                                        <option value="90">90</option>
                                                        <option value="100">100</option>
                                                    </select>
                                                    <span class="input-group" style="color:red;"><?php echo form_error('Qualifying_Grade'); ?></span>

                                                </div>

                                            </div>
                                            <div class="row justify-content-end py-3" id="view-btn">
                                                <div class="col-auto">
                                                    <button type="Submit" class="btn btn-outline-danger btn-sm" id="get_subject_assing">Save</button>
                                                </div>
                                            </div>

                                        </form>

                                    </div>


                                    <script>
                                        // Function to handle flash messages with SweetAlert
                                        function handleFlashMessages() {
                                            <?php if ($this->session->flashdata('success')) : ?>
                                                Swal.fire({
                                                    icon: 'success',
                                                    title: 'Success!',
                                                    text: '<?php echo $this->session->flashdata('success'); ?>',
                                                });
                                            <?php elseif ($this->session->flashdata('category_error')) : ?>
                                                // Display SweetAlert with the flashdata message
                                                Swal.fire({
                                                    icon: 'error',
                                                    title: 'Oops...',
                                                    text: '<?php echo $this->session->flashdata("category_error"); ?>'
                                                });
                                            <?php endif; ?>
                                        }

                                        // Call the function when the page loads
                                        window.onload = function() {
                                            handleFlashMessages();
                                        };
                                    </script>

                                    <!-- Row start -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div>


                    <!-- row complete for box   -->

                </div>
            </div>
        </div>

    </div>