<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Subject/</span>Subject Report</h4>
        <!-- Basic Layout & Basic with Icons -->
        

        <div class="row">
            <!-- Basic Layout -->
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-12">
                                <!-- Material tab card start -->
                                <div class="card">
                                    <div class="card-block">
                                    <h2 style="display: flex; justify-content: center; font-size: 23px;">Subject Reports</h2>
                                        <div class="row py-3">
                                            <div class="col-md-3">
                                                <label for="InstutionName" class="text-dark">Instution</label>
                                                <select name="InstutionName" class="form-control" id="InstutionName"></select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('InstutionName'); ?></span>
                                            </div>
                                            <div class="col-md-3">
                                                <label for="Course_type" class="text-dark">Course Type</label>
                                                <select name="Course_type" class="form-control" id="Course_type"></select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('Course_type'); ?></span>
                                            </div>
                                            <div class="col-md-3">
                                                <label for="DepartmentName" class="text-dark">Department</label>
                                                <select name="DepartmentName" class="form-control" id="DepartmentName"></select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('DepartmentName'); ?></span>
                                            </div>
                                            <div class="col-md-3">
                                                <label for="Course_name" class="text-dark">Course Name</label>
                                                <select name="Course_name" class="form-control" id="Course_name"></select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('Course_name'); ?></span>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-3">
                                                <label for="Batch" class="text-dark">Batch</label>
                                                <select name="Batch" class="form-control" id="Batch"></select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('Batch'); ?></span>
                                            </div>
                                            <div class="col-md-3">
                                                <label for="Semesters" class="text-dark">Semester</label>
                                                <select name="Semesters" class="form-control" id="Semesters"></select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('Semesters'); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row justify-content-end py-3" id="view-btn">
                                        <div class="col-auto">
                                            <button type="button" class="btn btn-outline-danger btn-sm" id="get_subjects_for_assign">View</button>
                                        </div>
                                    </div>
                                </div>
                                <!-- Row start -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Hidden form for submission -->
            <form action="<?php echo base_url('Downloader/subject')?>" method="post" style="display: none;" id="download-form">
                <input type="text" name="InstutionName" id="data1">
                <input type="text" name="Course_type" id="data2">
                <input type="text" name="DepartmentName" id="data3">
                <input type="text" name="Course_name" id="data4">
                <input type="text" name="Batch" id="data5">
                <input type="text" name="Semesters" id="data6">
            </form>

            <div class="card mb-4" id="subject">
                <div class="card-body">
                    <div class="row">
                        <div id="subject_report">
                            <div id="table-container" style="overflow-x: auto;">
                                <div class="d-flex justify-content-end mb-3">
                                    <button id="download-button" class="btn btn-danger">Download Report</button>
                                </div>
                                <table id="sheet" class="table table-striped">
                                    <thead style="background-color: #302c63; color: white;">
                                        <tr>
                                            <th>S.No</th>
                                            <th>Instution Name</th>
                                            <th>Course Type</th>
                                            <th>Department</th>
                                            <th>Course Name</th>
                                            <th>Batch</th>
                                            <th>Semester</th>
                                            <th>Subject Code</th>
                                            <th>Subject Name</th>
                                            <th>Category</th>
                                            <th>Credits</th>
                                            <th>QualifyingGrade</th>
                                            <th>Created By</th>
                                        </tr>
                                    </thead>
                                    <tbody id="assign_subject_list"></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<script>
    $(document).ready(function(){
        $('#get_subjects_for_assign').click(function(){
            var a = $('#InstutionName').val();
            var b = $('#Course_type').val();
            var c = $('#DepartmentName').val();
            var d = $('#Course_name').val();
            var e = $('#Batch').val();
            var f = $('#Semesters').val();
            $('#data1').val(a);
            $('#data2').val(b);
            $('#data3').val(c);
            $('#data4').val(d);
            $('#data5').val(e);
            $('#data6').val(f);
            $('#form_data1').submit();
        });

        $('#download-button').click(function(){
            var a = $('#InstutionName').val();
            var b = $('#Course_type').val();
            var c = $('#DepartmentName').val();
            var d = $('#Course_name').val();
            var e = $('#Batch').val();
            var f = $('#Semesters').val();
            $('#data1').val(a);
            $('#data2').val(b);
            $('#data3').val(c);
            $('#data4').val(d);
            $('#data5').val(e);
            $('#data6').val(f);
            $('#download-form').submit();
        });
    });
</script>
