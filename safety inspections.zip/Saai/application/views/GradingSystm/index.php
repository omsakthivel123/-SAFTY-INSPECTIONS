<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light"> Grading System/</span>Student Evaluation Entry</h4>

        <div class="row">

            <!-- Basic Layout -->
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-body">

                        <div class="row">
                            <div class="col-sm-12">
                                <!-- Material tab card start -->
                                <div class="card">
                                    <div class="card-block">

                                        <div class="row py-3">

                                            <div class="col-md-3">
                                                <label for="InstutionName" class="text-dark"> Instution</label>
                                                <select name="InstutionName" class="form-control" id="InstutionName"></select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('InstutionName'); ?></span>

                                            </div>
                                            <div class="col-md-3">
                                                <label for="Course_type" class="text-dark">Course Type</label>
                                                <select name="Course_type" class="form-control" id="Course_type"></select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('Course_type'); ?></span>

                                            </div>
                                            <div class="col-md-3">
                                                <label for="DepartmentName" class="text-dark">Department</label>
                                                <select name="DepartmentName" class="form-control" id="DepartmentName"> </select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('DepartmentName'); ?></span>

                                            </div>
                                            <div class="col-md-3">
                                                <label for="Course_name" class="text-dark">Course Name</label>
                                                <select name="Course_name" class="form-control" id="Course_name"> </select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('Course_name'); ?></span>

                                            </div>


                                        </div>
                                        <div class="row">

                                            <div class="col-md-3">
                                                <label for="Batch" class="text-dark">Batch</label>
                                                <select name="Batch" class="form-control" id="Batch"> </select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('Batch'); ?></span>

                                            </div>

                                            <div class="col-md-3">
                                                <label for="Semesters" class="text-dark">Semester</label>
                                                <select name="Semesters" class="form-control" id="Semesters"> </select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('Semesters'); ?></span>

                                            </div>

                                            <div class="col-md-3">
                                                <label for="Section" class="text-dark">Section</label>
                                                <select name="Section" class="form-control" id="Section"> </select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('Section'); ?></span>

                                            </div>

                                            <div class="col-md-3">
                                                <label for="ExamCategory" class="text-dark">Exam Category</label>
                                                <select name="ExamCategory" class="form-control" id="ExamCategory">
                                                    <option value="">Select Exam Category</option>
                                                    <option value="Internal I">Internal I</option>
                                                    <option value="Internal II">Internal II</option>
                                                    <option value="Internal III">Internal III</option>
                                                    <option value="Model"> Model</option>
                                                </select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('ExamCategory'); ?></span>

                                            </div>



                                        </div>
                                        <div class="row py-3">

                                            <div class="col-md-3">
                                                <label for="SubjectName" class="text-dark">Subject Name</label>
                                                <select name="SubjectName" class="form-control" id="SubjectName"> </select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('SubjectName'); ?></span>

                                            </div>


                                            <div class="col-md-3">
                                                <label for="Category" class="text-dark">Category</label>
                                                <input type="text" name="Category" class="form-control" id="Category" >
                                                <span class="input-group" style="color:red;"><?php echo form_error('Category'); ?></span>

                                            </div>
                                            <div class="col-md-3">
                                                <label for="Credits" class="text-dark">Credits</label>
                                                <input type="text" name="Credits" class="form-control" id="Credits" >
                                                <span class="input-group" style="color:red;"><?php echo form_error('Credits'); ?></span>

                                            </div>

                                            <div class="col-md-3">
                                                <label for="Qualifying_Grade" class="text-dark">Qualifying Grade</label>
                                                <input type="text" name="Qualifying_Grade" class="form-control" id="Qualifying_Grade" >
                                                <span class="input-group" style="color:red;"><?php echo form_error('Qualifying_Grade'); ?></span>

                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Row start -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div>


                <!-- row complete for box   -->

                <div class="card mb-4" id="mark_entry">
                    <div class="card-body">
                        <div class="row justify-content-strat py-3" id="view-btn">
                            <div class="col-auto">
                                <button type="button" class="btn btn-outline-primary btn-sm" id="select_mark">Select All</button>
                            </div>
                        </div>
                        <div class="row">
                            <div id="student_mark_entry">
                                <div id="table-container" style="overflow-x: auto;">
                                    <table id="student-mark-entry" class="table table-striped">
                                        <thead style="background-color: #302c63; color: white;">
                                            <tr>
                                                <th class="text-white">Select</th>
                                                <th  class="text-white">S.No</th>
                                                <th  class="text-white">Course Type</th>
                                                <th  class="text-white">Department</th>
                                                <th  class="text-white">Register No</th>
                                                <th  class="text-white">Student Name</th>
                                                <th  class="text-white">Section</th>
                                                <th  class="text-white">Batch</th>
                                                <th  class="text-white">Semester</th>
                                                <th  class="text-white">Exam Type</th>
                                                <th  class="text-white">Mark</th>
                                                <th  class="text-white">Attendance</th>
                                                <th  class="text-white">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                        </tbody>
                                    </table>

                                    <div class="row justify-content-end py-3" id="view-btn">
                                        <div class="col-auto">
                                            <button type="button" class="btn btn-outline-info btn-sm" id="update_marks">Update</button>
                                        </div>
                                    </div>

                                </div>
                            </div>



                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>