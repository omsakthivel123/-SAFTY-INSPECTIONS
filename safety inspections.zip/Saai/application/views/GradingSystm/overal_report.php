<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light"> Grading System/</span>Student Overall Report</h4>

        <div class="row">

            <!-- Basic Layout -->
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-body">

                        <div class="row">
                            <div class="col-sm-12">
                                <!-- Material tab card start -->
                                <div class="card">
                                    <div class="card-block">

                                        <div class="row py-3">

                                            <div class="col-md-3">
                                                <label for="InstutionName" class="text-dark"> Instution</label>
                                                <select name="InstutionName" class="form-control" id="InstutionName"></select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('InstutionName'); ?></span>

                                            </div>
                                            <div class="col-md-3">
                                                <label for="Course_type" class="text-dark">Course Type</label>
                                                <select name="Course_type" class="form-control" id="Course_type"></select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('Course_type'); ?></span>

                                            </div>
                                            <div class="col-md-3">
                                                <label for="DepartmentName" class="text-dark">Department</label>
                                                <select name="DepartmentName" class="form-control" id="DepartmentName"> </select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('DepartmentName'); ?></span>

                                            </div>
                                            <div class="col-md-3">
                                                <label for="Course_name" class="text-dark">Course Name</label>
                                                <select name="Course_name" class="form-control" id="Course_name"> </select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('Course_name'); ?></span>

                                            </div>


                                        </div>
                                        <div class="row">

                                            <div class="col-md-3">
                                                <label for="Batch" class="text-dark">Batch</label>
                                                <select name="Batch" class="form-control" id="Batch"> </select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('Batch'); ?></span>

                                            </div>

                                            <div class="col-md-3">
                                                <label for="Semesters" class="text-dark">Semester</label>
                                                <select name="Semesters" class="form-control" id="Semesters"> </select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('Semesters'); ?></span>

                                            </div>

                                            <div class="col-md-3">
                                                <label for="Section" class="text-dark">Section</label>
                                                <select name="Section" class="form-control" id="Section"> </select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('Section'); ?></span>

                                            </div>
                                            <div class="col-md-3">
                                                <label for="ExamCategory" class="text-dark">Exam Category</label>
                                                <select name="ExamCategory" class="form-control" id="ExamCategory">
                                                    <option value="">Select Exam Category</option>
                                                    <option value="Internal I">Internal I</option>
                                                    <option value="Internal II">Internal II</option>
                                                    <option value="Internal III">Internal III</option>
                                                    <option value="Model"> Model</option>
                                                </select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('ExamCategory'); ?></span>

                                            </div>

                                        </div>

                                    </div>
                                    <div class="row justify-content-end py-3" id="view-btn">
                                        <div class="col-auto">
                                            <button type="button" class="btn btn-outline-primary btn-sm" id="overal_report_btn">View</button>
                                        </div>
                                    </div>
                                </div>

                                <!-- Row start -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div>





                <!-- row complete for box   -->

                <div class="card mb-4" id="">
                    <div class="card-body">
                        <div class="row">
                            <div class="table_1 py-5">
                                <h4 id="DepartmentName" class="py-3" style="text-align: center;">Exam Details</h4>

                                <table class="table table-bordered" id="semester_subjects" style="overflow-x: auto">

                                    <thead style="background-color: #302c63;">
                                        <tr>
                                            <th style="color: whitesmoke">S.No</th>
                                            <th style="color: whitesmoke">Exam Type</th>
                                            <th style="color: whitesmoke">Subject Code</th>
                                            <th style="color: whitesmoke">Subject Name</th>
                                            <th style="color: whitesmoke">Exam Date</th>
                                        </tr>
                                    </thead>

                                    <tbody>

                                    </tbody>

                                </table>
                            </div>
                            <div class="table_2">
                                <table class="table table-bordered" id="mark_table" style="overflow-x: auto">
                                    <thead style="background-color: #302c63;">

                                        <tr></tr>
                                    </thead>
                                    <tbody>

                                    </tbody>

                                </table>

                            </div>


                        </div>
                    </div>
                </div>
                <!-- row end -->

                <!-- row complete for box   -->

                <div class="card mb-4" id="">
                    <div class="card-body">

                        <div class="row">

                        </div>
                    </div>
                </div>
                <!-- row end -->
            </div>
        </div>
    </div>