<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Student/</span>Class Incharge Report</h4>
        <!-- Basic Layout & Basic with Icons -->
        <div class="row">
            <!-- Basic Layout -->
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-body">
                        <!-- Stage 1 -->
                        <div class="stage" id="stage1">
                            <h2 style="display: flex; justify-content: center; font-size: 23px;">Class Incharge Report</h2>
                            <div class="row">
                                <div class="col-md-3 p-3">
                                    <label for="Inst_name_1" class="text-dark">Institution Name</label>
                                    <select name="Inst_name_1" class="form-control" id="Inst_name_1" required></select>
                                </div>
                                <div class="col-md-3 p-3">
                                    <label for="Inst_codes" class="text-dark">Institution Code</label>
                                    <input type="text" name="Inst_codes" class="form-control" id="Inst_codes" readonly>
                                </div>
                                <div class="col-md-3 p-3">
                                    <label for="department" class="text-dark">Department Name</label>
                                    <select name="department" class="form-control" id="Department_Name11"></select>
                                </div>
                                <div class="col-md-3 p-3">
                                    <label for="Course_type" class="text-dark">Course Type</label>
                                    <select name="Course_type" class="form-control" id="Course_type"></select>
                                </div>
                                <div class="col-md-3 p-3">
                                    <label for="Batch" class="text-dark">Batch</label>
                                    <select name="Batch" class="form-control" id="Batch"></select>
                                </div>
                                <div class="col-md-3 p-3">
                                    <label for="Section" class="text-dark">Section</label>
                                    <select name="Section" class="form-control" id="Section"></select>
                                </div>
                                <div class="col-md-3 p-3">
                                    <label for="Approval" class="text-dark">Approve</label>
                                    <select name="Approval" class="form-control" id="Approval">
                                        <option value="">Select</option>
                                        <option value="0">Not-Approve</option>
                                        <option value="1">Approved</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row justify-content-end py-3" id="view-btn">
                                <div class="col-auto">
                                    <button type="button" class="btn btn-outline-danger btn-sm" id="get_Department_list23">View</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <form action="<?php echo base_url('Downloader/incharge')?>" method="post" style="display: none;" id="download-form">
    <input type="text" name="Inst_name_1" id="data1">
    <input type="text" name="Inst_codes" id="data2">
    <input type="text" name="department" id="data3">
    <input type="text" name="Course_type" id="data4">
    <input type="text" name="Batch" id="data5">
    <input type="text" name="Section" id="data6">
</form>

            <div class="card mb-4" id="Class-view234">
                <div class="card-body">
                    <div class="row">
                        <div id="attendance-record">
                            <div id="table-container" style="overflow-x: auto;">
                                <div class="d-flex justify-content-end mb-3">
                                    <button id="download-button" class="btn btn-danger">Download Report</button>
                                </div>
                                <table id="sheet" class="table table-striped">
                                    <thead style="background-color: #302c63; color: white;">
                                        <tr>
                                            <th>S No</th>
                                            <th>Institution Code</th>
                                            <th>Institution Name</th>
                                            <th>Department Code</th>
                                            <th>Department Name</th>
                                            <th>Staff Name</th>
                                            <th>Course Type</th>
                                            <th>Batch</th>
                                            <th>Course Name</th>
                                            <th>Section</th>
                                        </tr>
                                    </thead>
                                    <tbody id="Class_stud124"></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
   $(document).ready(function(){
    $('#get_Department_list23').click(function(){
        var a = $('#Inst_name_1').val();
        var b = $('#Inst_codes').val();
        var c = $('#Department_Name11').val();
        var d = $('#Course_type').val();
        var e = $('#Batch').val();
        var f = $('#Section').val();
        $('#data1').val(a);
        $('#data2').val(b);
        $('#data3').val(c);
        $('#data4').val(d);
        $('#data5').val(e);
        $('#data6').val(f);
        $('#form_data1').submit();
    });

    $('#download-button').click(function(){
        var a = $('#Inst_name_1').val();
        var b = $('#Inst_codes').val();
        var c = $('#Department_Name11').val();
        var d = $('#Course_type').val();
        var e = $('#Batch').val();
        var f = $('#Section').val();
        $('#data1').val(a);
        $('#data2').val(b);
        $('#data3').val(c);
        $('#data4').val(d);
        $('#data5').val(e);
        $('#data6').val(f);
        $('#download-form').submit();
    });
});

</script>
