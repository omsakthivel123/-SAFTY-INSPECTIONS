<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Department/</span>Add Class Incharge</h4>

        <!-- Basic Layout & Basic with Icons -->
        <div class="row">
            <!-- Basic Layout -->
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-12">
                                <!-- Material tab card start -->
                                <div class="card">
                                    <div class="card-block">
                                        <form action="<?php echo base_url('department/assign_incharge') ?>" method="POST">
                                            <div class="row py-3">
                                            <div class="col-md-3">
                                                    <label for="InstutionName"> Instution</label>
                                                    <select name="InstutionName" class="form-control" id="InstutionName" required></select>
                                                </div>
                                                <div class="col-md-3">
                                                    <label for="Department_Name" class="text-dark">Department</label>
                                                    <select name="Department_Name" class="form-control" id="Department_Name" required> </select>
                                                </div>
                                                <div class="col-md-3">
                                                    <label for="Staff_Name">Staff Name</label>
                                                    <select name="Staff_Name" class="form-control" id="Staff_Name" required></select>
                                                </div>
                                                <div class="col-md-3">
                                                    <label for="Course_type">Course Type</label>
                                                    <select name="Course_type" class="form-control" id="Course_type" required>
                                                        <option value="Select">Select</option>
                                                        <option value="UG">UG</option>
                                                        <option value="PG">PG</option>
                                                    </select>
                                                </div>
                                               
                                            </div>
                                            <div class="row">
                                            <div class="col-md-3">
                                                    <label for="Course" class="text-dark">Course</label>
                                                    <select name="Course" class="form-control" id="Course" required> </select>
                                                </div>
                                                <div class="col-md-3">
                                                    <label for="Batch" class="text-dark">Batch</label>
                                                    <select name="Batch" class="form-control" id="Batch" required>

                                                    </select>
                                                </div>
                                               
                                                <div class="col-md-3">
                                                    <label for="Section" class="text-dark">Section</label>
                                                    <select name="Section" class="form-control" id="Section" required>

                                                    </select>
                                                </div>
                                            </div>
                                            
                                            </div>
                                            <div class="row" style="margin-top: 20px;">
                                                <div class="row justify-content-end">
                                                    <div class="col-auto">
                                                        <button type="submit" class="btn btn-outline-primary btn-sm submit">Assign</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                   

                                    <!-- Row start -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card mb-4">
                    <div class="card-body">
                        <!-- Table Container Row Start -->
                        <div class="row">
                            <div class="col-sm-12">
                                <!-- Material tab card start -->
                                <div class="card">
                                    <div class="card-block">
                                        <form id="myForm">
                                        <div id="table-container" style="overflow-x: auto;">
                                        <table id="sheet" class="table table-striped">
                                        <thead style="background-color: #302c63; color: white;">
                                                    <tr>
                                                        <th>S.NO</th>
                                                        <th>Instution Name</th>
                                                        <th>Department Code</th>
                                                        <th>Department Name</th>
                                                        <th>Staff Name</th>
                                                        <th>Course type</th>
                                                        <th>Batch</th>
                                                        <th>Course Name</th>
                                                        <th>Section</th>
                                                        <th>Approval Status</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $i = 1;
                                                    foreach ($get_assign_staff as $row) { ?>
                                                        <tr>
                                                            <td><?php echo $i ?></td>
                                                            <td><?php echo $row->Instution_Name ?></td>
                                                            <td><?php echo $row->Department_Code ?></td>
                                                            <td><?php echo $row->Department_Name ?></td>
                                                            <td><?php echo $row->Staff_Name ?></td>
                                                            <td><?php echo $row->Course_type ?></td>
                                                            <td><?php echo $row->Batch ?></td>
                                                            <td><?php echo $row->Course_Name ?></td>
                                                            <td><?php echo $row->Section ?></td>
                                                            <td><?php  $row->Approval_Status;  // Corrected to echo/print the value
                                                                if ($row->Approval_Status == "0") {
                                                                ?> <span class="badge bg-danger">Not Approved</span> <?php
                                                                } else { ?>
                                                                    <span class="badge bg-success">Approved</span>
                                                                <?php } ?>
                                                            </td>

                                                        </tr>
                                                    <?php $i++;
                                                    } ?>
                                                </tbody>
                                            </table>
                                           
                                        </form>

                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Table Container Row End -->
                        <script>
                            // Function to handle flash messages with SweetAlert
                            function handleFlashMessages() {
                                <?php if ($this->session->flashdata('success')) : ?>
                                    Swal.fire({
                                        icon: 'success',
                                        title: 'Success!',
                                        text: '<?php echo $this->session->flashdata('success'); ?>',
                                    });
                                <?php elseif ($this->session->flashdata('error')) : ?>
                                    Swal.fire({
                                        icon: 'error',
                                        title: 'Error!',
                                        text: '<?php echo $this->session->flashdata('error'); ?>',
                                    });
                                <?php endif; ?>
                            }

                            // Call the function when the page loads
                            window.onload = function() {
                                handleFlashMessages();
                            };
                        </script>



                    </div>
                </div>
            </div>
        </div>
    </div>

</div>