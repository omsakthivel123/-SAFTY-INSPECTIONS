        <div class="container" style="padding-top : 30px;">

    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.min.c ss">
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>

<!-- <script src="<?php echo base_url('/asset/assets/vendor/libs/jquery/jquery.js') ?>"></script>
<script src="<?php echo base_url('/asset/assets//vendor/libs/popper/popper.js') ?>"></script>
<script src="<?php echo base_url('/asset/assets/vendor/js/bootstrap.js') ?>"></script>
<script src="<?php echo base_url('/asset/assets//vendor/libs/perfect-scrollbar/perfect-scrollbar.js') ?>"></script>
<script src="<?php echo base_url('/asset/assets//vendor/js/menu.js') ?>"></script> -->
<!-- Vendors JS -->
<script src="<?php echo base_url('/asset/assets/vendor/libs/apex-charts/apexcharts.js') ?>"></script>
<script src="<?php echo base_url('/asset/assets/js/main.js') ?>"></script>
<script src="<?php echo base_url('/asset/assets/js/dashboards-analytics.js') ?>"></script>

          <!-- Material tab card start -->
          <div class="card">
            <div class="card-block">
              <footer class="content-footer footer card-body">
                <p class="text-center mt-3">© <?php echo date('Y') ?>. Design & Developed By Saai Health Care</p>
              </footer>
              <!-- / Footer -->

              <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
              


              <div class="content-backdrop fade"></div>
            </div>
            <!-- Content wrapper -->
          </div>
          <!-- / Layout page -->
        </div>

        <!-- Overlay -->
        <div class="layout-overlay layout-menu-toggle"></div>
        </div>  