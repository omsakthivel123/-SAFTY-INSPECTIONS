<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Fees Management/</span>Student Portal</h4>

        <div class="row">
            <!-- Basic Layout -->
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-12">
                                <!-- Material tab card start -->
                                <div class="card">
                                    <div class="card-block">
                                        <div class="row py-3">
                                            <div class="col-md-4">
                                                <label for="InstutionName" class="text-dark">Instution</label>
                                                <select name="InstutionName" class="form-control" id="InstutionName"></select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('InstutionName'); ?></span>
                                            </div>

                                            <div class="col-md-4">
                                                <label for="usertype" class="text-dark">User Type</label>
                                                <select name="usertype" class="form-control" id="usertype">
                                                    <option value="Select User">Select User</option>
                                                    <option value="Admin">Admin</option>
                                                    <option value="Cashier">Cashier</option>
                                                </select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('usertype'); ?></span>
                                            </div>

                                            <div class="col-md-4">
                                                <label for="StudentAdmisssionNo" class="text-dark">Student Admission No</label>
                                                <input type="text" name="StudentAdmisssionNo" class="form-control" id="StudentAdmisssionNo">
                                                <span class="input-group" style="color:red;"><?php echo form_error('StudentAdmisssionNo'); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row justify-content-end py-3" id="view-btn">
                                        <div class="col-auto">
                                            <button type="button" class="btn btn-outline-info btn-sm" id="Check_Fees">Check</button>
                                        </div>
                                    </div>
                                </div>
                                <!-- Material tab card end -->
                            </div>
                        </div>
                    </div>
                </div>




                <div>
                    <div class="card mb-4" id="">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-12">
                                    <nav class="navbar navbar-dark  justify-content-center" style="background-color: #302c63; color: white;">
                                        <h4 class="text-center text-white mt-2">Student Profile</h4>
                                    </nav>

                                    <div class="p-3 table-responsive">
                                        <table style="border-collapse: collapse;" border="1" cellpadding="5" class="table table-bordered">
                                            <tbody>
                                                <tr>
                                                    <td><span class="text-dark">Roll Number</span><br><span id="RollNo" class="value"></span></td>
                                                    <td colspan="2"><span class="text-dark">Student Name</span><br><span id="StudentName" class="value"></span></td>
                                                    <td><span class="text-dark">Date Of Birth</span><br><span id="DOB" class="value"></span></td>
                                                    <td rowspan="3"><span class="text-dark" style="justify-content: center; display: flex;"></span><br><span class="value" style="justify-content: center; display: flex;"><img src="<?php echo base_url('') ?>" alt="Student Image" height="200px" width="200px"></span></td>
                                                </tr>
                                                <tr>
                                                    <td colspan="1"><span class="text-dark">Department</span><br><span class="value"></span></td>
                                                    <td colspan="2"><span class="text-dark">Course</span><br><span id="Course" class="value"></span></td>
                                                    <td colspan="1"><span class="text-dark">Batch</span><br><span id="Batch" class="value"></span></td>
                                                </tr>
                                                <tr>
                                                    <td colspan="1"><span class="text-dark">Semester</span><br><span id="Semester" class="value"></span></td>
                                                    <td colspan="1"><span class="text-dark">Exam Register Number</span><br><span id="Exam_Reg_No" class="value"></span></td>
                                                </tr>
                                            </tbody>

                                        </table>
                                    </div>


                                    <br>
                                    <!-- 
                                    <nav class="navbar navbar-dark bg-primary justify-content-center">
                                        <h4 class="text-center text-white mt-2">View Fee Dues</h4>
                                    </nav> -->
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card mb-4" id="">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-12">
                                    <nav class="navbar navbar-dark  justify-content-center" style="background-color: #302c63; color: white;">
                                        <h4 class="text-center text-white mt-2">View Fee Dues</h4>
                                    </nav>

                                    <div class="p-3 table-responsive">
                                        <table style="border-collapse: collapse;" cellpadding="5" class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>S No</th>
                                                    <th>Semester</th>
                                                    <th>Fee Type</th>
                                                    <th>Fee Amount</th>
                                                    <th>Payment Status</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody id="fees_append">
                                                <tr>

                                                </tr>
                                            </tbody>

                                        </table>
                                    </div>


                                    <br>

                                    <!-- Button trigger modal
                                    <div id="fees_append" class="container mt-5">
                                        <button type="button" class="btn btn-primary pay-btn" data-bs-toggle="modal" data-bs-target="#loginModal">
                                            Open Modal
                                        </button>
                                    </div> -->

                                    <!-- Modal -->
                                    <div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered modal-sm">
                                            <div class="modal-content">
                                                <div class="modal-header" style="background-color: #302c63; color: white;">
                                                    <h5 class="modal-title text-center" id="loginModalLabel">Verification</h5>
                                                    <!-- <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button> -->
                                                </div>
                                                <div class="modal-body">
                                                    <form id="loginForm">
                                                        <div class="mb-3">
                                                            <label for="username" class="form-label">Username</label>
                                                            <input type="text" class="form-control" id="username" name="username" required>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label for="password" class="form-label">Password</label>
                                                            <input type="password" class="form-control" id="password" name="password" required>
                                                        </div>
                                                    </form>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-danger btn-sm" data-bs-dismiss="modal">Cancel</button>
                                                    <button type="submit" form="loginForm" class="btn btn-success btn-sm">Submit</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                    <!-- 
                                    <nav class="navbar navbar-dark bg-primary justify-content-center">
                                        <h4 class="text-center text-white mt-2">View Fee Dues</h4>
                                    </nav> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- col-xxl end -->
        </div>
        <!-- row end -->