<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Fees Module/</span>Fees</h4>
        <!-- Basic Layout & Basic with Icons -->
        <div class="row">
            <div class="row justify-content-end py-3">
                <!-- <div class="col-auto">
                    <a href="<?php echo base_url('Management/assign_fees') ?>" class="btn btn-outline-success btn-sm">Fees Assign</a>
                </div> -->
            </div>

            <!-- New Section with 4 Boxes -->
            <div class="row">
                <div class="col-md-3">
                    <div class="card text-center mb-4">
                        <div class="card-body">
                            <a href="<?php echo base_url('management/assign_fees') ?>">
                                <div class="icon mb-3">
                                    <i class="bx bx-dollar-circle" style="font-size: 2rem;"></i>
                                </div>
                                <h5 class="card-title">Fees</h5>
                                <p class="card-text">Manage Fees Assign.</p>
                            </a>
                        </div>
                    </div>
                </div>


                <div class="col-md-3">
                    <div class="card text-center mb-4">
                        <div class="card-body">
                        <a href="<?php echo base_url('management/concession_fees') ?>">
                                <div class="icon mb-3">
                                    <i class="bx bx-book" style="font-size: 2rem;"></i>
                                </div>
                                <h5 class="card-title">Concession Fees</h5>
                                <p class="card-text">Manage Fees Assign.</p>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card text-center mb-4">
                        <div class="card-body">
                        <a href="<?php echo base_url('management/student_payment') ?>">
                                <div class="icon mb-3">
                                    <i class="bx bx-book" style="font-size: 2rem;"></i>
                                </div>
                                <h5 class="card-title">Student Portal</h5>
                                <p class="card-text">Student Fees Management.</p>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card text-center mb-4">
                        <div class="card-body">
                            <a href="fees_url">
                                <div class="icon mb-3">
                                    <i class="bx bx-dollar-circle" style="font-size: 2rem;"></i>
                                </div>
                                <h5 class="card-title">Fees</h5>
                                <p class="card-text">Manage fees.</p>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- row complete for box -->
            <div class="card mb-4" id="subject">
                <div class="card-body">
                    <div class="row">
                        <div id="subject_report">
                            <div id="table-container" style="overflow-x: auto;">
                                <table id="sheet" class="table table-striped">
                                    <thead style="background-color: #302c63; color: white;">
                                        <tr>
                                            <th>S.No</th>
                                            <th>Instution Name</th>
                                            <th>Course Type</th>
                                            <th>Department</th>
                                            <th>Course Name</th>
                                            <th>Batch</th>
                                            <th>Semester</th>
                                            <th>Subject Code</th>
                                            <th>Subject Name</th>
                                            <th>Category</th>
                                            <th>Credits</th>
                                            <th>Qualifying Grade</th>
                                            <th>Created By</th>
                                        </tr>
                                    </thead>
                                    <tbody id="assign_subject_list">
                                        <!-- Dynamic content here -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>