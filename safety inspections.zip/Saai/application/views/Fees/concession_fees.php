<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Fees Module/</span>Assign Fees</h4>
        <!-- Basic Layout & Basic with Icons -->


        <div class="row">

            <!-- Basic Layout -->
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-body">

                        <div class="row">
                            <div class="col-sm-12">
                                <!-- Material tab card start -->

                                <div class="card">
                                    <div class="card-block">
                                        
                                        <!-- <div class="row justify-content-end py-3">
                                            <div class="col-auto">
                                                <a href="<?php echo base_url('Management/assign_fees') ?>" class="btn  btn-outline-info btn-sm ">Add Subject</a>
                                            </div>
                                        </div> -->

                                        <div class="row py-3">

                                            <div class="col-md-3">
                                                <label for="InstutionName" class="text-dark"> Instution</label>
                                                <select name="InstutionName" class="form-control" id="InstutionName"></select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('InstutionName'); ?></span>

                                            </div>
                                            <div class="col-md-3">
                                                <label for="Course_type" class="text-dark">Course Type</label>
                                                <select name="Course_type" class="form-control" id="Course_type"></select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('Course_type'); ?></span>

                                            </div>
                                            <div class="col-md-3">
                                                <label for="DepartmentName" class="text-dark">Department</label>
                                                <select name="DepartmentName" class="form-control" id="DepartmentName"> </select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('DepartmentName'); ?></span>

                                            </div>
                                            <div class="col-md-3">
                                                <label for="Course_name" class="text-dark">Course Name</label>
                                                <select name="Course_name" class="form-control" id="Course_name"> </select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('Course_name'); ?></span>

                                            </div>
                                        </div>
                                        <div class="row py-3">
                                        <div class="col-md-3">
                                                <label for="Batch" class="text-dark">Batch</label>
                                                <select name="Batch" class="form-control" id="Batch" required> </select>
                                            </div>
                                            <div class="col-md-3">
                                                <label for="Semesters" class="text-dark">Semester</label>
                                                <select name="Semesters" class="form-control" id="Semesters"> </select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('Semesters'); ?></span>

                                            </div>

                                            <div class="col-md-3">
                                                <label for="Section" class="text-dark">Section</label>
                                                <select name="Section" class="form-control" id="Section"> </select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('Section'); ?></span>

                                            </div>
                                            <div class="col-md-3">
                                                <label for="Student_id" class="text-dark">Student Id</label>
                                                <select name="Student_id" class="form-control" id="Student_id"> </select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('Student_id'); ?></span>

                                            </div>
                                        </div>
                                        
                                        <div class="row py-3">
                                        <div class="col-md-3">
                                                <label for="StudentName" class="text-dark">Student Name</label>
                                                <input type="text" name="StudentName" class="form-control" id="StudentName"  > 
                                                <span class="input-group" style="color:red;"><?php echo form_error('StudentName'); ?></span>

                                            </div>
                                        <div class="col-md-3">
                                                <label for="Fees_Type" class="text-dark"> Fees Type</label>
                                                <select name="Fees_Type" class="form-control" id="Fees_Type">
                                                    <option value="Concession" selected >Concession</option> 
                                                </select>
                                                <span class="input-group" style="color:red;"><?php echo form_error('FeesType'); ?></span>

                                            </div>
                                            <div class="col-md-3" id="Fees_input">
                                                <label for="Concession" class="text-dark">Enter Concession Fees</label>
                                                <div class="input-group">
                                                    <input type="text" name="Concession" class="form-control" id="Concession">
                                                    <div class="input-group-append">
                                                        <span class="input-group-text">₹</span>
                                                    </div>
                                                </div>
                                                <span style="color:red;" id="feesError"></span> <!-- This span is used to display errors -->
                                            </div>



                                        </div>

                                    </div>
                                    <div class="row justify-content-end py-3" id="view-btn">
                                        <div class="col-auto">
                                            <button type="button" class="btn btn-outline-danger btn-sm" id="consession_fees">Upadte</button>
                                        </div>
                                    </div>


                                </div>




                                <!-- Row start -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div>


                <!-- row complete for box   -->

                <div class="card mb-4" id="subject">
                    <div class="card-body">
                        <div class="row">
                            <div id="subject_report">
                                <div id="table-container" style="overflow-x: auto;">
                                    <table id="sheet" class="table table-striped">
                                        <thead style="background-color: #302c63; color: white;">
                                            <tr>
                                                <th>S.No</th>
                                                <th>Instution Name</th>
                                                <th>Course Type</th>
                                                <th>Department</th>
                                                <th>Course Name</th>
                                                <th>Batch</th>
                                                <th>Semester</th>
                                                <th>Subject Code </th>
                                                <th>Subject Name</th>
                                                <th>Category</th>
                                                <th>Credits</th>
                                                <th>QualifyingGrade</th>
                                                <th>Created By</th>
                                            </tr>
                                        </thead>
                                        <tbody id="assign_subject_list">

                                        </tbody>
                                    </table>

                                </div>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>