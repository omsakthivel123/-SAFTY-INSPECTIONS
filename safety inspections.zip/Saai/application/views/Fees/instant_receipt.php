
<style>
    .container {
        margin-top: 30px;
        margin-bottom: 30px;
    }

    .row {
        justify-content: center;
    }

    .card {
        width: 100%;
        border: 1px solid #dee2e6;
        border-radius: 0.25rem;
    }

    .card-body {
        padding: 1.25rem;
    }

    .button {
        display: flex;
        justify-content: flex-end;
    }

    .image {
        
        
    }

    .text-center {
        text-align: center;
    }

    .border-top {
        border-top: 1px solid #dee2e6;
    }

    .mt-4 {
        margin-top: 1.5rem;
    }

    .mb-2 {
        margin-bottom: 0.5rem;
    }

    .mb-4 {
        margin-bottom: 1.5rem;
    }

    .col-md-6 {
        flex: 0 0 50%;
        max-width: 50%;
    }

    .col-md-6.text-md-end {
        /* text-align: right; */
    }

    .table {
        width: 100%;
        margin-bottom: 1rem;
        color: #212529;
    }

    .table th,
    .table td {
        padding: 0.75rem;
        vertical-align: top;
        border-top: 1px solid #dee2e6;
    }

    .table-bordered th,
    .table-bordered td {
        border: 1px solid #dee2e6;
    }

    .text-end {
        text-align: right;
    }
</style>

<div class="container mt-6 mb-7 ">
    <div class="row justify-content-center">
        <div class="col-lg-12 col-xl-8">
            <div style="box-shadow: rgba(0, 0, 0, 0.16) 0px 10px 36px 0px, rgba(0, 0, 0, 0.06) 0px 0px 0px 1px;">
                
            <div class="card" style="">
                 <div class="but" style="justify-content: end;">
                <a class="btn btn-danger btn-sm text-center float-right" href="<?php echo base_url('Fees/live_payment_reciept');?>">Back</a>&nbsp;&nbsp;&nbsp;<button class="btn btn-success btn-sm float-right" onclick="printDiv();"><i class="fa-solid fa-download" style="color: #ffffff;"></i> PDF</button>
                 </div>
                <div class="card-body ">
                   
                    <div class="image " style="display: flex; justify-content: center;">
                        <img src="https://application.annaiveilankannis.com/uploads/banner/14.jpg" style="  height: 150px; width: 500px; "><br>
                    </div>
                    <!--<div class="" style=" display: flex; justify-content: center; width: 100%; height: auto;">-->
                    <!--     <p class="" style="text-align: center;">81/33 V.G.P. Salai, Saidapet, Chennai – 600 015.<br> Tamilnadu, India.<br>Email: mail4avc@gmail.com <br>-->
                    <!--     Contact : 044-43523712-->
                    <!--     </p>-->
                    <!--     </div>-->
                    <div class="button">
               
                        <!--<a class="btn btn-success btn-sm" href="<?php echo base_url('Reciept/downloadpdf'); ?>">Download PDF</a>-->
                    </div>
                    <h3  style="margin-top: 10px; text-align: center;">Payment Receipt</h3>
                    
                    
                    <div class="row" style="font-family: Calibri;">
		       
		       <div class="col-sm-12">
		           
		          
		           <div class="col-sm-12" style=" padding : 15px;">
		               <table style="  width:100%;font-size: 15px; border-top: 1px solid black; border-bottom: 1px solid black;  margin-bottom: 15px;  border-collapse: collapse;page-break-after:auto;"  cellpadding="5" class="parent_details">
		               <tbody>
		                   <tr style="page-break-inside:avoid; page-break-after:auto">
		                       
		                        <td><span class="head"><b>Roll No :</b></span><span class="value"><?php echo $result->Roll_No; ?></span></td>
		                        <td><span class="head"><b>Exam Reg No :</b></span><span class="value"><?php echo $result->Exam_Reg_Id; ?></span></td>
		                       <td><span class="head"><b>Student Name :</b></span><span class="value"></span> <?php echo $result->StudentName; ?></td>
		                   </tr>
		                   <tr>
		                       <td><span class="head"><b>DOB :</b></span><span class="value"></span><?php echo $result->Dob; ?></td>
		                       <td><span class="head"><b>Department :</b></span><span class="value"></span><?php echo $result->Department; ?></td>
		                       <td><span class="head"><b>Course :</b></span><span class="value"></span><?php echo $result->Course_Code; ?></td>
		                   </tr>
		                    <tr>
		                        <td><span class="head"><b>Semester :</b></span><span class="value"></span><?php echo $result->Semester; ?></td>
		                        <td><span class="head"><b>Receipt No :</b></span><span class="value"></span><?php echo $result->Receipt_No; ?></td>
		                       <td><span class="head"><b>Date :</b></span><span class="value"></span><?php  $dob = $result->Payment_Date; 
        // Assuming $dob is in 'Y-m-d' format, you can adjust this format accordingly
        $formatted_dob = date('j-m-Y', strtotime($dob)); // Formats the date
        echo $formatted_dob; 
        ?></td>
		                      
		                   </tr>
		                   <tr>
		                       <td><span class="head"><b>Payment Mode :</b></span><span class="value"></span><?php echo $result->Payment_Type; ?></td>
                               <td><span class="head"><b>Payment Type :</b></span><span class="value"></span><?php echo $result->Payment_Mode; ?></td>
		                       <td><span class="head"><b>Payment ID :</b></span><span class="value"></span><?php echo $result->Payment_Id; ?></td>
		                   </tr>
		               </tbody>
		           </table>
		          
		           </div>
		       </div>
		       
		   </div>
                    
                    <div class="row" style="font-family: Calibri;">
        		       <div class="col-sm-12 " style=" padding : 15px;">
        		           <table style="border-collapse: collapse; width: 100%;">
                                <thead>
                                    <tr>
                                        <th style=" text-align: center; border: 1px solid #000;  padding: 8px;">Particulars</th>
                                        <th style=" text-align: right; border: 1px solid #000;  padding: 8px;">Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td style= " text-align: center; border: 1px solid #000; padding: 8px;"><?php echo $result->Payment_For; ?></td>
                                        <td style=" text-align: right; border: 1px solid #000; padding: 8px;"><?php echo $result->Pay_Amount; ?></td>

                                    </tr>
                                </tbody>
                                <tfoot>
                                    <tr>
                                    <td  style=" text-align: center; border: 1px solid #000; padding: 8px;"><p id="result"> </p>

                                        <td colspan=2 style=" text-align: right; border: 1px solid #000; padding: 8px;">Total : <?php echo $result->Pay_Amount; ?></td>
                                    </tr>
                                </tfoot>
                    </table>
                    <div id="amountContainer">
                       <input type="hidden" id="amount" name="amount" value="<?php echo $result->Pay_Amount; ?>" >
                       <input type="hidden" id="printname11" name="amount" value="Fees_Reciept" >
                       <p id="result"> </p>
                       <!-- <p>Payment Mode : Online </p> -->
                    </div>
                    <div class=" amount"></div>
                      </div>
		          </div>
                    <div class="wordings mt-4">
                        <h5 class="text-center text-success" style="text-align: center; color: green;">Thank you For your Payment!!</h5>
                         
                    </div>
                </div>
                
            </div>
            </div>
        </div>
    </div>
</div>


<!--=============================================================convert to document========================================================================-->

<div class="container mt-6 mb-7 printdiv_pdf"  style="display: none;">
    <div class="row justify-content-center">
        <div class="col-lg-12 col-xl-8">
            
                
            <div class="card" style="padding: 20px;">
                <div class="card-body p-5">
                    <div class="image " style="display: flex; justify-content: center;">
                        <img src="https://application.annaiveilankannis.com/uploads/banner/14.jpg" style="  height: 150px; width: 500px; "><br>
                    </div>
                    <!--<div class="" style=" display: flex; justify-content: center; width: 100%; height: auto;">-->
                    <!--     <p class="" style="text-align: center;">81/33 V.G.P. Salai, Saidapet, Chennai – 600 015.<br> Tamilnadu, India.<br>Email: mail4avc@gmail.com <br>-->
                    <!--     Contact : 044-43523712-->
                    <!--     </p>-->
                    <!--     </div>-->
                    <div class="button">
               
                        <!--<a class="btn btn-success btn-sm" href="<?php echo base_url('Reciept/downloadpdf'); ?>">Download PDF</a>-->
                    </div>
                    <h3  style="margin-top: 10px; text-align: center;">Payment Receipt</h3>
                    
                    
                    <div class="row" style="font-family: Calibri;">
		       
		       <div class="col-sm-12">
		           
		          
		           <div class="col-sm-12" style=" padding : 15px;">
		               <table style="  width:100%;font-size: 15px; border-top: 1px solid black; border-bottom: 1px solid black; margin-top: 15px; margin-bottom: 15px;  border-collapse: collapse;page-break-after:auto;"  cellpadding="5" class="parent_details">
		               <tbody>
		                   <tr style="page-break-inside:avoid; page-break-after:auto">
		                       
		                        <td><span class="head"><b>Roll No :</b></span><span class="value"><?php echo $result->Roll_No; ?></span></td>
		                        <td><span class="head"><b>Exam Reg No :</b></span><span class="value"><?php echo $result->Exam_Reg_Id; ?></span></td>
		                       <td><span class="head"><b>Student Name :</b></span><span class="value"></span> <?php echo $result->Student_Name; ?></td>
		                   </tr>
		                   <tr>
		                       <td><span class="head"><b>DOB :</b></span><span class="value"></span><?php echo $result->Dob; ?></td>
		                       <td><span class="head"><b>Department :</b></span><span class="value"></span><?php echo $result->Department; ?></td>
		                       <td><span class="head"><b>Course :</b></span><span class="value"></span><?php echo $result->Course_Code; ?></td>
		                   </tr>
		                    <tr>
		                        <td><span class="head"><b>Semester :</b></span><span class="value"></span><?php echo $result->Semester; ?></td>
		                        <td><span class="head"><b>Receipt No :</b></span><span class="value"></span><?php echo $result->Receipt_No; ?></td>
		                       <td><span class="head"><b>Date :</b></span><span class="value"></span><?php  $dob = $result->Payment_Date; 
        // Assuming $dob is in 'Y-m-d' format, you can adjust this format accordingly
        $formatted_dob = date('j-m-Y', strtotime($dob)); // Formats the date
        echo $formatted_dob; 
        ?></td>
		                      
		                   </tr>
		                   <tr>
                           <td><span class="head"><b>Payment ID :</b></span><span class="value"></span><?php echo $result->Payment_Id; ?></td>
		                       <td><span class="head"><b>Payment ID :</b></span><span class="value"></span><?php echo $result->Payment_Mode; ?></td>
		                       <td><span class="head"><b>Semester :</b></span><span class="value"></span><?php echo $result->Semester; ?></td>
		                   </tr>
		               </tbody>
		           </table>
		          
		           </div>
		       </div>
		       
		   </div>
                    
                    <div class="row" style="font-family: Calibri;">
        		       <div class="col-sm-12 " style=" padding : 15px;">
        		           <table style="border-collapse: collapse; width: 100%;">
                                <thead>
                                    <tr>
                                        <th style=" text-align: center; border: 1px solid #000;  padding: 8px;">Particulars</th>
                                        <th style=" text-align: right; border: 1px solid #000;  padding: 8px;">Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td style= " text-align: center; border: 1px solid #000; padding: 8px;"><?php echo $result->Payment_For; ?></td>
                                        <td style=" text-align: right; border: 1px solid #000; padding: 8px;" ><?php echo $result->Pay_Amount; ?></td>
                                    </tr>
                                </tbody>
                                <tfoot>
                                    <tr  >
                                    <td  style=" text-align: center; border: 1px solid #000; padding: 8px;">                       <p id="result123"> </p>

                                        <td colspan=2 style=" text-align: right; border: 1px solid #000; padding: 8px;">Total : <?php echo $result->Pay_Amount; ?></td>
                                    </tr>
                                </tfoot>
                    </table>
                    <!--<div id="amountContainer">-->
                     
                    <!--    <input type="hidden" id="printname11" name="amount" value="Fees_Reciept" >-->
                       <p id="result123"> </p>
                    <!--    <p>Payment Mode : Online </p>-->
                    <!--</div>-->
                    <div class=" amount"></div>
                      </div>
		          </div>
                    <div class="wordings mt-4">
                        <h5 class="text-center text-success" style="text-align: center; color: green;">Thank you For your Payment!!</h5>
                       
                    </div>
                </div>
                
            </div>
             
        </div>
    </div>
</div>


<script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
<script>


</script>



