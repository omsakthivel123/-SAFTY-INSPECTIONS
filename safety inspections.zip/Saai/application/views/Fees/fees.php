<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Student/</span>Fees Details</h4>

        <!-- Basic Layout & Basic with Icons -->
        <div class="row">
            <!-- Basic Layout -->
            <div class="col-xxl">

                <!-- <div class="card mb-4" id="">
                    <div class="card-body">
                        <div class="row">
                            <div class="row justify-content-start py-3" id="view-btn">
                                <div class="col-auto">
                                    <button type="button" class="btn btn-outline-info btn-sm" id="select_for_fees">Select All</button>
                                </div>
                            </div>
                            <div id="course_mentor">
                                <div id="table-container" style="overflow-x: auto;">
                                    <table id="tableforfees" class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th></th>

                                                <th>Department</th>
                                                <th>Course Type</th>
                                                <th>Course Name</th>
                                                <th>Batch</th>
                                                <th>Semester</th>
                                                <th>Section</th>
                                                <th>Student Id</th>
                                                <th>Student Name</th>
                                                <th>Fees Type</th>
                                                <th>Fees</th>
                                                <th>Description</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody> -->
                                            <!-- <?php
                                            $i = 1;
                                            foreach ($fee as $row) {
                                            ?> -->
                                                <!-- <tr>
                                                    <td><input id="clicked" type="checkbox" name="fee_ids[]" value="<?php echo $row->FeesType; ?>"></td> 
 -->

                                                    <!-- <td><?php echo $row->Department ?></td>
                                                    <td><?php echo $row->CourseType ?></td>
                                                    <td><?php echo $row->CourseName ?></td>
                                                    <td><?php echo $row->Batch ?></td>
                                                    <td><?php echo $row->Semester ?></td>
                                                    <td><?php echo $row->Section ?></td>
                                                    <td><?php echo $row->StudentId ?></td>
                                                    <td><?php echo $row->StudentName ?></td>
                                                    <td><?php echo $row->FeesType ?></td>
                                                    <td><?php echo $row->Fees ?></td>
                                                    <td>
                                                        <?php
                                                        $status = $row->PaymentStatus;
                                                        if ($status == 'Pending') { ?>
                                                            <span class="badge bg-danger">Pending</span>
                                                        <?php } else { ?>
                                                            <span class="badge bg-success">Assigned</span>
                                                        <?php }
                                                        ?> -->
                                                    <!-- </td>
                                                    <td>
                                                        <button class="btn btn-info btn-sm razorpay-button" id="razorpay" data-payment_id="your_payment_id" data-amount="your_amount" data-currency="your_currency" data-buttontext="Pay with Razorpay">
                                                            Pay Now
                                                        </button>
                                                    </td>
                                                </tr>
                                            <?php
                                                $i++;
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> -->

                <div class="card mb-4" id="">
                    <div class="card-body">
                        <div class="row">


                            <nav class="navbar navbar-dark justify-content-center" style="background-color: #302c63; color: white; height: 50px;">
                                <h4 class="text-center text-white mt-2">View Fee Dues </h4>
                            </nav>
                            <div >
                                <div class="table-responsive py-2">

                                    <div class="row">
                                        <div class="col-md-4">

                                            <label><b>Fees Type</b> </label>
                                            <select class="form-select" id="FeesType">
                                               
                                            </select>
                                        </div>
                                        <div class="col-md-8" style="display: flex; justify-content: flex-end; height: 30px;">
                                            <a href="<?php echo base_url('Fees/reciept_table') ?>" id="view-reciept" class="btn btn-outline-info btn-sm ">View Receipt</a>
                                        </div>
                                    </div>
                                    <br>
                                    <br>

                                    <table class="table table-bordered ">
                                        <thead>
                                            <tr>
                                                <th scope="col">S.No</th>
                                                <th scope="col">Fees Type</th>
                                                <th scope="col">Semester</th>
                                                <th scope="col">Amount</th>
                                            </tr>
                                        </thead>
                                        <tr>
                                            <tbody id="your_table_id">

                                            </tbody>
                                        </tr>
                                    </table>

                                   
                                </div>
                                 <div style="display: flex; justify-content: flex-end;">
                                        <!--<a href="<?php echo base_url('Multi/reciept') ?>" style="space-between: 10px" id="view-reciept" class="btn btn-dark btn-sm">View Reciept</a>-->
                                        <div style="width: 10px;"></div>


                                        <button type"button" class="btn btn-outline-success btn-sm" id="rzp-button">Pay Now</button>
                                    </div>



                            </div>

                            <!--===============================================-->
                        </div>


                    </div>

                    <form class="form-horizontal" id="razorpay1" role="form" action="<?php echo base_url('Fees/callback') ?>" method="post">
                        <input type="hidden" name="order_id" id="order_id">
                        <input type="hidden" name="payment_id" id="payment_id">
                        <input type="hidden" name="selectedSemesters" id="selectedSemesters">
                        <input type="hidden" name="totalAmount" id="totalAmount">
                        <input type="hidden" name="signature_value" id="signature_value">
                    </form>
                    <br>

                </div>
            </div>
        </div>
    </div>
</div>
</div>


<script>
                                // Function to handle flash messages with SweetAlert
                                function handleFlashMessages() {
                                    <?php if ($this->session->flashdata('success')) : ?>
                                        Swal.fire({
                                            icon: 'success',
                                            title: 'Success!',
                                            text: '<?php echo $this->session->flashdata('success'); ?>',
                                            showConfirmButton: true,
                                            onClose: () => {
                                                // Redirect or do something after closing
                                            }
                                        }).then((result) => {
                                            if (result.isConfirmed) {
                                                // Close the SweetAlert dialog
                                                Swal.close();
                                            }
                                        });
                                    <?php elseif ($this->session->flashdata('error')) : ?>
                                        Swal.fire({
                                            icon: 'error',
                                            title: 'Error!',
                                            text: '<?php echo $this->session->flashdata('error'); ?>',
                                            showConfirmButton: true,
                                            onClose: () => {
                                                // Redirect or do something after closing
                                            }
                                        }).then((result) => {
                                            if (result.isConfirmed) {
                                                // Close the SweetAlert dialog
                                                Swal.close();
                                            }
                                        });
                                    <?php endif; ?>
                                }

                                // Call the function when the page loads
                                window.onload = function() {
                                    handleFlashMessages();
                                };
                            </script>




<!-- Razorpay Form -->
<form class="form-horizontal" id="razorpay-form" role="form" action="<?php echo base_url('Management/callback') ?>" method="post">
    <input type="hidden" name="order_id" id="order_id">
    <input type="hidden" name="payment_id" id="payment_id">
    <input type="hidden" name="signature_value" id="signature_value">
</form>

</div>
</div>
</div>
</div>