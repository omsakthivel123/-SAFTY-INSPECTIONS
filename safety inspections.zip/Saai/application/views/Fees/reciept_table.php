<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Student Fees Management/</span>Payment Details</h4>

        <!-- Basic Layout & Basic with Icons -->
        <div class="row">
            <!-- Basic Layout -->
            <div class="col-xxl">
                <div class="card mb-4">

                    <div class="card mb-4" id="">
                        <div class="card-body">
                        <div class="row justify-content-end py-3">
                                            <div class="col-auto">
                                                <a href="<?php echo base_url('Management/fees') ?>" class="btn  btn-outline-info btn-sm ">Home</a>
                                            </div>
                                        </div>
                            <div class="row">
                                <div id="course_mentor">
                                    <div id="table-container" style="overflow-x: auto;">
                                        <table id="" class="table table-striped">
                                            <thead style="background-color: #302c63; color: white;">
                                                <tr>
                                                    <th style="color: white;">S.No</th>
                                                    <th style="color: white;">Payment Date</th>
                                                    <th style="color: white;">Department</th>
                                                    <th style="color: white;">Semester</th>
                                                    <th style="color: white;">Student Id</th>
                                                    <th style="color: white;">Student Name</th>
                                                    <th style="color: white;">Fees Type</th>
                                                    <th style="color: white;">Fees Amount</th>
                                                    <th style="color: white;">Payment Mode</th>
                                                    <th style="color: white;">Payment Type</th>
                                                    <th style="color: white;">Payment Status</th>
                                                    <th style="color: white;">Action</th>
                                                </tr>
                                            </thead>
                                            <?php
                                            $i = 1;
                                            foreach ($result as $row) {
                                            ?>
                                                <tr> <!-- Assuming you meant to use <tr> instead of <tbody> for each row -->
                                                    <td><?php echo $i; ?></td>
                                                    <td><?php echo $row->Payment_Date; ?></td>  <!-- Assuming you meant to use $row->CourseName instead of $row->Department -->
                                                    <td><?php echo $row->Department; ?></td>
                                                    <td><?php echo $row->Semester; ?></td>  <!-- Assuming you meant to use $row->CourseName instead of $row->Department -->
                                                    <td><?php echo $row->Student_Id; ?></td>
                                                    <td><?php echo $row->StudentName; ?></td>
                                                    <td><?php echo $row->FeesType; ?></td>
                                                    <td><?php echo $row->Fees; ?></td>
                                                    <td><?php echo $row->Payment_Mode; ?></td>
                                                    <td><?php echo $row->Payment_Type; ?></td>
                                                    <td>
                                                        <?php
                                                        $sts = $row->PaymentStatus;
                                                        if ($sts == "Pending") {
                                                        ?><span class="badge bg-warning">Pending</span><?php
                                                            } else {
                                                                ?><span class="badge bg-success">Paid</span><?php
                                                            } ?>
                                                    </td>
                                                    <td>
                                                        <a href="<?php echo base_url(); ?>Fees/payment_reciept/<?php echo $row->Get_Id; ?>">
                                                            <i class="fas fa-download" style="color: #004201; font-size: 17px;"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php
                                                $i++;
                                            }
                                            ?>

                                        </table>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>