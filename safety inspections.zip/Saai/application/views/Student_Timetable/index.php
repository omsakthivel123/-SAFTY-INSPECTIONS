<style>
    .checkbox-row {
        display: flex;
        gap: 10px;
    }

    .checkbox-row label {
        display: flex;
        align-items: center;
    }

    table {
        width: 100%;
        border-collapse: collapse;
    }

    th,
    td {
        border: 1px solid black;
        text-align: center;
        padding: 8px;
    }

    th {
        background-color: #f2f2f2;
    }
</style>
<div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Student Wise/</span>Assign Time Table</h4>

        <div class="row">
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="card">
                                    <div class="card-block">
                                        <div class="row">
                                            <div id="form-wizard">
                                                <form id="wizard-form1">
                                                    <div class="step" id="step-1">
                                                        <h2 style="display: flex; justify-content: center; font-size: 23px;">Time Table</h2>
                                                        <div class="row">
                                                            <input type="hidden" name="department_name" id="Department_name001" value="<?php echo $dep; ?>">

                                                            <div class="col-md-3  p-3 " >
                                                                <label for="Course_type" class="text-dark">Course Type</label>
                                                                <select name="courseType" class="form-control " id="Course_type22"></select>
                                                            </div>
                                                            <div class="col-md-3  p-3">
                                                                <label for="Batch2" class="text-dark">Batch</label>
                                                                <select name="Batch2" class="form-control" id="Batch2"></select>
                                                            </div>
                                                            <div class="col-md-3  p-3">
                                                                <label for="Semester" class="text-dark">Semester</label>
                                                                <select name="Semester" class="form-control" id="get_Semester"></select>
                                                            </div>

                                                            <div class="col-md-3  p-3">
                                                                <label for="Department" class="text-dark">Select Section</label>
                                                                <select name="Section23" class="form-control" id="Section23">
                                                                </select>
                                                            </div>



                                                        </div>
                                                    </div>

                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y">

        <div class="row">
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-body">

                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-body">
                                        <!-- <h4 class="card-title" style="text-align: center;">Student Timetable</h4> -->
                                        <div class="table-responsive">
                                            <table id="timetableTable1" class="table table-striped">
                                                <thead style="background-color: #302c63; color: white;">
                                                    <tr>
                                                        <th class="text-white">Day</th>
                                                        <th class="text-white">Hour 1</th>
                                                        <th class="text-white">Hour 2</th>
                                                        <th class="text-white">Hour 3</th>
                                                        <th class="text-white">Hour 4</th>
                                                        <th class="text-white">Hour 5</th>
                                                        <th class="text-white">Hour 6</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    // Define an array for day names
                                                    $daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

                                                    // Loop through each day
                                                    for ($dayIndex = 0; $dayIndex < count($daysOfWeek); $dayIndex++) :
                                                    ?>
                                                        <tr data-day="<?= $dayIndex + 1 ?>">
                                                            <td><?= $daysOfWeek[$dayIndex] ?></td>
                                                            <td></td>
                                                            <td></td>
                                                            <td></td>
                                                            <td></td>
                                                            <td></td>
                                                            <td></td> <!-- Add more columns as needed -->
                                                        </tr>
                                                    <?php endfor; ?>
                                                </tbody>

                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>