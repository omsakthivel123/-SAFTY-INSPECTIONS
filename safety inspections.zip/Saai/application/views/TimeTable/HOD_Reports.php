<div class="content-wrapper">
    <!-- Content -->

    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">HOD/</span>HOD Details Report</h4>

        <!-- Basic Layout & Basic with Icons -->
        <div class="row">
            <!-- Basic Layout -->
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-body">
                        <!-- Stage 1 -->
                        <div class="stage" id="stage1">
                            <h2 style="display: flex; justify-content: center; font-size: 23px;">HOD Reports</h2>

                            <div class="row">
                                <div class="col-md-5 p-3">
                                    <label for="Inst_name_1" class="text-dark">Institution Name</label>
                                    <select name="Inst_name_1" class="form-control" id="Inst_name_1" required></select>
                                </div>
                                <div class="col-md-5 p-3">
                                    <label for="Inst_codes" class="text-dark">Institution Code</label>
                                    <input type="text" name="Inst_codes" class="form-control" id="Inst_codes" readonly>
                                </div>
                                <!-- <div class="col-md-4 p-3">
                                    <label for="department" class="text-dark">Department Name</label>
                                    <select name="department" class="form-control" id="Department_Name11"></select>
                                </div> -->
                             </div>

                            <div class="row justify-content-end py-3" id="view-btn">
                                <div class="col-auto">
                                    <button type="button" class="btn btn-outline-danger btn-sm" id="HOD_details">View</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card mb-4" id="hod-view2">
                <div class="card-body">
                    <div class="row">
                        <div id="attendance-record">
                            <div id="table-container" style="overflow-x: auto;">
                                <div class="d-flex justify-content-end mb-3">
                                    <button id="download-buttonhod" class="btn btn-danger">Download Report</button>
                                </div>
                                <table id="sheet" class="table table-striped">
                                    <thead style="background-color: #302c63; color: white;">
                                        <tr>
                                            <th class="text-white">S.No</th>
                                            <th class="text-white">Institution Name</th>
                                            <th class="text-white">Institution Code</th>
                                            <th class="text-white">Department</th>
                                            <th class="text-white">Hod Name</th>
                                        </tr>
                                    </thead>
                                    <tbody id="hod_detail1"></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<form action="<?php echo base_url('Downloader/HOD_Reports') ?>" method="post" style="display: none;" id="hod-download-form">
    <input type="text" name="Inst_name_1" id="data1">
    <input type="text" name="Inst_codes" id="data2">
    <!-- <input type="text" name="department" id="data3"> -->
</form>


<script>
    $(document).ready(function() {
        $('#HOD_details').click(function() {
            var institutionName = $('#Inst_name_1').val();
            var Inst_codes = $('#Inst_codes').val();
            // var departmentName = $('#Department_Name11').val();
            $('#data1').val(institutionName);
            $('#data2').val(Inst_codes);
            // $('#data3').val(departmentName);
            $('#form_datas').submit();
        });

        $('#download-buttonhod').click(function() {
            var institutionName = $('#Inst_name_1').val();
            var Inst_codes = $('#Inst_codes').val();
            // var departmentName = $('#Department_Name11').val();
            $('#data1').val(institutionName);
            $('#data2').val(Inst_codes);
            // $('#data3').val(departmentName);
            $('#hod-download-form').submit();
        });
    });
</script>



