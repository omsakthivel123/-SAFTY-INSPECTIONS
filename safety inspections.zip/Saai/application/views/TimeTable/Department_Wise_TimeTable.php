<style>
    table {
        width: 100%;
        border-collapse: collapse;
    }

    th,
    td {
        border: 1px solid black;
        text-align: center;
        padding: 8px;
    }

    th {
        background-color: #f2f2f2;
    }
</style>
<div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Department Wise/</span>Assign Time Table</h4>

        <div class="row">
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="card">
                                    <div class="card-block">
                                        <div class="row">
                                            <div id="form-wizard">
                                                <form id="wizard-form1">
                                                    <div class="step" id="step-1">
                                                        <h2 style="display: flex; justify-content: center; font-size: 23px;">Time Table</h2>
                                                        <div class="row">
                                                            <label for="Institute_name" class="text-dark" style="display: none;">Institute Name</label>
                                                            <input type="hidden" name="Institute_name" id="Institution_name" value="<?php echo $InstitutionName?>" >

                                                            <label for="Department" class="text-dark" style="display: none;">Department</label>
                                                            <input type="hidden" name="department" id="Department_name">

                                                            <div class="col-md-3  p-3 ">
                                                                <label for="Department" class="text-dark">Departments</label>
                                                                <select name="Department" class="form-control" id="Department_name2">
                                                                    <option value="">Select Departments</option>
                                                                </select>
                                                            </div>
                                                            <div class="col-md-3  p-3 ">
                                                                <label for="Course_type" class="text-dark">Course Type</label>
                                                                <select name="courseType" class="form-control " id="Course_type"></select>
                                                            </div>
                                                            <div class="col-md-3  p-3 ">
                                                                <label for="CourseCode" class="text-dark">Course Code</label>
                                                                <select name="CourseCode" class="form-control " id="CourseCode"></select>
                                                            </div>
                                                            <div class="col-md-3  p-3">
                                                                <label for="Batch" class="text-dark">Batch</label>
                                                                <select name="batch" class="form-control" id="Batch1"></select>
                                                            </div>
                                                            <div class="col-md-3 p-3 ">
                                                                <label for="Semester" class="text-dark">Semester</label>
                                                                <select name="Semester" class="form-control" id="Semesters"></select>
                                                            </div>
                                                            <label for="Hod" class="text-dark" style="display: none;">Department HOD</label>
                                                            <input type="hidden" name="Hod" class="form-control" id="Hod" >
                                                            <!-- <select  name="Hod" class="form-control " id="Hod" readonly></select> -->

                                                            <div class="col-md-3  p-3 ">
                                                                <label for="Staff_ID" class="text-dark">Staff ID</label>
                                                                <select name="Staff_ID" class="form-control " id="Staff_ID" required>
                                                                    <option value="">Select</option>
                                                                </select>
                                                            </div>
                                                            <div class="col-md-3  p-3 ">
                                                                <label for="Staff_Name" class="text-dark"> Staff Name</label>
                                                                <input type="text" name="Staff_Name" class="form-control " id="Staff_Name2" required  >
                                                            </div>
                                                            <div class="col-md-3  p-3 ">
                                                                <label for="Subjects" class="text-dark">Select Subject</label>
                                                                <select name="Subjects" class="form-control " id="Subjects1"></select>
                                                            </div>
                                                            <!-- <div class="col-md-3  p-3">
                                                                <label for="Batch" class="text-dark">Batch</label>
                                                                <select name="batch" class="form-control" id="Batch1"></select>
                                                            </div> -->
                                                            <div class="col-md-3  p-3 ">
                                                                <label for="Class_Section" class="text-dark">Class Section</label>
                                                                <select name="Class_Section" class="form-control" id="Section1">
                                                                    <option value="">Select Section</option>
                                                                </select>
                                                            </div>
                                                            <div class="col-md-3  p-3 ">
                                                                <label for="Shift" class="text-dark">Shift</label>
                                                                <select name="Shift" class="form-control" id="Shift" required>
                                                                    <option value="">Select</option>
                                                                    <option value="I">I</option>
                                                                    <option value="II">II</option>
                                                                </select>
                                                            </div>
                                                            <div class="col-md-3  p-3 ">
                                                                <label for="Dayss" class="text-dark">Days</label>
                                                                <select name="Dayss" class="form-control" id="Days">
                                                                    <option value="">Select</option>
                                                                    <option value="1">1 - Monday</option>
                                                                    <option value="2">2 - Tuesday</option>
                                                                    <option value="3">3 - Wednesday</option>
                                                                    <option value="4">4 - Thursday</option>
                                                                    <option value="5">5 - Friday</option>
                                                                    <option value="6">6 - Saturday</option>
                                                                </select>
                                                            </div>
                                                            <div class="col-md-3  p-3 ">
                                                                <label for="date" class="text-dark">Date </label>
                                                                <input type="date" id="date2" name="date" class="form-control">
                                                            </div>
                                                            <div class="col-md-3  p-3 ">
                                                                <label for="HourSelect" class="text-dark">Select Hours </label>
                                                                <select id="HourSelect" name="selectedHours[]" class="form-control">
                                                                    <option value="">Select Hours</option>
                                                                    <option value="1">1 Hour</option>
                                                                    <option value="2">2 Hour</option>
                                                                    <option value="3">3 Hour</option>
                                                                    <option value="4">4 Hour</option>
                                                                    <option value="5">5 Hour</option>
                                                                    <option value="6">6 Hour</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row justify-content-end">
                                                        <div class="col-auto">
                                                            <button type="submit" class="btn btn-success btn-sm submit">Submit</button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="card">
                                    <div class="card-block">
                                        <div class="row">
                                            <div id="form-wizard">
                                                <div class="row">

                                                    <input type="hidden" name="department_name2" id="Department_name0011" value="<?php echo $DepartmentName; ?>">

                                                    <div class="col-md-3  p-3 ">
                                                        <label for="Course_type223" class="text-dark">Course Type</label>
                                                        <select name="Course_type223" class="form-control " id="Course_type223"></select>
                                                    </div>
                                                    <div class="col-md-3 p-3">
                                                        <label for="Batch23" class="text-dark">Batch</label>
                                                        <select name="Batch23" class="form-control" id="Batch23"></select>
                                                    </div>
                                                    <div class="col-md-3 p-3">
                                                                <label for="Semester" class="text-dark">Semester</label>
                                                                <select name="Semester" class="form-control" id="get_Semesters1"></select>
                                                            </div>

                                                    <div class="col-md-3  p-3 ">
                                                        <label for="Section233" class="text-dark">Select Section</label>
                                                        <select name="Section233" class="form-control" id="Section233">
                                                        </select>
                                                    </div>
                                                </div>
                                                <br>
                                                <div id="table-container" style="overflow-x: auto;">
                                                    <table id="timetableTable" class="table table-striped">
                                                        <thead style="background-color: #302c63; color: white;">
                                                            <tr>
                                                                <th  class="text-white">Day</th>
                                                                <th  class="text-white">Hour 1</th>
                                                                <th  class="text-white">Hour 2</th>
                                                                <th  class="text-white">Hour 3</th>
                                                                <th  class="text-white">Hour 4</th>
                                                                <th  class="text-white">Hour 5</th>
                                                                <th  class="text-white">Hour 6</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <tr data-day="1">
                                                                <td>Monday</td>
                                                                <td></td>
                                                                <td></td>
                                                                <td></td>
                                                                <td></td>
                                                                <td></td>
                                                                <td></td>
                                                            </tr>
                                                            <tr data-day="2">
                                                                <td>Tuesday</td>
                                                                <td></td>
                                                                <td></td>
                                                                <td></td>
                                                                <td></td>
                                                                <td></td>
                                                                <td></td>
                                                            </tr>
                                                            <tr data-day="3">
                                                                <td>Wednesday</td>
                                                                <td></td>
                                                                <td></td>
                                                                <td></td>
                                                                <td></td>
                                                                <td></td>
                                                                <td></td>
                                                            </tr>
                                                            <tr data-day="4">
                                                                <td>Thursday</td>
                                                                <td></td>
                                                                <td></td>
                                                                <td></td>
                                                                <td></td>
                                                                <td></td>
                                                                <td></td>
                                                            </tr>
                                                            <tr data-day="5">
                                                                <td>Friday</td>
                                                                <td></td>
                                                                <td></td>
                                                                <td></td>
                                                                <td></td>
                                                                <td></td>
                                                                <td></td>
                                                            </tr>
                                                            <tr data-day="6">
                                                                <td>Saturday</td>
                                                                <td></td>
                                                                <td></td>
                                                                <td></td>
                                                                <td></td>
                                                                <td></td>
                                                                <td></td>
                                                            </tr>
                                                        </tbody>
                                                    </table>

                                                    <!-- Your dropdowns for department, course type, batch, and section here -->

                                                    <!-- <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
                                                    <script>
                                                        var baseurl = '<?php echo base_url(); ?>';
                                                    </script>
                                                    <script src="path_to_your_script.js"></script> -->
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>