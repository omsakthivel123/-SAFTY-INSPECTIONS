
<div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">HOD/</span>Assign HOD</h4>

        <div class="row">
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="card">
                                    <div class="card-block">
                                        <div class="row">
                                            <div id="form-wizard">
                                                <form id="wizard-form">
                                                    <div class="stage" id="stage1">
                                                        <div class="row">
                                                            <div class="col-md-3 p-3">
                                                                <label for="Inst_name_1" class="text-dark">Institution Name</label>
                                                                <select name="Inst_name_1" class="form-control" id="Inst_name_1" required></select>
                                                            </div>
                                                            <div class="col-md-3 p-3">
                                                                <label for="Inst_codes" class="text-dark">Institution Code</label>
                                                                <input type="text" name="Inst_codes" class="form-control" id="Inst_codes" >
                                                            </div>
                                                            <div class="col-md-3 p-3">
                                                                <label for="department" class="text-dark">Department Name</label>
                                                                <select name="department" class="form-control" id="Department_Name11"></select>
                                                            </div>
                                                            <!-- <div class="col-md-3 p-3">
                                                                <label for="Department" class="text-dark">Department</label>
                                                                <select name="Department" class="form-control" id="Department_type1" required></select>
                                                            </div> -->
                                                            <!-- <div class="col-md-3 p-3">
                                                                <label for="Course_type" class="text-dark">Course Type</label>
                                                                <select name="Course_type" class="form-control " id="Course_type" ></select>
                                                            </div> -->
                                                            <!--  <div class="col-md-3 p-3">
                                                                <label for="CourseCode" class="text-dark">Course Code</label>
                                                                <select name="CourseCode" class="form-control " id="CourseCode"></select>
                                                            </div> -->
                                                            <div class="col-md-3  p-3 ">
                                                                <label for="Staff_ID" class="text-dark">Staff ID</label>
                                                                <select name="Staff_ID" class="form-control " id="Staff_ID1" required>
                                                                    <option value="">Select</option>
                                                                </select>
                                                            </div>
                                                            <div class="col-md-3  p-3 ">
                                                                <label for="Staff_Name" class="text-dark"> Staff Name</label>
                                                                <input type="text" name="Hod_Name" class="form-control " id="Staff_Name21" required  >
                                                            </div>
                                                            <!-- <div class="col-md-3 p-3">
                                                                <label for="Staff_Name" class="text-dark">Staff Name</label>
                                                                <select name="Staff_Name" class="form-control Staff_Name1" id="Staff_Name">
                                                                    <option value="">Select</option>
                                                                </select>
                                                            </div>
                                                            <div class="col-md-3 p-3">
                                                                <label for="Sub_Staff_Name" class="text-dark">Sub Staff Name</label>
                                                                <select name="Sub_Staff_Name" class="form-control Staff_Name1" id="Sub_Staff_Name">
                                                                    <option value="Select">Select</option>
                                                                </select>
                                                            </div>
                                                            <div class="col-md-3 p-3">
                                                                <label for="Subjects" class="text-dark">Select Subject</label>
                                                                <select name="Subjects" class="form-control " id="Subjects"></select>
                                                            </div>
                                                            <div class="col-md-3 p-3">
                                                                <label for="Class_Section" class="text-dark">Class Section</label>
                                                                <select name="Class_Section" class="form-control" id="Class_Section">
                                                                    <option value="">Select</option>
                                                                    <option value="(A)">A</option>
                                                                    <option value="(B)">B</option>
                                                                    <option value="(C)">C</option>
                                                                    <option value="(D)">D</option>
                                                                </select>
                                                            </div>
                                                            <div class="col-md-3 p-3">
                                                                <label for="Dayss" class="text-dark">Days</label>
                                                                <select name="Dayss" class="form-control" id="Days">
                                                                    <option value="">Select</option>
                                                                    <option value="1">1 - Monday</option>
                                                                    <option value="2">2 - Tuesday</option>
                                                                    <option value="3">3 - Wednesday</option>
                                                                    <option value="4">4 - Thursday</option>
                                                                    <option value="5">5 - Friday</option>
                                                                    <option value="6">6 - Saturday</option>
                                                                </select>
                                                            </div>
                                                            <div class="col-md-3 p-3">
                                                                <label for="Shift" class="text-dark">Shift</label>
                                                                <select name="Shift" class="form-control" id="Shift">
                                                                    <option value="">Select</option>
                                                                    <option value="I">I</option>
                                                                    <option value="II">II</option>
                                                                </select>
                                                            </div>
                                                            <div class="row mt-3">
                                                                <div class="col-md-12">
                                                                    <label class="text-dark">Select Hours:</label>
                                                                    <div class="checkbox-row">
                                                                        <label>
                                                                            <input type="checkbox" name="Hour_1"> 1 Hour
                                                                        </label>
                                                                        <label>
                                                                            <input type="checkbox" name="Hour_2" value="2"> 2 Hours
                                                                        </label>
                                                                        <label>
                                                                            <input type="checkbox" name="Hour_3" value="3"> 3 Hours
                                                                        </label>
                                                                        <label>
                                                                            <input type="checkbox" name="Hour_4" value="4"> 4 Hours
                                                                        </label>
                                                                        <label>
                                                                            <input type="checkbox" name="Hour_5" value="5"> 5 Hours
                                                                        </label>
                                                                        <label>
                                                                            <input type="checkbox" name="Hour_6" value="6"> 6 Hours
                                                                        </label>
                                                                    </div>
                                                                </div>
                                                            </div> -->

                                                        </div>
                                                        <div class="row justify-content-end">
                                                            <div class="col-auto">
                                                                <button type="button" class="btn btn-outline-secondary btn-sm next ">Next</button>
                                                            </div>
                                                        </div>


                                                    </div>
                                                    <div class="stage" id="final-stage">
                                                        <h2 class="py-4" style="display: flex; justify-content: center; font-size: 23px;">Create Login Details</h2>

                                                        <div class="container">
                                                            <div class="row justify-content-center mb-3">
                                                                <div class="col-md-3 text-end">
                                                                    <label for="User_role">User Role :</label>
                                                                </div>
                                                                <div class="col-md-3">
                                                                    <input type="text" name="User_role" id="User_role" class="form-control" value="HOD" >
                                                                    <!-- <?php echo form_error('User_role', '<div class="error">', '</div>'); ?> -->
                                                                </div>
                                                            </div>

                                                            <div class="row justify-content-center mb-3">
                                                                <div class="col-md-3 text-end">
                                                                    <label for="Username">Username :</label>
                                                                </div>
                                                                <div class="col-md-3">
                                                                    <input type="email" name="Username" id="Username" class="form-control">
                                                                    <?php echo form_error('Username', '<div class="error">', '</div>'); ?>
                                                                </div>
                                                            </div>

                                                            <div class="row justify-content-center mb-3">
                                                                <div class="col-md-3 text-end">
                                                                    <label for="Password">Password :</label>
                                                                </div>
                                                                <div class="col-md-3">
                                                                    <input type="password" name="Password" id="Password" class="form-control">
                                                                    <?php echo form_error('Password', '<div class="error">', '</div>'); ?>
                                                                </div>
                                                            </div>

                                                            <div class="row justify-content-center mb-3">
                                                                <div class="col-md-3 text-end">
                                                                    <label for="Confirm_Password">Confirm Password :</label>
                                                                </div>
                                                                <div class="col-md-3">
                                                                    <input type="password" name="Confirm_Password" id="Confirm_Password" class="form-control">
                                                                    <?php echo form_error('Confirm_Password', '<div class="error">', '</div>'); ?>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="row justify-content-end">
                                                            <div class="col-auto">
                                                                <button type="button" class="btn btn-outline-danger btn-sm previous">Previous</button>
                                                                <button type="submit" class="btn btn-outline-success btn-sm submit">Submit</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- <div class="row justify-content-end">
                                                        <div class="col-auto">
                                                            <button type="submit" class="btn btn-success btn-sm submit">Submit</button>
                                                        </div>
                                                    </div> -->
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="card">
                                    <div class="card-block">
                                        <div class="row">
                                            <div id="form-wizard">
                                            <h4 style="text-align: center;">HOD List</h4>

                                                <div class="col-md-3" id="departmentContainer">
                                                    <label for="InstutionName" class="text-dark">Select Instution </label>
                                                    <select name="InstutionName" class="form-control" id="InstutionName">
                                                    </select>
                                                </div>
                                                <br>
                                                <div id="table-container" style="overflow-x: auto;">
                                                    <table id="hod_table" class="table table-responsive">
                                                        <thead style="background-color: #302c63; color: white;">

                                                            <tr>
                                                                <th class="text-white">S.No</th>
                                                                <th class="text-white">Institution Name</th>
                                                                <th class="text-white">Department</th>
                                                                <th class="text-white">Staff Id</th>
                                                                <th class="text-white">HOD Name</th>
                                                                <th class="text-white">Created By</th>
                                                                <th class="text-white">Modified On</th>
                                                                <th class="text-white">Action</th>

                                                            </tr>
                                                        </thead>
                                                        <tbody id="hod_list">
                                                            <!-- Table rows will be dynamically added here via JavaScript -->
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>